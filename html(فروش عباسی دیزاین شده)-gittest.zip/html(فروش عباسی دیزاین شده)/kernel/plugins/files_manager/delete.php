<?php
include_once '../../config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$data = array(
  $checked->checkPost('id_delete', 11, 'notNull'),
  $checked->checkPost('image_name', 150, 'notNull'),
);
$output->delete_data($data);
