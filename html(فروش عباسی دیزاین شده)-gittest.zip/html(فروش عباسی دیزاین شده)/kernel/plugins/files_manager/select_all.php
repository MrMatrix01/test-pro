<?php
include_once '../../config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$id_page=((int)$checked->checkPost('id_page', 11, 'notNull')-1)*15;
$data = array(
  $id_page,
);
$output->selectAll_data($data);
