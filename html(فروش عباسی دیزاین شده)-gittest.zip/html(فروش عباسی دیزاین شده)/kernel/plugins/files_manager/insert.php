<?php
include_once '../../config/config.php';
if($checked->checkPost('type', 30, 'notNull')=='file'){
include_once '../../lib/uploads.php';
$valid_formats = array('jpg', 'png', 'jpeg', 'PNG', 'JPG');
$max_file_size = 1024 * 1024 * 10; //100 kb
$path = '../../../uploads/'; // Upload directory
// $path2='/uploads/';
$uploads=New Uploads();
  $uploads->upload($max_file_size, $path, $valid_formats);
  $fileNew = $uploads->file;
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$data = array(
  $_SESSION['id_user'],
  $fileNew[0],
  $checked->checkPost('type', 30, 'notNull'),
  $checked->checkPost('p', 30, 'null'),
);
}elseif($checked->checkPost('type', 30, 'notNull')=='folder') {
  $data = array(
    $_SESSION['id_user'],
    $checked->checkPost('name_folder', 150, 'notNull'),
    $checked->checkPost('type', 30, 'notNull'),
    $checked->checkPost('p', 30, 'null'),
  );
}
$output->insert_data($data);
