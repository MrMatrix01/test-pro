<?php
class DbAction extends Config
{
  public function insert($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'INSERT INTO `rtl_files_user` (`id_rtl_users`,`file_name`,`type`,`parent`)VALUES(?,?,?,?)';
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $id = $conn->lastInsertId();
      // $sh = $stmt->fetch();
      $this->temp = array(
        "image_id"=>$id,
        "image_name" => $data[0],
        // "password" => $sh['password'],
      );
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
  public function delete($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'DELETE FROM `rtl_files_user` WHERE `id` =?';
      $stmt = $conn->prepare($sql);
      $stmt->execute(array($data[0]));
      if (unlink('../../../uploads/'.$data[1])) {
        $result_image='ok';
      } else {
        $result_image='nok';
      }
      $sw = "SELECT * FROM  `rtl_files_user`";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $file_count=  $qw->rowCount();
      $this->temp = array(
        "result_image"=>$result_image,
      );
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
  public function selectAll($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $id_rtl_users=$_SESSION['id_user'];
      $sw = "SELECT * FROM  `rtl_files_user` WHERE `id_rtl_users`='$id_rtl_users'";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $file_count=  $qw->rowCount();



      $sql = "SELECT * FROM `rtl_files_user`   ORDER BY `id` DESC LIMIT $data[0],15";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();
      foreach($sh as $key=>$value) {
        $this->temp5[] = array(
          'id' => @$value['id'],
          'file_name' => @$value['file_name'],
          'type' => @$value['type'],
          'parent' => @$value['parent'],
        );
      }
      $this->temp6=array('file_count' => $file_count, );
      return 'noError';
    } catch (PDOException $e) {
      return  'Error';
    }
    $conn = null;
  }
}
?>
