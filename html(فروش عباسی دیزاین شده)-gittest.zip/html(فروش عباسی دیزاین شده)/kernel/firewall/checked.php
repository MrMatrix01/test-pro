<?php

/**
 *
 */
class Checked
{
  // function __construct(argument)
  // {
  //   // code...
  // }
  public function message($messageCode)
  {
    $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
    $json = array('messageCode' => $messageCode, "Data" => $temp);
    exit(json_encode($json, JSON_UNESCAPED_UNICODE));
  }
  public function filter()
  {
    $blackList = array("script", "'", "<", ">", "%27", "%3C", "%3E", "cookie", "document", "hack", "alert");
    if (isset($_GET)) {
      foreach ($blackList as $k => $v) {
        if (preg_grep("@$v@", $_GET)) {
          include_once 'dbCheck.php';
          $ip = '111';
          $detail = '222';
          $dbCheck = new DbCheck();
          $result = $dbCheck->insertLog($ip, $detail);
          $messageCode = array("code" => "404", "detail" => "Not Found GET3", "message" => "صفحه موجود نمی باشد");
          $this->message($messageCode);
        }
      }
    }
  }
  public function checkPost($key, $length, $null)
  {
    if (isset($_POST[$key])) {
      $varible = @$_POST[$key];
      if ((!empty($varible)) || ($null == "null")) {
        if (strlen($varible) < $length) {
          switch ($key) {
            case 'email':
              if (!filter_var($varible, FILTER_VALIDATE_EMAIL)) {
                // regix email
                // /^(?=[^\._]+[\w_]+([\._])?[\w_]+[^\_]+$)[\w\.]{4,20}(\@)(\w)+(\.)([a-z]){2,6}$/


                $messageCode = array("code" => "400", "detail" => "error email", "message" => "ایمیل اشتباه می باشد");
                $this->message($messageCode);
              }
              break;
            case 'mobile':
              if (!preg_match("/^(0098|\+98|0)?(9\d{9})$/", $varible)) {
                $messageCode = array("code" => "400", "detail" => "error mobile", "message" => "شماره موبایل اشتباه می باشد.");
                $this->message($messageCode);
              }
              break;
            case 'mobile2':
              if (!preg_match("/^(0098|\+98|0)?(9\d{9})$/", $varible)) {
                $messageCode = array("code" => "400", "detail" => "error mobile2", "message" => "شماره موبایل اشتباه می باشد.");
                $this->message($messageCode);
              }
              break;
            case 'phone':
              if (!preg_match("/^(0098|\+98|0)?([0-9]\d{9})$/", $varible)) {
                $messageCode = array("code" => "400", "detail" => "error phone", "message" => "شماره تلفن اشتباه می باشد.");
                $this->message($messageCode);
              }
            case 'nationalCode':
              if (!preg_match("/^[0-9]{8,20}$/", $varible)) {
                $messageCode = array("code" => "400", "detail" => "error nationalCode", "message" => "کد ملی اشتباه می باشد");
                $this->message($messageCode);
              }
              break;
            case 'password':
              $varible = trim(htmlentities(addslashes($varible)));
              return 'm' . md5($varible) . sha1('mrf');
              break;
            case 'new_password':
              $varible = trim(htmlentities(addslashes($varible)));
              return 'm' . md5($varible) . sha1('mrf');
              break;
            case 'old_password':
              $varible = trim(htmlentities(addslashes($varible)));
              return 'm' . md5($varible) . sha1('mrf');
              break;

            default:
              // code...
              break;
          }


          $varible = trim(htmlentities(addslashes($varible)));
          return $varible;
        } else {
          $messageCode = array("code" => "417", "detail" => "length string $key", "message" => "طول رشته بیشتر از مقدار تعیین شده می باشد");
          $this->message($messageCode);
        }
      } else {
        $messageCode = array("code" => "204", "detail" => "empty", "message" => "مقادیر $key خالی می باشد");
        $this->message($messageCode);
      }
    }
  }
  public function checkSession($username, $tokenClient)
  {
    if (isset($_SESSION['id'])) {
      return 'ok';
    } elseif (isset($tokenClient) && isset($username)) {
      include_once 'dbCheck.php';
      $dbCheck = new DbCheck();
      $result = $dbCheck->select($username, $tokenClient);
      //echo $dbCheck->id;
      if ($dbCheck->count == 1) {
        return 'ok';
      } elseif ($dbCheck->count <> 1) {
        $messageCode = array("code" => "404", "detail" => "Not Found1", "message" => "صفحه موجود نمی باشد");
        $this->message($messageCode);
      }
    } elseif (isset($tokenClient)) {
      return 'nok';
    } else {
      $messageCode = array("code" => "404", "detail" => "Not Found2", "message" => "صفحه موجود نمی باشد");
      $this->message($messageCode);
    }
    // if(isset($tokenClient)){
    //
    // }

  }
  public function checkUrl($tokenClient)
  {
    if ((!isset($tokenClient)) && (($_SERVER["HTTP_HOST"] != SITE_URL) || (@$_SERVER["HTTP_REFERER"] != BASE_URL))) {
      $messageCode = array("code" => "404", "detail" => "Not Found4", "message" => "صفحه موجود نمی باشد");
      $this->message($messageCode);
    }
  }
  public function checkToken($token)
  {
    if (!isset($_SESSION['token']) || $_SESSION['token'] != $token) {
      $messageCode = array("code" => "404", "detail" => "Not Found", "message" => "صفحه موجود نمی باشد");
      $this->message($messageCode);
    }
  }
  public function clearScreenText($value)
  {
    return stripcslashes(filter_var($value, FILTER_SANITIZE_FULL_SPECIAL_CHARS));
  }
  public function setToken()
  {
    return base64_encode(md5(microtime()));
  }
}

$checked = new Checked();
$checked->filter();
$username = $checked->checkPost('username_manager', 40, 'null');
$checkToken = $checked->checkPost('token_client', 100, 'null');
$session = $checked->checkSession($username, $checkToken);
if (!isset($checkToken)) {
  $checked->checkToken($checked->checkPost('token', 150, 'notNull'));
}
$checked->checkUrl($checkToken);
