<?php
class DbCheck extends Config
{
  public function insertLog($ip, $detail)
  {
    $host = $this->host;
    $dbname = $this->dbname;
    $user = $this->user;
    $pass = $this->pass;
    try {
      $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'INSERT INTO `logs` (`ip`,`detail`)VALUES(?,?)';
      $stmt = $conn->prepare($sql);
      $stmt->execute(array($ip, $detail));
      return 'noError';
    } catch (PDOException $e) {
      return  'Error: ' . $e->getMessage();
    }
    $conn = null;
  }
  public function select($username, $tokenClient)
  {
    $host = $this->host;
    $dbname = $this->dbname;
    $user = $this->user;
    $pass = $this->pass;
    try {
      $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'SELECT `id` FROM `managers` WHERE `username`=?';
      $stmt = $conn->prepare($sql);
      $stmt->execute(array($username));
      $this->count = $stmt->rowCount();
      $sh = $stmt->fetch();
      $this->id = @$sh['id'];
      return 'ok';
    } catch (PDOException $e) {
      return 'Error';
    }
    $conn = null;
  }
}
