<?php
session_start();

class Config
{
    // protected $host = '127.0.0.1';
    // protected $dbname = 'parscover_vahid';
    // protected $user = 'root';
    // protected $pass = 'iranpars';

    protected $host = '127.0.0.1';
    protected $dbname = 'sell_iranbag';
    protected $user = 'root';
    protected $pass = '291179';
}
 ?>
