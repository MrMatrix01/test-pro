<form  action="request.php" method="post">
  <input type="text" name="amount" value="1000">مبلغ
  <br>
  <input type="text" name="descraption" value="توضیحات تراکنش تستی">
  توضیحات
  <br>
  <input type="text" name="mobile" value="09123456789">
  موبایل
  <br>
    <input type="text" name="email" value="UserEmail@Mail.Com">
  <input type="submit" name="" value="ارسال">

</form>
