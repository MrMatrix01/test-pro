<?php
include 'config.php';
$authority = $_GET['Authority'];

class DbAction extends Config
{
  public function select($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'SELECT * FROM `rtl_transactions` WHERE `authority`=?';

      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $this->count = $stmt->rowCount();
      $sh = $stmt->fetch();
      $this->id=@$sh['id'];
      $this->price=@$sh['price'];
      return 'noError';
    } catch (PDOException $e) {
      return  'Error';
    }
    $conn = null;
  }
  public function update($data1,$data2)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'UPDATE `rtl_transactions` SET `payment`=?,`refid`=? WHERE `authority`=?';
      $stmt = $conn->prepare($sql);
      $stmt->execute($data1);



      $sql = 'UPDATE `buy_castomer` SET `pey`=? WHERE `authority`=?';
      $stmt = $conn->prepare($sql);
      $stmt->execute($data2);



      return 'noError';
    } catch (PDOException $e) {
      // return $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
}

$dbAction=new DbAction();
$dbAction->select([$authority]);
$amount=$dbAction->price;

$data = array("merchant_id" => "4facd492-ed76-4232-ab29-09a68e05991e", "authority" => $authority, "amount" => $amount);
$jsonData = json_encode($data);
$ch = curl_init('https://api.zarinpal.com/pg/v4/payment/verify.json');
curl_setopt($ch, CURLOPT_USERAGENT, 'ZarinPal Rest Api v4');
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  'Content-Type: application/json',
  'Content-Length: ' . strlen($jsonData)
));

$result = curl_exec($ch);
curl_close($ch);
$result = json_decode($result, true);
if (isset($err)) {
  if($err==(-1)){
  echo 'اطلاعات ارسال شده ناقص است';
}elseif ($err==(-2)) {
  echo 'آی پی و مرچنت پذیرنده صحیح نمی باشد';
}elseif ($err==(-3)) {
  echo 'رقم بالای ۱۰۰ تومان باشد.';
}elseif ($err==(-4)) {
  echo 'سطح تایید پذیرنده پایین تر از نقره ای می باشد.';
}elseif ($err==(-11)) {
  echo 'درخواست مورد نظر یافت نشد.';
}elseif ($err==(-22)) {
  echo 'تراکنش ناموفق می باشد.';
}elseif ($err==(-33)) {
  //echo 'رقم تراکنش با رقم پرداخت شده مطابقت ندارد';
  echo 'تراکنش لغو شد';
}elseif ($err==(-54)) {
  echo 'درخواست مورد نظر آرشیو شده.';
}
} else {
  if ($result['data']['code'] == 100) {
    $payment=100;
    $pey=1;
    $result=$dbAction->update([$payment,$result['data']['ref_id'],$authority],[$pey,$authority]);
    if($result=='noError'){
      ?>
      <div style="display:table;width:100%;background-color: #b2fdb2;text-align:center;">
        تراکنش با موفقیت انجام شد.
        <br>
        <!-- شماره تراکنش:
        <b>
        <?php echo $result['data']['ref_id']; ?>
        </b> -->
        <a href="https://iranbag.ir/order?list-order">بازگشت به صفحه خرید</a>
          <meta http-equiv='refresh' content='4; URL=https://iranbag.ir/order?list-order' />
      </div>
      <?php
    }
    // echo 'Transation success. RefID:' . $result['data']['ref_id'];
  } else {
    // echo'code: ' . $result['errors']['code'];
    // echo'message: ' .  $result['errors']['message'];
    ?>
    <meta http-equiv='refresh' content='0; URL=https://iranbag.ir/order' />
    <?php
  }
}
?>
