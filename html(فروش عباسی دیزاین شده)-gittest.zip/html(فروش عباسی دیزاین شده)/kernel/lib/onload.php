<?php
function onload($location,$post='')
{
  function random() {
    return (float)rand()/(float)getrandmax();
  }
  if(isset($_GET['page'])){
    $post_id=$_GET['page'];
  }else {
    $post_id=1;
  }
  $post_final = [
      'token_client' => makeToken(),
      'id' => random(),
  ];
  $post_page = [
      'blog_id' => $post_id,
      'url_id'=>@$GLOBALS['url_id'],
      'blog_url'=>urldecode(Route::getUrl()),
  ];
  if(empty($post)){
    $post=[];
  }
  $post_final=array_merge($post_final,$post_page,$post);
  $ch = curl_init($GLOBALS['countBack'].$location);
  // curl_setopt($ch, CURLOPT_PORT, 8080);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $post_final);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
  $response = curl_exec($ch);

  // close the connection, release resources used
  curl_close($ch);
  $GLOBALS['response']=$response;
}
?>
