<?php
session_start();
$salt = 'amniatMam';
$rand=1;
switch ($rand) {
  case 1:
  $avalinAdad=rand(0,10);
  $dovominAdad=rand(0,10);
  $javab=$avalinAdad+$dovominAdad;
  $_SESSION["pic"]=md5($javab.$salt);
  $pic=$avalinAdad.'+'.$dovominAdad.'=';
  break;
  // case 2:
  // $avalinAdad=rand(0,10);
  // $dovominAdad=rand(0,10);
  // $javab=$avalinAdad-$dovominAdad;
  // $_SESSION["pic"]=md5($javab.$salt);
  // $pic=$avalinAdad.'-'.$dovominAdad.'=';
  // break;
  default:
  ?>
  ؟؟؟!!!???
  <?php
  break;
}


$img = imagecreate(70, 25);
$bgcolor = imagecolorallocate($img, 238, 238, 238);
$fontcolor = imagecolorallocate($img, 80, 80, 80);
imagestring($img, 12, 6, 4, $pic, $fontcolor);
header("Content-Type: image/png");
$a=imagepng($img);
imagedestroy($img);
// $myfile = fopen($a, "w")
?>
