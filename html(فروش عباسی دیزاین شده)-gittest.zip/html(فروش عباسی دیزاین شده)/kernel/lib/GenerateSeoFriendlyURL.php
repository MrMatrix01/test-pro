<?php
class GenerateSeoFriendlyURL{
    public $url = "";
    function __construct(string $url , int $limit){

        $this->url = $this->generateUrl($url);
        $this->url = $this->limitWords($this->url , $limit);
    }

    function generateUrl(string $url){
        $newUrl = $url;
        $patterns = [
        "/[`_\"'\/\\\\]{1,}/i",
        "/[\s+*&^%$#@=.,?!-]{2,}/i",
        ];
        foreach($patterns as $pattern){
            $newUrl = preg_replace($pattern, " " ,$newUrl);
        }

        $newUrl = trim($newUrl);
        $newUrl = str_replace(" " , "-" , $newUrl);
        $newUrl = strtolower($newUrl);
        return $newUrl;
    }

    function limitWords(string $url , int $limit=6){

        if($limit < 2) $limit = 2;

        $urlList = explode("-" , $url);
        $urlList = array_slice($urlList , 0 , $limit);
        $newUrl = join("-",$urlList);
        return $newUrl;
    }

    function getUrl(){
        return $this->url;
    }
}
 ?>
