<?php
class Uploads
{
  public $file;
  public function upload($max_file_size, $path, $valid_formats)
  {
    $count = 0;
    //-----localhost
    // $path2 = '../uploads/';
    //$path2 = $path;
    //-----host
    //  $path2 = 'uploads/';
    // Loop $_FILES to execute all files
    //---------------------مشکل خطا مربوط به نوع  ارسال فرم میباشد و فراخوانی تابع تاریخ
    if(!empty($_FILES['file']['name'])){
    foreach ($_FILES['file']['name'] as $f => $name) {
      if ($_FILES['file']['error'][$f] == 4) {
        continue; // Skip file if any error found
      }
      elseif ($_FILES['file']['error'][$f] == 0) {
        if ($_FILES['file']['size'][$f] > $max_file_size) {
          echo '. از حجمی بالاتر از مقدار مجاز برخوردار است'.$name;
          continue; // Skip large files
        } elseif (!in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats)) {
          echo '. از فرمت فایلی مجاز برای آپلود برخوردار نیست'.$name;
          continue; // Skip invalid file formats
        } else { // No error found! Move uploaded files
          $name = date('Ymjhis').$name;
          $this->name=$name;
          if (move_uploaded_file($_FILES['file']['tmp_name'][$f], $path.$name)) {
            ++$count;

            // $this->file[$f] = "http://{$_SERVER ['HTTP_HOST']}"  . '/'.$path2.$name;
            $this->file[$f] = $name;
            //return 'noErrorImage';
          }
          else{
            return 'ErrorImage';
          }
        }
      }
    }
  }
  }
}
