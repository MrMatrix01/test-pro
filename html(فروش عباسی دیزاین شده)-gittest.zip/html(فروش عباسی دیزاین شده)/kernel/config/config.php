<?php
session_start();
// header("Content-Type:application/json");
header('Content-Type: application/json; charset=utf-8');
if(!defined("SITE_URL")) define("SITE_URL","localhost");
// if (!defined("SITE_URL")) define("SITE_URL", "https://www.iranbag.ir/");
// define(SITE_URL,"test.com");
//--------------------------------------------------
//if(!defined("BASE_URL")) define("BASE_URL","http://localhost/iranbag/backend/");
 if (!defined("BASE_URL")) define("BASE_URL", "https://www.iranbag.ir/backend/");
// define(SITE_URL,"test.com");
//--------------------------------------------------
header("X-Frame-Options:DENY");
class Config
{
    // protected $host = '127.0.0.1';
    // protected $dbname = 'easy_accounting';
    // protected $user = 'root';
    // protected $pass = 'iranpars';

    protected $host = '127.0.0.1';
    protected $dbname = 'sell_iranbag';
    protected $user = 'root';
    protected $pass = '291179';
}
include_once __DIR__ . '../../firewall/checked.php';
include_once __DIR__ . '../../output/output.php';
$output = new Output();
