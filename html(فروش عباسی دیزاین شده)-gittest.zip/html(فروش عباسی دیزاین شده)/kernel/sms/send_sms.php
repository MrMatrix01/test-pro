<?php
// require __DIR__ . '/vendor/autoload.php';
//
// try{
// 	$api = new \Kavenegar\KavenegarApi( "33544A49654A41584F5245782F6E474B304F4D534A324E716D4F614F78384747577646596A5763792F6A493D" );
// 	$sender = "1000033003000";
// 	$message = $phone_pass.'کد ورود شما به ایران بگ: ';
// 	$receptor = array($phone_singin);
// 	$result = $api->Send($sender,$receptor,$message);
// 	if($result){
// 		foreach($result as $r){
// 			// echo "messageid = $r->messageid";
// 			// echo "message = $r->message";
// 			// echo "status = $r->status";
// 			// echo "statustext = $r->statustext";
// 			// echo "sender = $r->sender";
// 			// echo "receptor = $r->receptor";
// 			// echo "date = $r->date";
// 			// echo "cost = $r->cost";
// 		}
// 	}
// }
// catch(\Kavenegar\Exceptions\ApiException $e){
// 	// در صورتی که خروجی وب سرویس 200 نباشد این خطا رخ می دهد
// 	// echo $e->errorMessage();
// }
// catch(\Kavenegar\Exceptions\HttpException $e){
// 	// در زمانی که مشکلی در برقرای ارتباط با وب سرویس وجود داشته باشد این خطا رخ می دهد
// 	// echo $e->errorMessage();
// }
?>

<?php

// curl_setopt($ch, CURLOPT_URL, );
// // curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
// // curl_setopt($ch, CURLOPT_HEADER, 0);
//
// //$body = '{}';
// //curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
// //curl_setopt($ch, CURLOPT_POSTFIELDS,$body);
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);




// // $post_final=array_merge($post_final,$post_page,$post);
// $ch = curl_init("https://api.kavenegar.com/v1/33544A49654A41584F5245782F6E474B304F4D534A324E716D4F614F78384747577646596A5763792F6A493D/verify/lookup.json?receptor=$phone_singin&token=$phone_pass&template=iranbag");
// // curl_setopt($ch, CURLOPT_PORT, 8080);
// curl_setopt($ch, CURLOPT_POST, 1);
// // curl_setopt($ch, CURLOPT_POSTFIELDS, $post_final);
// curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
// $response = curl_exec($ch);
//
// // close the connection, release resources used
// curl_close($ch);



$content = file_get_contents("https://api.kavenegar.com/v1/33544A49654A41584F5245782F6E474B304F4D534A324E716D4F614F78384747577646596A5763792F6A493D/verify/lookup.json?receptor=$phone_singin&token=$phone_pass&template=iranbag");


 ?>
