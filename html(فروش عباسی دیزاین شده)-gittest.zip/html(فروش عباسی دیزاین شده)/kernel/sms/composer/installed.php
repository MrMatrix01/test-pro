<?php return array (
  'root' => 
  array (
    'pretty_version' => 'dev-master',
    'version' => 'dev-master',
    'aliases' => 
    array (
    ),
    'reference' => '2fdfd4a3f1a748eb0d236c13d5dd8e2f8667b66d',
    'name' => '__root__',
  ),
  'versions' => 
  array (
    '__root__' => 
    array (
      'pretty_version' => 'dev-master',
      'version' => 'dev-master',
      'aliases' => 
      array (
      ),
      'reference' => '2fdfd4a3f1a748eb0d236c13d5dd8e2f8667b66d',
    ),
    'kavenegar/php' => 
    array (
      'pretty_version' => 'v1.2.2',
      'version' => '1.2.2.0',
      'aliases' => 
      array (
      ),
      'reference' => '884561b8d8c91b01f7db25284c2be9923c809412',
    ),
  ),
);
