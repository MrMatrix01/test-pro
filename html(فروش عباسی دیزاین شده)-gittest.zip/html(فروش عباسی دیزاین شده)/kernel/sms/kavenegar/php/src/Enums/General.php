<?php

namespace Kavenegar\Enums;

abstract class General {
	const  Enabled = "enabled";
    const  Disabled = "disabled";
}
?>