<?php
class Route {
  public $uri;
  public static $lastElement;
  public static $count;
  public static $gUrl;
  public static function http()
  {
    $pageURL = 'http';
    if (@$_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
    $pageURL .= "://";
    return $pageURL;
  }
  public static function getUrl()
  {
    $requestUri=$_SERVER['REQUEST_URI'];
    $parseUrl=(parse_url($requestUri));
    $rUri=$parseUrl['path'];
    $serverSelf = explode('/index.php', $_SERVER['PHP_SELF']);
    $load = $serverSelf[0];

    if(!empty($load)){
      $rUri = explode($load, $rUri);
      $varRUri=$rUri[1];
    }else {
      $varRUri=$_SERVER['REQUEST_URI'];
    }
    $GLOBALS['uri']= $varRUri;
    self::$lastElement = explode('/', $varRUri);
    self::$count=count(self::$lastElement);
    self::$gUrl='';
    for ($i=0; $i < self::$count-1; $i++) {
      if($i!=0){
        self::$gUrl=self::$gUrl.'/';
      }
      self::$gUrl=self::$gUrl.self::$lastElement[$i];
    }
    // if((is_numeric(self::$lastElement[self::$count-1]))==1){
    //   $GLOBALS['url_id']=self::$lastElement[self::$count-1];
    //   $j=1;
    // }else {
    //   $j=1;
    // }
    $countSlash=substr_count($varRUri, '/');
    $GLOBALS['countBack']=self::http().$_SERVER['SERVER_NAME'].'/';
    // for ($i=$j; $i < $countSlash; $i++) {
    //   $GLOBALS['countBack']='../'.$GLOBALS['countBack'];
    // }
    if(substr($varRUri, strlen($varRUri)-1)=='/' && $varRUri!='/'){
      $er=explode('/',$_SERVER['REQUEST_URI']);
      $mo=urldecode($er[1]);


     header('Location: '.self::http().$_SERVER['HTTP_HOST'].'/'.$mo);
    }else{
      return $varRUri;
    }

  }
  public static function request($receiveUrl,$controller) {
    $rm=explode('?',self::getUrl());
    $h=explode('/', self::$gUrl);
    $t=count($h);
    $q='';
    for ($i=0; $i < $t-1; $i++) {
      if($i!=0){
        $q=$q.'/';
      }
      $q=$q.$h[$i];
    }
    //------------about ---- blog/1
    if(($receiveUrl== $rm[0])||
    (((is_numeric(self::$lastElement[self::$count-1])==1))&&
    (self::$gUrl==$receiveUrl))){
      $GLOBALS['route_page']=$controller;
      if (file_exists($controller.'index.php')) {
        if(isset($_GET['page'])){
          $GLOBALS['url_id']=$_GET['page'];
        }else {
          $GLOBALS['url_id']=1;
        }
        $GLOBALS['m']=1;
        $GLOBALS['main_route']=$controller.'index.php';
      } else {
        $GLOBALS['main_route']='404';
      }
    }elseif ((is_numeric(self::$lastElement[self::$count-2])==1) && ($q==$receiveUrl)) {
      $GLOBALS['m']=1;
      $GLOBALS['url_id']=$h[$t-1];
      $GLOBALS['route_page']=$controller;
      $GLOBALS['main_route']=$controller.'index.php';
    }elseif(@$GLOBALS['f']==1){
      $GLOBALS['route_page']=$controller;
      $GLOBALS['main_route']=$controller.'index.php';
    }
  }
}
?>
