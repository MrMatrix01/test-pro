<?php

/**
 *
 */
include_once 'dbAction.php';
$dbAction = new DbAction();
class Output extends DbAction
{
  public function insert_data($data)
  {
    //----------مشخص کردن موارد ارسال به دیتابیس-------
    $result = $this->insert($data);
    $temp = @$this->temp;
    if ($result == "noError") {
      $messageCode = array("code" => "110", "detail" => "success", "message" => "موفقیت آمیز");
      if ($temp == null) {
        $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      }
      $json = array('messageCode' => $messageCode, "Data" => $temp);
    } else {
      $messageCode = array("code" => "403", "detail" => "repeat", "message" => $result);
      $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      $json = array('messageCode' => $messageCode, "Data" => $temp);
    }
    exit(json_encode($json));
  }
  public function delete_data($data)
  {
    //----------مشخص کردن موارد ارسال به دیتابیس-------
    $result = $this->delete($data);
    $temp = @$this->temp;
    $temp2 = @$this->temp2;
    $temp3 = @$this->temp3;
    $temp4 = @$this->temp4;
    if ($result == "noError") {
      $messageCode = array("code" => "110", "detail" => "success", "message" => "موفقیت آمیز");
      if ($temp == null) {
        $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      }
      $json = array('messageCode' => $messageCode, "Data" => $temp);
    } else {
      $messageCode = array("code" => "403", "detail" => "repeat", "message" => $result);
      $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      $json = array('messageCode' => $messageCode, "Data" => $temp);
    }
    exit(json_encode($json));
  }
  public function login($data_select, $update_token_client)
  {
    $result_select = $this->select($data_select);
    if ($this->count == 1) {
      session_regenerate_id();
      $_SESSION['id'] = $this->id;
      $update_token_client[] = $this->id;
      // $result_update = $this->update_token_client($update_token_client);
      $messageCode = array("code" => "110", "detail" => "success", "message" => "موفقیت آمیز");
      $temp = $this->temp;
    } else if ($result_select == 'Error' && $result_update == 'Error') {
      $messageCode = array("code" => "403", "detail" => "repeat", "message" => '$resultttt');
      $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
    } else {
      $messageCode = array("code" => "109", "detail" => "repeat", "message" => '$result');
      $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');

    }
    $json = array('messageCode' => $messageCode, "Data" => $temp);
    exit(json_encode($json));
  }
  public function check_pass($data_check)
  {
    $result_select = $this->check_pass_manager($data_check);
    if ($this->count == 1) {
      return 'check_pass_ok';
    } else {
      $messageCode = array("code" => "403", "detail" => "repeat", "message" => 'check_pass_nok');
      $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      $json = array('messageCode' => $messageCode, "Data" => $temp);
      exit(json_encode($json));
    }
  }
  public function selectAll_data($data)
  {
    //----------مشخص کردن موارد ارسال به دیتابیس-------
    $result = $this->selectAll($data);
    $temp = @$this->temp;
    $temp2 = @$this->temp2;
    $temp3 = @$this->temp3;
    $temp4 = @$this->temp4;
    $temp5 = @$this->temp5;
    $temp6 = @$this->temp6;
    $temp7 = @$this->temp7;
    if ($result == "noError") {
      $messageCode = array("code" => "110", "detail" => "success", "message" => "موفقیت آمیز");
      if ($temp == null) {
        $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      }
      $json = array('messageCode' => $messageCode, "Data" => $temp,"Data2" => $temp2,"Data3" => $temp3,"Data4" => $temp4,"Data5" => $temp5,"Data6" => $temp6,"Data7" => $temp7);
    } else {
      $messageCode = array("code" => "404", "detail" => "Error Database", "message" => 'error');
      $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      $json = array('messageCode' => $messageCode, "Data" => $temp);
    }

    exit(json_encode($json));
  }
  public function search_data($data)
  {
    //----------مشخص کردن موارد ارسال به دیتابیس-------
    $result = $this->search($data);
    $temp = @$this->temp;
    $temp2 = @$this->temp2;
    $temp3 = @$this->temp3;
    $temp4 = @$this->temp4;
    $temp5 = @$this->temp5;
    $temp6 = @$this->temp6;
    $temp7 = @$this->temp7;
    if ($result == "noError") {
      $messageCode = array("code" => "110", "detail" => "success", "message" => "موفقیت آمیز");
      if ($temp == null) {
        $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      }
      $json = array('messageCode' => $messageCode, "Data" => $temp,"Data2" => $temp2,"Data3" => $temp3,"Data4" => $temp4,"Data5" => $temp5,"Data6" => $temp6,"Data7" => $temp7);
    } else {
      $messageCode = array("code" => "404", "detail" => "Error Database", "message" => 'error');
      $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      $json = array('messageCode' => $messageCode, "Data" => $temp);
    }

    exit(json_encode($json));
  }
  public function select_data($data)
  {
    //----------مشخص کردن موارد ارسال به دیتابیس-------
    $result = $this->select($data);
    $temp = @$this->temp;
    $temp2 = @$this->temp2;
    $temp3 = @$this->temp3;
    $temp4 = @$this->temp4;
    $temp5 = @$this->temp5;
    $temp6 = @$this->temp6;
    $temp7 = @$this->temp7;
    if ($result == "noError") {
      $messageCode = array("code" => "110", "detail" => "success", "message" => "موفقیت آمیز");
      if ($temp == null) {
        $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      }
      $json = array('messageCode' => $messageCode, "Data" => $temp,"Data2" => $temp2,"Data3" => $temp3,"Data4" => $temp4,"Data5" => $temp5,"Data6" => $temp6,"Data7" => $temp7);
    } else {
      $messageCode = array("code" => "404", "detail" => "Error Database", "message" => 'error');
      $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      $json = array('messageCode' => $messageCode, "Data" => $temp);
    }

    exit(json_encode($json));
  }
  public function multi_selectAll_data($data)
  {
    //----------مشخص کردن موارد ارسال به دیتابیس-------
    $result = $this->multiSelectAll($data);
    $temp = @$this->temp;
    if ($result == "noError") {
      $messageCode = array("code" => "110", "detail" => "success", "message" => "موفقیت آمیز");
      if ($temp == null) {
        $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      }
      $json = array('messageCode' => $messageCode, "Data" => $temp);
    } else {
      $messageCode = array("code" => "404", "detail" => "Error Database", "message" => 'error');
      $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      $json = array('messageCode' => $messageCode, "Data" => $temp);
    }

    exit(json_encode($json));
  }
  public function update_data($data_update)
  {
    //----------مشخص کردن موارد ارسال به دیتابیس-------
    $result = $this->update($data_update);
    if ($result == "noError") {
      $messageCode = array("code" => "110", "detail" => "success", "message" => "موفقیت آمیز");
      $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      $json = array('messageCode' => $messageCode, "Data" => $temp);
    } else {
      $messageCode = array("code" => "403", "detail" => "repeat", "message" => $result);
      $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
      $json = array('messageCode' => $messageCode, "Data" => $temp);
    }
    exit(json_encode($json));
  }
  public function error()
  {
    $messageCode = array("code" => "107", "detail" => "captcha", "message" =>'کپچا');
    $temp[] = array("id" => '?', "name" => '?', "avatar" => '?');
    $json = array('messageCode' => $messageCode, "Data" => $temp);
    exit(json_encode($json));
  }
}
