<?php
include_once '../../../kernel/config/config.php';
include_once '../../../kernel/lib/GenerateSeoFriendlyURL.php';
$checked->checkUrl('blog/', $checkToken);
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$data = array(
  ($checked->checkPost('blog_id', 11, 'notNull')-1)*10,
  // 0,
);
$output->selectAll_data($data);
