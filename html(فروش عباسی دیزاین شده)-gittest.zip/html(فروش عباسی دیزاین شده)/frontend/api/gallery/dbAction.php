<?php
class DbAction extends Config
{
  public function selectAll($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT * FROM `rtl_lnd_gallery`  ORDER BY `id` DESC LIMIT $data[0],20";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();


      $sw = "SELECT * FROM  `rtl_lnd_gallery`";
      $qw = $conn->prepare($sw);
      $qw->execute();
      foreach($sh as $key=>$value) {
        $blog_count =  $qw->rowCount();
        $urlObject = new GenerateSeoFriendlyURL($value['title'] , 9);
        $seo_url=$urlObject->getUrl();
        $content=explode("<!--more-->",@$value['content']);
        $this->temp[] = array(
          'id' => @$value['id'],
          'post_content' => @$content[0],
          'post_title' => @$value['title'],
          'guid' => @$value['Preview_image'],
          'seo_url'=>$seo_url,
        );
      }
      $this->temp2=array('blog_count' => $blog_count,);
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
}
