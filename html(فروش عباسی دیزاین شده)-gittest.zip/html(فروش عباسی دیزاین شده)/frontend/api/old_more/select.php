<?php
include_once '../../../kernel/config/config.php';
$checked->checkUrl('old_more/', $checkToken);
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$blog_url=explode('/', $_POST['blog_url']);
$data = array(
  $blog_url[1],
);
$output->selectAll_data($data);
