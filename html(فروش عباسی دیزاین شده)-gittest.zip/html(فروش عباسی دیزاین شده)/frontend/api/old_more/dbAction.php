<?php
class DbAction extends Config
{

  public function selectAll($data)
  {
    $host = $this->host;
    $dbname = $this->dbname;
    $user = $this->user;
    $pass = $this->pass;
    try {
      $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      $sql = "SELECT * FROM `rtl_lnd_posts` WHERE `url`=?";
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $sh=$stmt->fetch();
        $sqll = "SELECT * FROM `rtl_lnd_posts` WHERE `post_parent`=?";

        $stmtl = $conn->prepare($sqll);
        $stmtl->execute(array(@$sh['ID']));
        $shl=$stmtl->fetch();
        if(!empty($shl['guid']) || @$sh['ID']>9199){
          if($sh['ID']>9199){
          $guid = @$sh['guid'];
          }else {
            $guid = @$shl['guid'];
          }
          $this->temp[] = array(
            'id' => @$sh['ID'],
            'post_date' => @$sh['post_date'],
            'post_content' => @$sh['post_content'],
            'post_title' => @$sh['post_title'],
            'guid' => $guid,
          );
        }





      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }

}
