<?php
class DbAction extends Config
{

  public function selectAll($data)
  {
    $host = $this->host;
    $dbname = $this->dbname;
    $user = $this->user;
    $pass = $this->pass;
    try {
      $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      $sql = "SELECT * FROM `rtl_lnd_gallery` WHERE `id`=?";
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $sh=$stmt->fetch();
      $content=explode("<!--more-->",@$sh['content']);
          $this->temp[] = array(
            'id' => @$sh['id'],
            'post_content' => @$content[0],
            'post_content_max' => @$content[1],
            'post_title' => @$sh['title'],
            'guid' => @$sh['Preview_image'],
          );
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }

}
