<?php
include_once '../../../kernel/config/config.php';
// include_once '../../../kernel/lib/GenerateSeoFriendlyURL.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$data = array(
    $checked->checkPost('id_user', 11, 'notNull'),
);
$output->selectAll_data($data);
