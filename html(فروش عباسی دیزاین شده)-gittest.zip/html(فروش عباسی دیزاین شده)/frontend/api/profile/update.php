<?php
include_once '../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
echo $_POST['id_buy'];
$data = array(
  // $checked->checkPost('blog_title', 200, 'notNull'),
  $checked->checkPost('name', 150, 'notNull'),
  $checked->checkPost('family', 150, 'notNull'),
  $checked->checkPost('password', 55, 'notNull'),
  // $checked->checkPost('transport_city', 200, 'notNull'),
  // $checked->checkPost('transport_state', 200, 'notNull'),
  // $checked->checkPost('panel_div_input', 200, 'notNull'),
  // $checked->checkPost('text_transport', 200, 'notNull'),
  // $checked->checkPost('white', 200, 'notNull'),
  // $checked->checkPost('add_Percent', 200, 'notNull'),


    $checked->checkPost('id_user', 15, 'notNull'),
  // ($checked->checkPost('min_content', 1500, 'notNull').
  // '<!--more-->'.
  // $checked->checkPost('max_content', 2500, 'notNull')),

);
$output->update_data($data);
