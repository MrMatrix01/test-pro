<?php
class DbAction extends Config
{
  // public function selectAll($data)
  // {
  //   try {
  //     $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
  //     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  //     $sql = "SELECT * FROM `rtl_order`";
  //     $stmt = $conn->prepare($sql);
  //     $stmt->execute();
  //     $sh=$stmt->fetchAll();
  //
  //
  //
  //
  //
  //     $sqll = "SELECT * FROM `add_price` WHERE `id`=1";
  //     $stmtl = $conn->prepare($sqll);
  //     $stmtl->execute();
  //     $shl=$stmtl->fetchAll();
  //
  //
  //     $sqlll = "SELECT * FROM `buy_castomer` WHERE `rtl_users_id`=?";
  //     $stmtll = $conn->prepare($sqlll);
  //     $stmtll->execute($data);
  //     $shll=$stmtll->fetchAll();
  //
  //     $this->temp=$sh;
  //     $this->temp2=$shl;
  //     $this->temp3=$shll;
  //     // foreach($sh as $key=>$value) {
  //     //   $this->temp[] = array(
  //     //     'id' => @$value['id'],
  //     //   );
  //     // }
  //     return 'noError';
  //   } catch (PDOException $e) {
  //     // echo $e->getMessage();
  //     return  'Error';
  //   }
  //   $conn = null;
  // }
  // public function insert($data)
  // {
  //   try {
  //     $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
  //     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  //     $sql = "INSERT INTO `buy_castomer` (`rtl_users_id`,`garma`,`cassette`,`size`,`first_color`,`second_color`,`print`,`form`,`handel`,`handel_color`,`number`,`price`)
  //     VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
  //     $stmt = $conn->prepare($sql);
  //     $stmt->execute($data);
  //     $id = $conn->lastInsertId();
  //     $sh = $stmt->fetch();
  //     $this->temp = array(
  //       "blog_id"=>$id,
  //     );
  //     return 'noError';
  //   } catch (PDOException $e) {
  //      echo $e->getMessage();
  //     return 'Error';
  //   }
  //   $conn = null;
  // }
  public function update($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'UPDATE `rtl_users` SET `name`=?,`family`=?,`password`=? WHERE `id`=?';
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
        return 'noError';
    } catch (PDOException $e) {
      return $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
}
