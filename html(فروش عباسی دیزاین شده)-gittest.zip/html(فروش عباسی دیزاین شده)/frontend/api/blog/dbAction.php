<?php
class DbAction extends Config
{
  public function selectAll($data)
  {
    $var='post';
    $var1='attachment';
    $var2='open';
    $var3='0';
    $a=12;
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8",$this->user,$this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      // $sql = "SELECT `a`.`ping_status`,`a`.`post_type`,`a`.`post_content`,`a`.`post_content`,`b`.`guid`,`a`.`post_title`,`a`.`ID`,`b`.`post_parent`,`a`.`post_type` as `a_post_type`
      // FROM `rtl_lnd_posts` `a` LEFT JOIN `rtl_lnd_posts` `b`
      //  ON `a`.`ID`=`b`.`post_parent` WHERE `a`.`post_type`='$var' AND `a`.`ping_status`='$var2' AND `b`.`post_parent`<>'$var3' ORDER BY `a`.`ID` DESC LIMIT 100";
      $sql = "SELECT * FROM `rtl_lnd_posts` WHERE `post_type`='$var'  ORDER BY `ID` DESC LIMIT $data[0],20";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();
      $sw = "SELECT * FROM  `rtl_lnd_posts` WHERE `post_type`='$var'";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count =  $qw->rowCount();
      foreach($sh as $key=>$value) {
        $sqll = "SELECT * FROM `rtl_lnd_posts` WHERE `post_type`='$var1'  AND `post_parent`=?";
        $stmtl = $conn->prepare($sqll);
        $stmtl->execute(array($value['ID']));
        $shl=$stmtl->fetch();
        $content=explode("<!--more-->",@$value['post_content']);
        if(!empty($shl['guid']) || $value['ID']>9199){
          if($value['ID']>9199){
            $guid = @$value['guid'];
            $urlObject = new GenerateSeoFriendlyURL($value['post_title'] , 9);
            $seo_url=$urlObject->getUrl();
          }else {
            $guid = @$shl['guid'];
            $seo_url=null;
          }
          if(empty($value['url'])){
            $value['url']=null;
          }
          $this->temp[] = array(
            'id' => @$value['ID'],
            'post_date' => @$value['post_date'],
            'post_content' => @$content[0],
            'post_title' => @$value['post_title'],
            'url' => @$value['url'],
            'guid' => $guid,
            'seo_url'=>$seo_url,
          );
        }
      }
      $this->temp2=array('blog_count' => $blog_count,);
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
  public function search($data)
  {
    $var='post';
    $var1='attachment';
    $var2='open';
    $var3='0';
    $a=12;
    $search=$data[1];


    $likeWord='';

      $searchWord = explode(' ' ,$search);
      foreach ($searchWord as $key => $value) {
        $likeWord=$likeWord."AND `post_title`  LIKE '%$value%'";
      }



    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8",$this->user,$this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      // $sql = "SELECT `a`.`ping_status`,`a`.`post_type`,`a`.`post_content`,`a`.`post_content`,`b`.`guid`,`a`.`post_title`,`a`.`ID`,`b`.`post_parent`,`a`.`post_type` as `a_post_type`
      // FROM `rtl_lnd_posts` `a` LEFT JOIN `rtl_lnd_posts` `b`
      //  ON `a`.`ID`=`b`.`post_parent` WHERE `a`.`post_type`='$var' AND `a`.`ping_status`='$var2' AND `b`.`post_parent`<>'$var3' ORDER BY `a`.`ID` DESC LIMIT 100";
      $sql = "SELECT * FROM `rtl_lnd_posts` WHERE `post_type`='$var' $likeWord ORDER BY `ID` DESC LIMIT $data[0],10";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();
      $sw = "SELECT * FROM `rtl_lnd_posts` WHERE `post_type`='$var' && `post_title`  LIKE '%$search%'";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count =  $qw->rowCount();
      foreach($sh as $key=>$value) {
        $sqll = "SELECT * FROM `rtl_lnd_posts` WHERE `post_type`='$var1'  AND `post_parent`=?";
        $stmtl = $conn->prepare($sqll);
        $stmtl->execute(array($value['ID']));
        $shl=$stmtl->fetch();
        $content=explode("<!--more-->",@$value['post_content']);
        if(!empty($shl['guid']) || $value['ID']>9199){
          if($value['ID']>9199){
            $guid = @$value['guid'];
            $urlObject = new GenerateSeoFriendlyURL($value['post_title'] , 9);
            $seo_url=$urlObject->getUrl();
          }else {
            $guid = @$shl['guid'];
            $seo_url=null;
          }
          if(empty($value['url'])){
            $value['url']=null;
          }
          $this->temp[] = array(
            'id' => @$value['ID'],
            'post_date' => @$value['post_date'],
            'post_content' => @$content[0],
            'url' => @$value['url'],
            'post_title' => @$value['post_title'],
            'guid' => $guid,
            'seo_url'=>$seo_url,
          );
        }
      }
      $this->temp2=array('blog_count' => $blog_count, );
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
}
