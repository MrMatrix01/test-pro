<?php
class DbAction extends Config
{
  public function selectAll($data)
  {
    $host = $this->host;
    $dbname = $this->dbname;
    $user = $this->user;
    $pass = $this->pass;
    try {
      $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      //---------------------slide----------------------------------
      $sm = "SELECT * FROM  `rtl_lnd_home_slide`";
      $qm = $conn->prepare($sm);
      $qm->execute();
      $shm=$qm->fetchAll();
      $blog_count_gallery =  $qm->rowCount();
      foreach($shm as $key=>$value) {
        // $contentm=explode("<!--more-->",@$value['content']);
        $urlObject = new GenerateSeoFriendlyURL($value['title'] , 9);
        $seo_url=$urlObject->getUrl();
        $slide[] = array(
          'id' => @$value['id'],
          // 'post_content' => @$content[0],
          'title' => @$value['title'],
          'content' => @$value['content'],
          'img_slide' => @$value['img_slide'],
          'seo_url' => @$seo_url,
        );
      }
      //---------------------why----------------------------------
      $smo = "SELECT * FROM  `rtl_lnd_why`";
      $qmo = $conn->prepare($smo);
      $qmo->execute();
      $shmo=$qmo->fetchAll();
      $blog_count_why =  $qmo->rowCount();
      foreach($shmo as $key=>$value) {
        // $contentm=explode("<!--more-->",@$value['content']);
        $urlObject = new GenerateSeoFriendlyURL($value['title'] , 9);
        $seo_url=$urlObject->getUrl();
        $why[] = array(
          'id' => @$value['id'],
          // 'post_content' => @$content[0],
          'title' => @$value['title'],
          'min_content' => @$value['min_content'],
          'max_content' => @$value['max_content'],
          'seo_url' => @$seo_url,
        );
      }
      //---------------------------about--------------------------------
      $idAbout=1;
      $sqlz = "SELECT * FROM `rtl_lnd_about` WHERE `id`='$idAbout'";
      $stmtz = $conn->prepare($sqlz);
      $stmtz->execute();
      $shz=$stmtz->fetch();
        $about[] = array(
          'min_content' => @$shz['min_content'],
        );

      //---------------------------gallery-------------------------------
      $sm = "SELECT * FROM  `rtl_lnd_gallery` ORDER BY `ID` DESC LIMIT 0,16";
      $qm = $conn->prepare($sm);
      $qm->execute();
      $shm=$qm->fetchAll();
      $blog_count_gallery =  $qm->rowCount();
      foreach($shm as $key=>$value) {
        // $contentm=explode("<!--more-->",@$value['content']);
        $urlObject = new GenerateSeoFriendlyURL($value['title'] , 9);
        $seo_url=$urlObject->getUrl();
        $gallery[] = array(
          'id' => @$value['id'],
          // 'post_content' => @$content[0],
          'gallery_title' => @$value['title'],
          'Preview_image' => @$value['Preview_image'],
          'seo_url' =>$seo_url,
        );
      }
      //---------------------------------article-------------------------
      $var='post';
      $var1='attachment';
      $var2='open';
      $var3='0';
      $a=12;
      $sql = "SELECT * FROM `rtl_lnd_posts` WHERE `post_type`='$var'  ORDER BY `ID` DESC LIMIT 0,16";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();
      $sw = "SELECT * FROM  `rtl_lnd_posts` WHERE `post_type`='$var'";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count_article =  $qw->rowCount();
      $count=0;
      foreach($sh as $key=>$value) {
        $sqll = "SELECT * FROM `rtl_lnd_posts` WHERE `post_type`='$var1'  AND `post_parent`=?";
        $stmtl = $conn->prepare($sqll);
        $stmtl->execute(array($value['ID']));
        $shl=$stmtl->fetch();
        $content=explode("<!--more-->",@$value['post_content']);
        if(!empty($shl['guid']) || $value['ID']>9199){
          $count++;
          if($value['ID']>9199){
            $guid = @$value['guid'];
            $urlObject = new GenerateSeoFriendlyURL($value['post_title'] , 9);
            $seo_url=$urlObject->getUrl();
          }else {
            $guid = @$shl['guid'];
            $seo_url='null';
          }
          if(empty($value['url'])){
            $value['url']=null;
          }
          $article[] = array(
            'id' => @$value['ID'],
            'post_date' => @$value['post_date'],
            'post_content' => @$content[0],
            'post_title' => @$value['post_title'],
            'url' => @$value['url'],
            'guid' => $guid,
            'seo_url'=>$seo_url,
          );
        }
      }
      //--------------------------final-------------------------------------
      $this->temp=array('gallery' => $gallery,'article'=>$article,'slide'=>$slide,'why'=>$why,'about'=>$about);
      $this->temp2=array('blog_count_gallery' => $blog_count_gallery,'blog_count_article' => $blog_count_article, );
      return 'noError';
    } catch (PDOException $e) {
      // eslidecho $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
}
