<?php
class DbAction extends Config
{

  public function selectAll($data)
  {
    $host = $this->host;
    $dbname = $this->dbname;
    $user = $this->user;
    $pass = $this->pass;
    try {
      $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      $sql = "SELECT * FROM `rtl_lnd_posts` WHERE `ID`=?";
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $sh=$stmt->fetch();
        $sqll = "SELECT * FROM `rtl_lnd_posts` WHERE `post_parent`=?";

        $stmtl = $conn->prepare($sqll);
        $stmtl->execute($data);
        $shl=$stmtl->fetch();
        $content=explode("<!--more-->",@$sh['post_content']);
        if(!empty($shl['guid']) || $sh['ID']>9199){
          if($sh['ID']>9199){
          $guid = @$sh['guid'];
          }else {
            $guid = @$shl['guid'];
          }
          $this->temp[] = array(
            'id' => @$sh['ID'],
            'post_date' => @$sh['post_date'],
            'post_content' => @$content[0],
            'post_content_max' => @$content[1],
            'post_title' => @$sh['post_title'],
            'guid' => $guid,
          );
        }





      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }

}
