<?php
class DbAction extends Config
{
  public function insert($data)
  {
    $var='post';
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO `rtl_lnd_comments_me` (`name`,`family`,`email`,`title`,`content`)
      VALUES(?,?,?,?,?)";
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $id = $conn->lastInsertId();
      $sh = $stmt->fetch();
      $this->temp = array(
        "blog_id"=>$id,
      );
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
}
