<?php
include_once '../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$salt = 'amniatMam';
$answer=md5($_POST['answer'].$salt);

if($answer==$_SESSION["pic"] && @$_SESSION['pic_old']!=$_SESSION["pic"]){
  $data = array(
    $checked->checkPost('name', 150, 'notNull'),
    $checked->checkPost('family', 150, 'notNull'),
    $checked->checkPost('email', 150, 'notNull'),
    $checked->checkPost('title', 200, 'notNull'),
    $checked->checkPost('content', 2500, 'notNull'),
    // $checked->checkPost('answer', 11, 'notNull'),
  );
  $_SESSION['pic_old']=$_SESSION["pic"];
  $output->insert_data(@$data);
}else{
  $output->error();
}
