<?php
class DbAction extends Config
{
  public function selectAll($data)
   {
     $id=1;
     try {
       $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
       $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       $sql = "SELECT * FROM `rtl_lnd_price_list` WHERE `id`='$id'";
       $stmt = $conn->prepare($sql);
       $stmt->execute();
       $sh=$stmt->fetch();

         $this->temp[] = array(
           'image' => @$sh['rtl_lnd_price_list'],
           'content' => @$sh['content'],
         );

       return 'noError';
     } catch (PDOException $e) {
       return  'Error';
     }
     $conn = null;
   }
}
