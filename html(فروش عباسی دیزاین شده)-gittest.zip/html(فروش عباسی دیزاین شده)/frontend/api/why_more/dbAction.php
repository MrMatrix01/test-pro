<?php
class DbAction extends Config
{

  public function selectAll($data)
  {
    $host = $this->host;
    $dbname = $this->dbname;
    $user = $this->user;
    $pass = $this->pass;
    try {
      $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      $sql = "SELECT * FROM `rtl_lnd_why` WHERE `id`=?";
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $sh=$stmt->fetch();
          $this->temp[] = array(
            'id' => @$sh['id'],
            'content' => @$sh['min_content'].@$sh['max_content'],
            'title' => @$sh['title'],
          );
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }

}
