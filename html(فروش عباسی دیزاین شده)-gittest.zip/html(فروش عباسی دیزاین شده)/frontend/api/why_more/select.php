<?php
include_once '../../../kernel/config/config.php';
$checked->checkUrl('blog_more/', $checkToken);
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$data = array(
  $checked->checkPost('blog_id', 11, 'notNull'),
);
$output->selectAll_data($data);
