<?php
class DbComputing extends Config{
  public function computing($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      $sqlll = "SELECT * FROM `rtl_order`  WHERE `gram`=? AND `cassette`=? AND `size`=? AND `form`=?";
      $stmtll = $conn->prepare($sqlll);
      $stmtll->execute([$data[1],$data[2],$data[3],$data[7]]);
      $shll=$stmtll->fetch();
      $final=@$shll['price'];







      $sqlla = "SELECT * FROM `add_price`  WHERE `id`=1";
      $stmtla = $conn->prepare($sqlla);
      $stmtla->execute();
      $shla=$stmtla->fetch();

        $final=$final+($final/100*$shla['add_Percent']);
   //    if ($data[4]=="خاکستری") {
   //     $final=$final+$shla['silver'];
   //   }elseif ($data[4]=="سبز") {
   //      $final=$final+$shla['phosphoric'];
   //
   //   }elseif ($data[4]=="طلایی") {
   //      $final=$final+$shla['golden'];
   //
   //   }elseif ($data[4]=="سفید") {
   //      $final=$final+$shla['white'];
   //
   // }elseif ($data[4]=="آبی" || $data[4]=="صورتی" || $data[4]=="بنفش" || $data[4]=="فیروزه ای" || $data[4]=="زرد" || $data[4]=="قرمز" || $data[4]=="سیاه" || $data[4]=="نارنجی" ) {
   //      $final=$final+$shla['price_first_color'];
   //   }

     if (!empty($data[5]) && $data[5]!=$data[4]) {
         $final=$final+$shla['choose_second_color'];

     }
   //    if ($data[5]=="خاکستری") {
   //     $final=$final+$shla['silver'];
   //   }elseif ($data[5]=="سبز") {
   //      $final=$final+$shla['phosphoric'];
   //
   // }elseif ($data[5]=="طلایی") {
   //      $final=$final+$shla['golden'];
   //
   // }elseif ($data[5]=="سفید") {
   //      $final=$final+$shla['white'];
   //
   // }elseif ($data[5]=="آبی" || $data[5]=="صورتی" || $data[5]=="بنفش" || $data[5]=="فیروزه ای" || $data[5]=="زرد" || $data[5]=="قرمز" || $data[5]=="سیاه" || $data[5]=="نارنجی" ) {
   //      $final=$final+$shla['price_second_color'];
   //   }

     if($data[8]=="دارد" && $data[1]=="60" ){
       $final=$final+$shla['zanbil_handel_60'];
     }elseif ($data[8]=="دارد" && $data[1]=="90") {
       $final=$final+$shla['zanbil_handel_90'];
     }elseif ($data[8]=="دارد" && $data[1]=="40") {
      $final=$final+$shla['zanbil_handel_40'];
     }
    //  if ($data[6]=='one') {
    //     $final=$final+$shla['print_one'];
    //  }
    // else if ($data[6]=='two') {
    //     $final=$final+$shla['print_two'];
    //  }
    //  if ($data[13]=="silver") {
    //       $final=$final+$shla['silver'];
    //  }elseif ($data[13]=="phosphor") {
    //       $final=$final+$shla['phosphoric'];
    //
    //  }elseif ($data[13]=="golden") {
    //       $final=$final+$shla['golden'];
    //
    //  }elseif ($data[13]=="white") {
    //       $final=$final+$shla['white'];
    //
    //  }
    if ($data[6]=='one') {

       if ($data[13]=="silver") {
            $final=$final+$shla['silver'];
       }elseif ($data[13]=="phosphor") {
            $final=$final+$shla['phosphoric'];

       }elseif ($data[13]=="golden") {
            $final=$final+$shla['golden'];

       }elseif ($data[13]=="white") {
            $final=$final+$shla['white'];

       }
       elseif ($data[13]=="nocolor") {
            $final=$final+$shla['print_one'];

       }
    }
   else if ($data[6]=='two') {
       // $final=$final+$shla['print_two'];

       if ($data[13]=="silver") {
            $final=$final+$shla['silver']+$shla['silver'];
       }elseif ($data[13]=="phosphor") {
            $final=$final+$shla['phosphoric']+$shla['phosphoric'];

       }elseif ($data[13]=="golden") {
            $final=$final+$shla['golden']+$shla['golden'];

       }elseif ($data[13]=="white") {
            $final=$final+$shla['white']+$shla['white'];

       }
       elseif ($data[13]=="nocolor") {
            $final=$final+$shla['print_one']+$shla['print_one'];

       }
    }
















     $final=$final*$data[10];
     return $final;
      // return 'noError';
    } catch (PDOException $e) {
      // exit($e->getMessage());
       // echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
}
class DbAction extends Config
{
  public function selectAll($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT * FROM `rtl_order`";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();


      $id_user=$data[0];


      $sqll = "SELECT * FROM `add_price` WHERE `id`=1";
      $stmtl = $conn->prepare($sqll);
      $stmtl->execute();
      $shl=$stmtl->fetchAll();


      $sqlll = "SELECT *,`buy_castomer`.`id` AS `buy_castomer_id` FROM `buy_castomer`LEFT JOIN `rtl_files_user` ON `rtl_files_user`.`id` = `buy_castomer`.`id_rtl_files_user` WHERE `rtl_users_id`=? ORDER BY `buy_castomer_id` DESC ";
      $stmtll = $conn->prepare($sqlll);
      $stmtll->execute([$id_user]);
      $shll=$stmtll->fetchAll();


      $sqlll7 = "SELECT *,`buy_castomer`.`id` AS `buy_castomer_id` FROM `buy_castomer`LEFT JOIN `rtl_files_user` ON `rtl_files_user`.`id` = `buy_castomer`.`id_rtl_files_user2` WHERE `rtl_users_id`=? ORDER BY `buy_castomer_id` DESC ";
      $stmtll7 = $conn->prepare($sqlll7);
      $stmtll7->execute([$id_user]);
      $shll7=$stmtll7->fetchAll();
// ..............................................
      $sqlll2 = "SELECT * FROM `rtl_users` WHERE `id`=?";
      $stmtll2 = $conn->prepare($sqlll2);
      $stmtll2->execute([$id_user]);
      $shll2=$stmtll2->fetchAll();


      $sw = "SELECT * FROM  `rtl_files_user` WHERE `parent`=? AND `id_rtl_users`=?";
      $qw = $conn->prepare($sw);
      $qw->execute([$data[2],$id_user]);
      $file_count=  $qw->rowCount();


      $sql5 = "SELECT * FROM `rtl_files_user` WHERE `parent`=? AND `id_rtl_users`=?  ORDER BY `id` DESC LIMIT $data[1],15";
      $stmt5 = $conn->prepare($sql5);
      $stmt5->execute([$data[2],$id_user]);
      $sh5=$stmt5->fetchAll();
      // echo "____";
      // echo $file_count;
      // echo "____";
      $this->temp=$sh;
      $this->temp2=$shl;
      $this->temp3=$shll;
      $this->temp4=$shll2;
      $this->temp5=$sh5;
      $this->temp7=$shll7;

        $this->temp6=array('file_count' => $file_count, );
      // foreach($sh as $key=>$value) {
      //   $this->temp[] = array(
      //     'id' => @$value['id'],
      //   );
      // }
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
  public function select($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// ..............................................

      $id_rtl_users=$_SESSION['id_user'];
      $sw = "SELECT * FROM  `rtl_files_user` WHERE `parent`='$data[0]'  AND `id_rtl_users`='$id_rtl_users'";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $file_count=  $qw->rowCount();

      $sql5 = "SELECT * FROM `rtl_files_user` WHERE `parent`='$data[0]'  AND `id_rtl_users`='$id_rtl_users'    ORDER BY `id` DESC";
      $stmt5 = $conn->prepare($sql5);
      $stmt5->execute();
      $sh5=$stmt5->fetchAll();


      if($data[0]!=0){
      $sql7 = "SELECT * FROM `rtl_files_user` WHERE `id`='$data[0]'  AND `id_rtl_users`='$id_rtl_users'   ORDER BY `id` DESC";
      $stmt7 = $conn->prepare($sql7);
      $stmt7->execute();
      $sh7=$stmt7->fetchAll();
    }else{
      $sql7 = "SELECT * FROM `rtl_files_user` WHERE `parent`='$data[0]'  AND `id_rtl_users`='$id_rtl_users'   ORDER BY `id` DESC";
      $stmt7 = $conn->prepare($sql7);
      $stmt7->execute();
      $sh7=$stmt7->fetchAll();
    }

      $this->temp5=$sh5;
      $this->temp7=$sh7;

        $this->temp6=array('file_count' => $file_count, );
      // foreach($sh as $key=>$value) {
      //   $this->temp[] = array(
      //     'id' => @$value['id'],
      //   );
      // }
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
  public function insert($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


      $sql = "INSERT INTO `rtl_transactions` (`authority`,`payment`,`price`)
      VALUES(?,?,?)";
      $stmt = $conn->prepare($sql);
      $stmt->execute([$data[1][0],$data[1][1],$data[2]]);
      $id = $conn->lastInsertId();
      // $sh = $stmt->fetch();



      foreach ($data[0] as $key => $value) {
        // code...
        if(!isset($value['selectImg'])){
          $selectImg=0;
        }else{
          $selectImg=(int)$value['selectImg']+0;
        }
        if(!isset($value['selectImg2'])){
          $selectImg2=0;
        }else{
          $selectImg2=(int)$value['selectImg2']+0;
        }

        // echo $data[3][$key];
      $sql2 = "INSERT INTO `buy_castomer` (`rtl_users_id`,`garma`,`cassette`,`size`,`first_color`,`second_color`,`print`,`form`,`handel`,`handel_color`,`number`,`price`,`id_rtl_files_user`,`authority`,`title`,`print_color`,`description`,`id_rtl_files_user2`,`id_rtl_transactions`)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      $stmt2 = $conn->prepare($sql2);
      $stmt2->execute([$_SESSION['id_user'],@$value['gram'],@$value['cassette'],@$value['textSize'],@$value['firstColor'],@$value['secondColor'],@$value['textPrint'],@$value['form'],@$value['handle'],@$value['handleColor'],@$value['number'],$data[3][$key],$selectImg,$data[1][0],@$value['nameBuy'],@$value['textPrintColor'],@$value['descriptionPrint'],$selectImg2,$id]);
      // $id = $conn->lastInsertId();
      // $sh = $stmt->fetch();
      $this->temp = array(
        "blog_id"=>$id,
      );
          }

// exit();






      return 'noError';
    } catch (PDOException $e) {
      // exit($e->getMessage());
      echo "+++++++++";
       echo $e->getMessage();
       echo "+++++";
      return 'Error';
    }
    $conn = null;
  }
  public function update($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'UPDATE `buy_castomer` SET `mobile`=?,`mobile2`=?,`phone`=?,`city`=?,`state`=?,`address`=?,`transport`=? WHERE `id`=?';
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
        return 'noError';
    } catch (PDOException $e) {
      return 'Error';
    }
    $conn = null;
  }
}
