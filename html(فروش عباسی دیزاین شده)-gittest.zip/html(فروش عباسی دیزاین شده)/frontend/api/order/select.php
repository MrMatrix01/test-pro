<?php
include_once '../../../kernel/config/config.php';
// include_once '../../../kernel/lib/GenerateSeoFriendlyURL.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$data = array(
    $checked->checkPost('id_folder', 11, 'null'),
);
$output->select_data($data);
