<?php
session_start();

class Config
{
    // protected $host = '127.0.0.1';
    // protected $dbname = 'parscover_vahid';
    // protected $user = 'root';
    // protected $pass = 'iranpars';

    protected $host = '127.0.0.1';
    protected $dbname = 'parscover_vahid2';
    protected $user = 'parscover_vahid';
    protected $pass = 'VaHiD61374568';
}
include_once 'dbAction.php';
$dbAction=NEW DbAction();
$callback_url="https://iranbag.ir/kernel/gute/zarin/verify.php";
// $callback_url="http://localhost/kernel/gute/zarin/verify.php";
 ?>
