<?php
include_once '../../../kernel/config/config.php';
// include_once '../../../kernel/lib/GenerateSeoFriendlyURL.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$id_page=((int)$checked->checkPost('id_page', 11, 'notNull')-1)*15;
$data = array(
    $_SESSION['id_user'],
    $id_page,
    $checked->checkPost('parent', 11, 'null'),
);
$output->selectAll_data($data);
