<?php
include_once 'config.php';
include_once '../../../kernel/firewall/checked.php';
include_once '../../../kernel/lib/uploads.php';


$json_all_buy=$_POST['input-all-buy-hidden'];
$json_all_buy=json_decode($json_all_buy,true);

// var_dump($json_all_buy);
// exit();


$valid_formats = array('jpg', 'png', 'jpeg', 'PNG', 'JPG');
$max_file_size = 1024 * 1024 * 10; //100 kb
$path = '../../../uploads/'; // Upload directory
// $path = '../../../files/'; // Upload directory
// $path2='/uploads/';
// $json_all_buy=$_POST['json_all_buy'];
// $json_all_buy=json_decode($json_all_buy,true);
$uploads=New Uploads();
  $uploads->upload($max_file_size, $path, $valid_formats);
  $fileNew = $uploads->file;
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$salt = 'amniatMam';
$answer=md5($_POST['answer'].$salt);
// if($checked->checkPost('number', 11, 'notNull')>=1000){

if($answer==$_SESSION["pic"] && @$_SESSION['pic_old']!=$_SESSION["pic"]){


  $dbComputing=new DbComputing();
$amountAll=0;
  foreach ($json_all_buy as $key => $value) {


  $amount=$dbComputing->computing(
    [
      $_SESSION['id_user'],
      @$value['gram'],
      @$value['cassette'],
      @$value['textSize'],
      @$value['firstColor'],
      @$value['secondColor'],
      @$value['textPrint'],
      @$value['form'],
      @$value['handle'],
      @$value['handleColor'],
      @$value['number'],
      $checked->checkPost('hidden-id', 11, 'notNull'),
      @$result['data']["authority"],
      @$value['textPrintColor'],
      @$value['nameBuy'],


      // $_SESSION['id_user'],
      // $checked->checkPost('gram', 70, 'notNull'),
      // $checked->checkPost('cassette', 70, 'notNull'),
      // $checked->checkPost('size', 70, 'notNull'),
      // $checked->checkPost('first-color', 70, 'notNull'),
      // $checked->checkPost('second-color', 70, 'notNull'),
      // $checked->checkPost('print', 70, 'null'),
      // // $fileNew[0],
      // $checked->checkPost('form', 70, 'notNull'),
      // $checked->checkPost('handle', 70, 'notNull'),
      // $checked->checkPost('handle-color', 70, 'notNull'),
      // $checked->checkPost('number', 11, 'notNull'),
      // // $checked->checkPost('price', 11, 'notNull'),
      // $checked->checkPost('hidden-id', 11, 'notNull'),
      // $result['data']["authority"],
      // $checked->checkPost('print-color', 70, 'null'),

  ]
  );
$amountAll=$amountAll+$amount;
$final1[]=$amount;
}

$amount=$amountAll;
// $amount=100000;

// echo $amountAll;
// exit();



  // $amount=$checked->checkPost('price', 11, 'notNull');
  $mobile=$_SESSION['username'];
  include_once '../../../kernel/gute/zarin/request.php';

// var_dump($result);

  if ($err) {
      echo "cURL Error #:" . $err;
  } else {

      if (empty($result['errors'])) {
          if ($result['data']['code'] == 100) {
              // var_dump($json_all_buy);

// echo $value['textPrintColor'];
              // $hidden_id_file=0+$checked->checkPost('hidden-id-file', 11, 'null');
              // $hidden_id_file2=0+$checked->checkPost('hidden-id-file2', 11, 'null');


              $data = array(

                  // $_SESSION['id_user'],
                  // @$value['gram'],
                  // @$value['cassette'],
                  // @$value['textSize'],
                  // @$value['firstColor'],
                  // @$value['secondColor'],
                  // @$value['textPrint'],
                  // @$value['form'],
                  // @$value['handle'],
                  // @$value['handleColor'],
                  // @$value['number'],
                  // $amount,
                  // 1,
                  // $result['data']["authority"],
                  // @$value['nameBuy'],
                  // @$value['textPrintColor'],
                  // @$value['descriptionPrint'],
                  // 1,
                  $json_all_buy,

                [
                  $result['data']["authority"],
                  1,
                  // $checked->checkPost('price', 11, 'notNull'),
                ],

                  $amount,
                  $final1

              );
              // var_dump($data);
              $dbAction->insert(@$data);
              // exit();
              ?>
              <meta http-equiv='refresh' content='0; URL=https://www.zarinpal.com/pg/StartPay/<?php echo $result["data"]["authority"]; ?>' />

              <?php
          }
      }
      else {
           echo'Error Code: ' . $result['errors']['code'];
           echo'message: ' .  $result['errors']['message'];

      }
  }
  $_SESSION['pic_old']=$_SESSION["pic"];
}
// }
