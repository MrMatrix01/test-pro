<?php
include_once '../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$data = array(
  $checked->checkPost('phone', 20, 'notNull'),
  $checked->checkPost('phone_pass', 11, 'notNull'),
  // 0,
);
$update_token_client = array(
  $checked->checkPost('token_client', 100, 'notNull'),
);
$output->login($data, $update_token_client);
