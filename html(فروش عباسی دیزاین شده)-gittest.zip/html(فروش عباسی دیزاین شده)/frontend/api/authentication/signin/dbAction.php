<?php
class DbAction extends Config
{
  public function insert($data)
  {
    $var='post';
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);



      $sql = 'SELECT * FROM `rtl_users` WHERE `username`=?';

      $stmt = $conn->prepare($sql);
      $stmt->execute([$data[0]]);
      $this->count = $stmt->rowCount();
      $sh = $stmt->fetch();
      if($this->count==1){




        $sql = "UPDATE `rtl_users` SET `phone_pass`=? WHERE `username`=?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$data[1],$data[0]]);


        $this->temp = array(
          "blog_id"=>$sh['id'],
        );



      }else {


        $sql2 = "INSERT INTO `rtl_users` (`username`,`phone_pass`)
        VALUES(?,?)";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->execute($data);
        $id = $conn->lastInsertId();
        $sh2 = $stmt2->fetch();
        $this->temp = array(
          "blog_id"=>$id,
        );




      }










      return 'noError';
    } catch (PDOException $e) {
       echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }


  public function select($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


      $sql = 'SELECT * FROM `rtl_users` WHERE `username`=? AND `phone_pass`=?';

      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $this->count = $stmt->rowCount();
      $sh = $stmt->fetch();

      if($this->count==1){
        $this->id=@$sh['id'];
        $_SESSION['username']=$data[0];
        $_SESSION['id_user']=$sh['id'];
        $this->temp = array(
          "blog_id"=>$sh['id'],
        );
      }














      return 'noError';
    } catch (PDOException $e) {
      return  'Error';
    }
    $conn = null;
  }
}
