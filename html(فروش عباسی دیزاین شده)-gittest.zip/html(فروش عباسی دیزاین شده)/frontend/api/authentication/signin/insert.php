<?php

include_once '../../../../kernel/config/config.php';


$phone_singin=$checked->checkPost('phone', 20, 'notNull');
$phone_pass=(rand(1000,9999));
include_once '../../../../kernel/sms/send_sms.php';

//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
// $salt = 'amniatMam';
// $answer=md5($_POST['answer'].$salt);
// if($answer==$_SESSION["pic"] && @$_SESSION['pic_old']!=$_SESSION["pic"]){
  $data = array(
    // $checked->checkPost('username', 100, 'notNull'),
    $checked->checkPost('phone', 20, 'notNull'),
    $phone_pass,
    // $checked->checkPost('name', 100, 'notNull'),
    // $checked->checkPost('family', 150, 'notNull'),
    // $checked->checkPost('email', 200, 'notNull'),
    // $checked->checkPost('password', 250, 'notNull'),
    // $checked->checkPost('address', 500, 'notNull'),
    // $checked->checkPost('answer', 11, 'notNull'),
  );
//   $_SESSION['pic_old']=$_SESSION["pic"];
// }
$output->insert_data(@$data);
