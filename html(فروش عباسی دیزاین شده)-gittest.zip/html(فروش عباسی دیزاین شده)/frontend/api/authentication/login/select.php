<?php
include_once '../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$salt = 'amniatMam';
$answer=md5($_POST['answer'].$salt);
if($answer==$_SESSION["pic"] && @$_SESSION['pic_old']!=$_SESSION["pic"]){
  $data = array(
    $checked->checkPost('phone', 100, 'notNull'),
    $checked->checkPost('password', 150, 'notNull'),
  );
  $update_token_client = array(
    $checked->checkPost('token_client', 100, 'notNull'),
  );
  $_SESSION['pic_old']=$_SESSION["pic"];
  $output->login($data, $update_token_client);
}else{
  $output->error();
}
