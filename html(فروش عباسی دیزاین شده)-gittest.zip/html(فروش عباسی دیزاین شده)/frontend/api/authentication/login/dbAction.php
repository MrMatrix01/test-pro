<?php
class DbAction extends Config
{
  public function select($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'SELECT * FROM `rtl_users` WHERE `username`=? && `password`=?';

      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $this->count = $stmt->rowCount();
      $sh = $stmt->fetch();

      if($this->count==1){
        $this->id=@$sh['id'];
        $_SESSION['username']=$data[0];
        $_SESSION['id_user']=$sh['id'];
        $this->temp = array(
          "blog_id"=>$sh['id'],
        );












      }

      return 'noError';
    } catch (PDOException $e) {
      return  'Error';
    }
    $conn = null;
  }
}
?>
