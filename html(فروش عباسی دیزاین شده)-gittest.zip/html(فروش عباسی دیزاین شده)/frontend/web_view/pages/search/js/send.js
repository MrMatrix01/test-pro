var searchUrl=getParameterByName('search');
function select() {
    // var username = document.getElementById("username").value;
    // var password = document.getElementById("password").value;
    var token = document.getElementById("token").value;
    var rnd = Math.random();
    var url = countBack+"frontend/api/blog/search.php?id=" + rnd +"&blog_id="+urlId+"&search_value="+searchUrl+"&token_client=" + token;
    postRequest(url);
}
