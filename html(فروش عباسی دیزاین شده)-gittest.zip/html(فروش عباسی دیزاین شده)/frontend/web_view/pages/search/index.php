<main>
  <div class="blog" id="blog">
    <div id="receive">
    <div class="blog-content" id="blog-content">
      <img src="api/uploads/parsgraphic-office-1.jpg" class="blog-img" alt="">
      <div class="blog-div">
        <a href="#" class="blog-a">
          <h1 class="blog-h4"></h1>
        </a>
        <div class="blog-p">
        </div>
      </div>
      <!-- <a href="blog_more/" class="blog-a">
        ادامه مطلب>>
      </a> -->
    </div>
    </div>
  </div>
  <div id="blog-page-number">
    <div class="row1">
    </div>
    <div class="row1">
    </div>
    <div class="row1">
    </div>
    <!-- <div id="row2">
    </div>
    <div id="row3">
    </div> -->
  </div>
  <div id="result">

  </div>
</main>
