<?php onload('frontend/api/about/select.php');?>
<main>
  <div class="about">
    <div class="about-content">
      <h3 class="about-h3">درباره ما</h3>
      <div id="about-all">

      </div>
    </div>
  </div>
</main>
