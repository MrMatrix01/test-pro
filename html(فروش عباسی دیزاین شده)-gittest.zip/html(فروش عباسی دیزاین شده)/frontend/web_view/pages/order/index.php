<?php
if (isset($_SESSION['id_user'])) {
  // $post=[
  //   'id_user'=>$_SESSION['id_user'],
  //   'id_page'=>1,
  //   'parent'=>0,
  // ];
  // onload('frontend/api/order/select_all.php',$post);
?>
  <main>
    <div class="warpper">
      <input class="radio" id="one" name="group" type="radio" checked>
      <input class="radio" id="two" name="group" type="radio">
      <input class="radio" id="three" name="group" type="radio">
      <input class="radio" id="four" name="group" type="radio">
      <input class="radio" id="fiv" name="group" type="radio">
      <input class="radio" id="six" name="group" type="radio">
      <div class="tabs">
        <label class="tab-1" id="one-tab" for="one">ثبت خرید</label>
        <label class="tab-1" id="two-tab" for="two">درخواست ارسال </label>
        <label style="display: none;" class="tab-1" id="three-tab" for="three">Prerequisites</label>
        <label class="tab-1" id="fiv-tab" for="fiv">سفارشات</label>
        <label class="tab-1" id="six-tab" for="six">صورت حساب</label>
        <label class="tab-1" id="four-tab" for="four">حساب کاربری</label>
      </div>
      <div class="about1">
        <div class="panels">
          <div id="blur">
            <div class="show-select-file">
              <i class="fa fa-close close-blur" onclick="closeBlur()"></i>
              <div id="back">

              </div>
              <form class="upload-image" action="index.html" method="post" enctype="multipart/form-data" name="myForm">
                <div class="div-select-file">
                  <label for="file-upload">انتخاب تصویر:</label>
                  <input type="file" id="file-upload" value="انتخاب تصویر" class="input-f" accept="image/*">
                  <button type="button" class="pic-button" name="button" onclick="uploadImage()">بارگذاری تصویر</button>
                </div>
                <div class="div-select-file">
                  <input type="text" name="name-folder" id="name-folder" class="name-folder" value="" placeholder="نام پوشه">
                  <button type="button" class="pic-button" name="button" onclick="creatFolder()">ساخت پوشه</button>
                </div>

                <div id="blog-page-number">
                  <div class="row1">
                  </div>
                  <div class="row1">
                  </div>
                  <div class="row1">
                  </div>
                  <!-- <div id="row2">
              </div>
              <div id="row3">
              </div> -->
                </div>
              </form>
              <div class="scroll-child">
                <div id="box-gallery">
                </div>
              </div>
            </div>
          </div>
          <div class="panel" id="one-panel">
            <div class="about-content" onclick="closeColorUser()">
              <h2 class="about-h3">ثبت فروش</h2>

              <div id="about-all">
                <div class="float_right">
                  <div class="row-comment">
                    <div class="garma-div">
                      <div class="titr-order">
                        گرماژ:
                      </div>
                      <div>
                        <input type="radio" name="gram" value="40" id="innormal" onclick="gramColor('40')" class="input-hidden" />
                        <label for="innormal">
                          <div class="img-garma-40">
                            <h2>40</h2>
                          </div>
                          </label>
                        <input type="radio" name="gram" value="60" id="sad" onclick="gramColor('60')" class="input-hidden" />
                        <label for="sad">
                          <div class="img-garma-60">
                            <h2>60</h2>
                          </div>
                          </label>
                          <input type="radio" name="gram" value="90" id="happy" onclick="gramColor('90')" class="input-hidden" />
                          <label for="happy">
                            <div class="img-garma-90">
                              <h2>90</h2>
                            </div>
                          </label>
                          <!-- <input type="radio" name="gram" value="90" id="happy" class="input-hidden" />
                  <label for="happy">
                    <img src="<?= @$countBack ?>frontend/web_view/themes/images/90.png" alt="I'm happy" class="img-garma" />
                  </label> -->
                      </div>
                    </div>
                  </div>
                  <div class="row-comment">
                    <div class="garma-div">
                      <div class="titr-order-1">
                        کاست:
                      </div>
                      <div class="kaset-div">
                        <input type="radio" name="cassette" id="a" class="input-hidden" value="بدون کاست" />
                        <label for="a">
                          <div class="test-div-three-right">
                            <img class="kaset-img" src="<?= $countBack ?>frontend/web_view/themes/images/01.png" alt="" />
                          </div>
                        </label>
                        <input type="radio" name="cassette" id="b" class="input-hidden" value="کف کاست" />
                        <label for="b">
                          <div class="test-div-three-center">
                            <img class="kaset-img" src="<?= $countBack ?>frontend/web_view/themes/images/03.png" alt="" />
                          </div>
                        </label>
                        <input type="radio" name="cassette" id="c" class="input-hidden" value="سه طرف کاست" />
                        <label for="c">
                          <div class="test-div-three-left">
                            <img class="kaset-img" src="<?= $countBack ?>frontend/web_view/themes/images/06.png" />
                          </div>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="row-comment">
                    <div class="garma-div">
                      <div class="titr-order">
                        اندازه:
                      </div>
                      <div>
                        <select class="select-order select-order2" name="size" id="size">
                          <option value="20*25">20 &times; 25</option>
                          <option value="20*30">20 &times; 30</option>
                          <option value="25*30">25 &times; 30</option>
                          <option value="25*35">25 &times; 35</option>
                          <option value="30*30">30 &times; 30</option>
                          <option value="30*35">30 &times; 35</option>
                          <option value="30*40">30 &times; 40</option>
                          <option value="35*35">35 &times; 35</option>
                          <option value="35*40">35 &times; 40</option>
                          <option value="35*45">35 &times; 45</option>
                          <option value="40*40">40 &times; 40</option>
                          <option value="40*45">40 &times; 45</option>
                          <option value="40*50">40 &times; 50</option>
                          <option value="45*45">45 &times; 45</option>
                          <option value="45*50">45 &times; 50</option>
                          <option value="45*55">45 &times; 55</option>
                          <option value="50*50">50 &times; 50</option>
                          <option value="50*55">50 &times; 55</option>
                          <option value="55*55">55 &times; 55</option>
                          <option value="50*60">50 &times; 60</option>
                          <option value="55*60">55 &times; 60</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="row-comment">
                    <div class="garma-div">
                      <div class="titr-order">
                        رنگ بگ:
                      </div>
                      <div>
                        <div class="dropdown-order">
                          <input type="button" onclick="myDropdownOrder()" class="dropbtn-order" id="dropbtnOrderUser1"name="" value="رنگ اول:">
                          <div id="myDropdownOrder" class="dropdown-order-content">
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="نخودی" id="i1" class="input-hidden" />
                              <label class="coloriii" for="i1">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/001.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="زرد روشن" id="i2" class="input-hidden" />
                              <label class="coloriii" for="i2">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/002.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="زرد پرتغالی" id="i3" class="input-hidden" />
                              <label class="coloriii" for="i3">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/003.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="نارنجی" id="i4" class="input-hidden" />
                              <label class="coloriii" for="i4">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/004.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="زرشکی" id="i5" class="input-hidden" />
                              <label class="coloriii" for="i5">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/006.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="قرمز" id="i6" class="input-hidden" />
                              <label class="coloriii" for="i6">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/005.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="قهوه ای" id="i7" class="input-hidden" />
                              <label class="coloriii" for="i7">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/007.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="کرم" id="i8" class="input-hidden" />
                              <label class="coloriii" for="i8">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/008.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="سورمه ای" id="i9" class="input-hidden" />
                              <label class="coloriii" for="i9">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/009.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="کربنی تیره" id="i22" class="input-hidden" />
                              <label class="coloriii" for="i22">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/100.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="کربنی روشن" id="i10" class="input-hidden" />
                              <label class="coloriii" for="i10">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/11.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="آبی" id="i11" class="input-hidden" />
                              <label class="coloriii" for="i11">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/12.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="فیروزه ای" id="i13" class="input-hidden" />
                              <label class="coloriii" for="i13">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/13.jpg" alt="" />
                              </label>
                            </div>





                            <div style="float:right;">
                              <input type="radio" name="first-color" value="مشکی" id="i14" class="input-hidden" />
                              <label class="coloriii" for="i14">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/14.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="سفید" id="i15" class="input-hidden" />
                              <label class="coloriii" for="i15">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/15.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="نقره ای" id="i16" class="input-hidden" />
                              <label class="coloriii" for="i16">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/16.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="یاسی" id="i17" class="input-hidden" />
                              <label class="coloriii" for="i17">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/17.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="طوسی" id="i18" class="input-hidden" />
                              <label class="coloriii" for="i18">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/18.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="صورتی" id="i19" class="input-hidden" />
                              <label class="coloriii" for="i19">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/19.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="یشمی" id="i20" class="input-hidden" />
                              <label class="coloriii" for="i20">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/200.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="first-color" value="سبز" id="i21" class="input-hidden" />
                              <label class="coloriii" for="i21">
                                <img class="color-order first-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/21.jpg" alt="" />
                              </label>
                            </div>












                          </div>
                        </div>
                        <div class="dropdown-order-two">
                          <input type="button" onclick="myDropdownOrderTwo()" class="dropbtn-order-two" id="dropbtnOrderUser1-3" value="رنگ دوم:">
                          <div id="myDropdownOrderTwo" class="dropdown-order-two-content">
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="نخودی" id="j1" class="input-hidden" />
                              <label class="colorjjj" for="j1">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/001.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="زرد روشن" id="j2" class="input-hidden" />
                              <label class="colorjjj" for="j2">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/002.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="زرد پرتغالی" id="j3" class="input-hidden" />
                              <label class="colorjjj" for="j3">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/003.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="نارنجی" id="j4" class="input-hidden" />
                              <label class="colorjjj" for="j4">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/004.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="زرشکی" id="j5" class="input-hidden" />
                              <label class="colorjjj" for="j5">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/006.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="قرمز" id="j6" class="input-hidden" />
                              <label class="colorjjj" for="j6">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/005.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="قهوه ای" id="j7" class="input-hidden" />
                              <label class="colorjjj" for="j7">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/007.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="کرم" id="j8" class="input-hidden" />
                              <label class="colorjjj" for="j8">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/008.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="سورمه ای" id="j9" class="input-hidden" />
                              <label class="colorjjj" for="j9">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/009.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="کربنی تیره" id="j22" class="input-hidden" />
                              <label class="colorjjj" for="j22">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/100.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="کربنی روشن" id="j10" class="input-hidden" />
                              <label class="colorjjj" for="j10">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/11.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="آبی" id="j11" class="input-hidden" />
                              <label class="colorjjj" for="j11">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/12.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="فیروزه ای" id="j13" class="input-hidden" />
                              <label class="colorjjj" for="j13">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/13.jpg" alt="" />
                              </label>
                            </div>








                            <div style="float:right;">
                              <input type="radio" name="second-color" value="مشکی" id="j14" class="input-hidden" />
                              <label class="colorjjj" for="j14">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/14.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="سفید" id="j15" class="input-hidden" />
                              <label class="colorjjj" for="j15">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/15.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="نقره ای" id="j16" class="input-hidden" />
                              <label class="colorjjj" for="j16">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/16.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="یاسی" id="j17" class="input-hidden" />
                              <label class="colorjjj" for="j17">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/17.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="طوسی" id="j18" class="input-hidden" />
                              <label class="colorjjj" for="j18">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/18.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="صورتی" id="j19" class="input-hidden" />
                              <label class="colorjjj" for="j19">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/19.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="یشمی" id="j20" class="input-hidden" />
                              <label class="colorjjj" for="j20">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/200.jpg" alt="" />
                              </label>
                            </div>
                            <div style="float:right;">
                              <input type="radio" name="second-color" value="سبز" id="j21" class="input-hidden" />
                              <label class="colorjjj" for="j21">
                                <img class="color-order second-color-user" src="<?= $countBack ?>frontend/web_view/themes/images/21.jpg" alt="" />
                              </label>
                            </div>














                            <div style="float:right;">
                              <input type="radio" name="second-color" value="قرمز" id="j23" class="input-hidden" />
                              <label for="j23">
                                <!-- <img class="color-order second-color-user" onclick="noneColor()" src="<?= $countBack ?>frontend/web_view/themes/images/a12.png" alt="" /> -->
                                <i class="fa fa-trash color-order" style="padding-right: 7px;color: #E91E63;" onclick="noneColor()"></i>
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="rangbag-div">
                        <div id="color-1">

                        </div>
                        <div id="color-2">

                        </div>
                        <div id="color-3">

                        </div>

                        <img src="<?= $countBack ?>frontend/web_view/themes/images/Rectangle-62.png" class="rangbag-img" alt="">
                      </div>
                    </div>
                  </div>
                  <div class="row-comment">
                    <div class="garma-div">
                      <div class="titr-order">
                        آیا نیاز به چاپ دارد؟
                      </div>
                      <select class="select-order" id="print" name="print" style="width: 144px;">
                        <option name="no" value="no">نیاز به چاپ ندارم</option>
                        <option value="one">یک طرف چاپ</option>
                        <option value="two">دو طرف چاپ</option>
                      </select>
                    </div>
                    <div class="garma-div" id="ask-print" style="display:none;">
                      <div class="titr-order">
                        رنگ چاپ:
                      </div>
                      <select class="select-order" id="print-color" onchange="changeDescription()" name="print-color">
                        <option value="nocolor">معمولی</option>
                        <option value="silver">نقره ای</option>
                        <option value="golden">طلایی</option>
                        <option value="white">سفید اوربیت</option>
                        <option value="phosphor">فسفری</option>
                      </select>
                      <input type="text" class="description-print" id="description-print" name="description-print" value="" placeholder="رنگ چاپ">
                    </div>
                  </div>
                  <div class="row-comment">
                    <div class="garma-div" id="upload-img" style="display:none;">
                      <div class="titr-order">
                        آپلود طرح جهت چاپ:
                      </div>
                      <div class="">
                        <button type="button" name="button" class="select-file" onclick="selectFile(1)">آپلود طرح</button>
                        <button id="upload-img2" type="button" name="button2" class="select-file" onclick="selectFile(2)">طرح دوم</button>
                        <!-- <input type="file" id="file-upload" value="" class="input" style="background-color: #c4c4c4;
                border: solid 1px #d2d2d2;
                height: 25px;
                width: 200px;
                font-size: 14px;
                border-radius: 3px;"  accept="image/*">
                <label for="file-upload">
                    <div class="input-file">
                      آپلود فایل
                    </div>
                </label> -->
                      </div>
                    </div>
                    <div class="garma-div">
                      <img src="" id="image-name" alt="">
                      <img src="" id="image-name2" alt="">
                      <input type="hidden" name="hidden-id-file" id="hidden-id-file" value="">
                      <input type="hidden" name="hidden-id-file2" id="hidden-id-file2" value="">
                    </div>

                    <div class="titr-order">
                      <div class="mablagh">
                        عنوان سفارش:
                      </div>
                      <input type="text" class="select-buy" id="title-buy" name="title-buy" value="" required oninvalid="setCustomValidity('عنوان را وارد کنید')" oninput="setCustomValidity('')">
                    </div>
                  </div>
                </div>
                <div class="float_left">
                  <div class="row-comment">
                    <div class="garma-div">
                      <div class="titr-order-1">
                        فرم:
                      </div>
                      <div class="form-div">
                        <input type="radio" name="form" value="عمودی" id="d1" class="input-hidden" />
                        <label for="d1">
                          <div class="test-div-1">
                            <img class="kaset-img-form" src="<?= $countBack ?>frontend/web_view/themes/images/01.png" alt="" />
                          </div>
                        </label>
                        <input type="radio" name="form" value="افقی" id="d2" class="input-hidden" />
                        <label for="d2">
                          <div class="test-div-2">
                            <img class="form-img" src="<?= $countBack ?>frontend/web_view/themes/images/02.png" alt="" />
                          </div>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="row-comment">
                    <div class="garma-div">
                      <div class="titr-order-1">
                        دسته:
                      </div>
                      <div class="form-div">
                        <input type="radio" name="handle" id="c1" value="دارد" class="input-hidden" />
                        <label for="c1">
                          <div class="test-div">
                            <img class="kaset-img" src="<?= $countBack ?>frontend/web_view/themes/images/01.png" alt="" />
                          </div>
                        </label>
                        <input type="radio" name="handle" id="c2" value="ندارد" class="input-hidden" />
                        <label for="c2">
                          <div class="test-div-daste">
                            <img class="kaset-daste" src="<?= $countBack ?>frontend/web_view/themes/images/04.png" alt="" />
                          </div>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="row-comment" style="display: none;" id="style-handel-color">
                    <div class="garma-div">
                      <div class="titr-order">
                        رنگ دسته
                      </div>
                      <div class="dropdown-order-two">
                        <input type="button" onclick="myDropdownOrderHandle()" class="dropbtn-order-two" id="dropbtnOrderUser1-1" value="انتخاب">
                        <div id="myDropdownOrderHandle" class="dropdown-order-two-content">
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="نخودی" id="k1" class="input-hidden" />
                            <label class="colorkkk" for="k1">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/001.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="زرد روشن" id="k2" class="input-hidden" />
                            <label class="colorkkk" for="k2">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/002.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="زرد پرتغالی" id="k3" class="input-hidden" />
                            <label class="colorkkk" for="k3">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/003.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="نارنجی" id="k4" class="input-hidden" />
                            <label class="colorkkk" for="k4">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/004.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="زرشکی" id="k5" class="input-hidden" />
                            <label class="colorkkk" for="k5">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/006.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="قرمز" id="k6" class="input-hidden" />
                            <label class="colorkkk" for="k6">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/005.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="قهوه ای" id="k7" class="input-hidden" />
                            <label class="colorkkk" for="k7">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/007.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="کرم" id="k8" class="input-hidden" />
                            <label class="colorkkk" for="k8">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/008.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="سورمه ای" id="k9" class="input-hidden" />
                            <label class="colorkkk" for="k9">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/009.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="کربنی تیره" id="k22" class="input-hidden" />
                            <label class="colorkkk" for="k22">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/100.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="کربنی روشن" id="k10" class="input-hidden" />
                            <label class="colorkkk" for="k10">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/11.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="آبی" id="k11" class="input-hidden" />
                            <label class="colorkkk" for="k11">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/12.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="فیروزه ای" id="k13" class="input-hidden" />
                            <label class="colorkkk" for="k13">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/13.jpg" alt="" />
                            </label>
                          </div>




                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="مشکی" id="k14" class="input-hidden" />
                            <label class="colorkkk" for="k14">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/14.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="سفید" id="k15" class="input-hidden" />
                            <label class="colorkkk" for="k15">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/15.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="نقره ای" id="k16" class="input-hidden" />
                            <label class="colorkkk" for="k16">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/16.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="یاسی" id="k17" class="input-hidden" />
                            <label class="colorkkk" for="k17">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/17.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="طوسی" id="k18" class="input-hidden" />
                            <label class="colorkkk" for="k18">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/18.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="صورتی" id="k19" class="input-hidden" />
                            <label class="colorkkk" for="k19">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/19.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="یشمی" id="k20" class="input-hidden" />
                            <label class="colorkkk" for="k20">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/200.jpg" alt="" />
                            </label>
                          </div>
                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="سبز" id="k21" class="input-hidden" />
                            <label class="colorkkk" for="k21">
                              <img class="color-order" src="<?= $countBack ?>frontend/web_view/themes/images/21.jpg" alt="" />
                            </label>
                          </div>





                          <div style="float:right;">
                            <input type="radio" name="handle-color" value="قرمز" id="k23" class="input-hidden" />
                            <label for="k23">
                              <!-- <img class="color-order" onclick="noneColorK()" src="<?= $countBack ?>frontend/web_view/themes/images/a12.png" alt="" /> -->
                              <i class="fa fa-trash color-order" style="padding-right: 7px; color: #E91E63;" onclick="noneColorK()"></i>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row-comment">
                    <div class="garma-div">
                      <div class="titr-order">
                        <div class="mablagh">
                          تعداد:
                        </div>
                        <input type="text" class="select-order select-order2" onchange="pricee()" id="number" name="number" value="">
                      </div>
                    </div>
                  </div>
                  <div class="row-comment">
                    <div class="garma-div">
                      <!-- <div class="mablagh">
                  مبلغ نهایی:
                </div> -->
                      <input type="hidden" name="price" id="final-hidden" value="">
                      <input type="text" class="select-order-mablagh" id="final" placeholder="مبلغ نهایی:">
                      <!-- <input type="button" name="" value="بروزرسانی قیمت" class="input-send" onclick="firstPrice()"> -->

                    </div>
                  </div>

                </div>
                <!-- <input type="button" name="" value="ثبت سفارش" class="input-send" onclick="confirmComment()"> -->
                <!-- <button type="button" name="button" class="input-send"onclick="confirmInsert()">ثبت سفارش</button> -->

              </div>
              <input type="button" name="send" class="input-send" onclick="insertComment()" value="افزودن فاکتور">
              <table id="table-wait">
                <thead>


                  <tr class="tr">
                    <td class="td">نام سفارش</td>
                    <td class="td">تعداد</td>
                    <!-- <td class="td">کاست</td> -->
                    <!-- <td class="td">گرماژ</td>
        <td class="td form">حالت</td>
        <td class="td">کاست</td>
        <td class="td handel">دسته</td>
        <td class="td">سایز</td>
            <td class="td first-color">رنگ اول</td>
            <td class="td second-color">رنگ دوم</td>
            <td class="td handel-color">رنگ دسته</td> -->
                    <!-- <td class="td number-buy">فرم</td> -->
                    <!-- <td class="td img-buy">دسته</td> -->
                    <td class="td img-ris">طرح اول</td>
                    <td class="td img-ris">طرح دوم</td>
                    <td class="td">قیمت</td>
                    <td class="td">حذف</td>
                    <!-- <td class="td">print</td> -->
                    <!-- <td class="td">upload_img</td> -->

                    <!-- <td class="td">ارسال بار</td> -->
                    <!-- <td>update</td> -->

                  </tr>
                </thead>
                <tbody id="tbody-blog-wait"></tbody>
              </table>
              <form class="upload-image" action="frontend/api/order/insert.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="token_client" value="<?= makeToken() ?>">
                <input type="hidden" name="hidden-id" id="hidden-id" value="">
                <input type="hidden" name="input-all-buy-hidden" id="input-all-buy-hidden" value="">

                <div class="price-final-div">
                  <div class="row-comment">
                    <div class="title-coment">
                      <!-- لطفا جواب سوال روبرو را در کادر پایین بنویسید: -->
                      <img src="kernel/lib/captcha.php" class="captcha" alt="">
                    </div>
                    <input type="text" class="input-text-wide-comment" id="comment-answer" placeholder="حاصل را وارد کنید" name="answer" required oninvalid="setCustomValidity('کد امنیتی را وارد کنید')" oninput="setCustomValidity('')" value="">
                  </div>
                  <input type="number" name="" placeholder="مجموع خرید ها" class="price-final" id="price-final" value="" style="display:none;">
                  <input type="text" name="" placeholder="مجموع خرید ها" class="price-final" id="price-final-view" value="">

                  <input type="submit" name="" value="پرداخت فاکتور" class="price-final-button" id="buy-all-submit" onclick="deleteCookie()" value="">

                </div>
              </form>
            </div>
          </div>
          <div class="panel" id="two-panel">
            <table id="table-blog">
              <thead>


                <tr class="tr">
                  <td class="td">شماره</td>
                  <td class="td">نام سفارش</td>
                  <!-- <td class="td">گرماژ</td>
        <td class="td form">حالت</td>
        <td class="td">کاست</td>
        <td class="td handel">دسته</td>
        <td class="td">سایز</td>
            <td class="td first-color">رنگ اول</td>
            <td class="td second-color">رنگ دوم</td>
            <td class="td handel-color">رنگ دسته</td> -->
                  <td class="td number-buy">تعداد</td>
                  <td class="td img-buy">تصویر</td>
                  <td class="td img-buy">تصویر۲</td>
                  <td class="td">قیمت</td>
                  <!-- <td class="td">print</td> -->
                  <!-- <td class="td">upload_img</td> -->

                  <td class="td">ارسال بار</td>
                  <!-- <td>update</td> -->

                </tr>
              </thead>
              <tbody id="tbody-blog">
              </tbody>
            </table>
            <div class="send-sells-div">
              <input type="submit" onclick="pageSendSell()" class="send-sells-input" value="درخواست ارسال ها">
            </div>
          </div>
          <div class="panel" id="three-panel">
            <div class="panel-div-right">
              <div class="panel-div-bag" id="dell0" style="display:none;">

              </div>
              <div class="panel-div-bag" style="display:none;" id="dell1">

              </div>
              <div class="panel-div-bag" style="display:none;" id="dell2">

              </div>
              <div class="panel-div-bag" style="display:none;" id="dell3">

              </div>
              <div class="panel-div-bag" style="display:none;" id="dell4">

              </div>

              <div class="panel-div-bag" style="display:none;" id="dell5">

              </div>
              <div class="panel-div-bag" style="display:none;" id="dell6">

              </div>
              <div class="panel-div-bag" style="display:none;" id="dell7">

              </div>
              <div class="panel-div-bag" style="display:none;" id="dell8">

              </div>
              <div class="panel-div-bag" style="display:none;" id="dell9">

              </div>
              <div class="panel-div-bag" style="display:none;" id="dell10">

              </div>
              <br>
              <div class="panel-input-div" id="dell11">
                <div class="select-transport-div">
                  <input class="select-transport" type="text" name="" value="" placeholder="شماره موبایل: " id="transport-phone">
                  <br>
                  <input class="select-transport" type="text" name="" value="" placeholder="شماره موبایل: " id="transport-phone2">
                </div>
                <div class="select-transport-div">
                  <input class="select-transport" type="text" name="" value="" placeholder="شهر : " id="transport-city">
                  <br>
                  <input class="select-transport" type="text" name="" value="" placeholder="استان: " id="transport-state">
                </div>
                <div class="select-transport-div">
                  <input class="select-transport" type="text" name="" value="" placeholder="شماره ثابت: " id="transport-phone3">
                  <select class="select-transport" id="transport" name="transport">
                    <option value="">باربری شاهین</option>
                    <option value="">ترمینال</option>
                    <!-- <option value="">ccccc</option> -->
                  </select>
                  <br>
                </div>
                <input class="panel-div-input" type="textarea" name="" placeholder="آدرس خود را وارد کنید: " value="" id="panel-div-input">

              </div>
              <input type="button" name="" id="sendTransport" value="درخواست ارسال بار" class="input-send-transport" onclick="sendTransport()">


            </div>
          </div>
          <div class="panel" id="four-panel">
            <div class="profile">
              <div class="titr-pro">
                <div class="profile-name">
                  نام:
                </div>
                <input type="text" class="profile-name-input" id="profile-name-input" name="" value="">
              </div>

              <div class="titr-pro">
                <div class="profile-name">
                  نام خانوادگی:
                </div>
                <input type="text" class="profile-name-input" id="profile-family-input" name="" value="">
              </div>

              <div class="titr-pro">
                <div class="profile-name">
                  گذرواژه:
                </div>
                <input type="text" class="profile-name-input" id="profile-pass-input" name="" value="">
              </div>

              <div class="titr-pro">
                <div class="profile-name">
                  تکرار گذرواژه:
                </div>
                <input type="text" class="profile-name-input" id="profile-reppass-input" name="" value="">
              </div>
              <div class="titr-pro">
                <input type="button" name="" value="ارسال مشخصات" class="input-send-pro" onclick="sendProfile()">
              </div>

            </div>
          </div>
          <div class="panel" id="fiv-panel">
            <table id="table-blog">
              <thead>


                <tr class="tr">
                  <td class="td">شماره</td>
                  <td class="td">نام سفارش</td>
                  <!-- <td class="td">گرماژ</td>
        <td class="td form">حالت</td>
        <td class="td">کاست</td>
        <td class="td handel">دسته</td>
        <td class="td">سایز</td>
            <td class="td first-color">رنگ اول</td>
            <td class="td second-color">رنگ دوم</td>
            <td class="td handel-color">رنگ دسته</td> -->
                  <td class="td number-buy">تعداد</td>
                  <td class="td img-buy">تصویر</td>
                  <td class="td img-buy">تصویر۲</td>
                  <td class="td">قیمت</td>
                  <td class="td">وضعیت</td>
                  <!-- <td class="td">مشاهده</td> -->
                  <!-- <td class="td">print</td> -->
                  <!-- <td class="td">upload_img</td> -->

                  <!-- <td class="td">ارسال بار</td> -->
                  <!-- <td>update</td> -->

                </tr>
              </thead>
              <tbody id="tbody-blog-send">
              </tbody>
            </table>
          </div>
          <div class="panel" id="six-panel">
            <table id="table-blog">
              <thead>


                <tr class="tr">
                  <td class="td">شماره</td>
                  <td class="td">نام سفارش</td>
                  <!-- <td class="td">گرماژ</td>
        <td class="td form">حالت</td>
        <td class="td">کاست</td>
        <td class="td handel">دسته</td>
        <td class="td">سایز</td>
            <td class="td first-color">رنگ اول</td>
            <td class="td second-color">رنگ دوم</td>
            <td class="td handel-color">رنگ دسته</td> -->
                  <td class="td number-buy">تعداد</td>
                  <td class="td img-buy">تصویر</td>
                  <td class="td img-buy">تصویر۲</td>
                  <td class="td">قیمت</td>
                  <td class="td">وضعیت</td>
                  <td class="td" style="display:none;">مشاهده</td>
                  <!-- <td class="td">print</td> -->
                  <!-- <td class="td">upload_img</td> -->

                  <!-- <td class="td">ارسال بار</td> -->
                  <!-- <td>update</td> -->

                </tr>
              </thead>
              <tbody id="tbody-blog-nopey">
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </main>
<?php
} else {
?>
  <meta http-equiv='refresh' content='0; URL=signin' />
<?php
}
?>
