
function updatepage(str){
  myObj=JSON.parse(str);
  // console.log(str);
  if(myObj.messageCode.code=="110"){
    console.log('choise');
    console.log(choise);
    console.log('choise');
    if(choise=='insert'){

    window.location='order?list-order';
    }else if(choise=='select') {

        e('box-gallery').innerHTML='';
        var id;
        var fileName;
          if(myObj.Data5!=undefined){
        for (var i = 0; i < myObj.Data5.length; i++) {
          id=myObj.Data5[i]['id'];
          fileName=myObj.Data5[i]['file_name'];
          parent=myObj.Data5[i]['parent'];
          if(myObj.Data5[i]['type']=='file'){
          e('box-gallery').innerHTML+='<div class="column-gallery"  onclick="showFile(\''+fileName+'\',\''+id+'\')"><button class="delete-gallery" onclick="imgDelete(\''+id+'\',\''+fileName+'\')"><i class="fa fa-trash"></i></button><img src="../uploads/'+fileName+'" class="galley-img" alt=""></div>';
          // showFile();
        }else {
          e('box-gallery').innerHTML+='<div class="column-gallery" onclick="inToFolder(\''+id+'\')"><img src="../frontend/web_view/themes/images/folder.png" class="galley-folder" alt=""><span class="span-name">'+fileName+'</span></div>';
        }

        }
      }
      if(myObj.Data7!=undefined){
        ccc=myObj.Data7[0]['parent'];
      }else {
        ccc='0';
      }
      e('back').innerHTML='<span onclick="inToFolder(\''+ccc+'\')">برگشت</span>';


        if(myObj.Data6!=undefined){
          fileCount=Math.ceil(myObj.Data6['file_count']/15);
        }
        var row1=document.querySelectorAll('.row1');
        stUrlId=window.location.hash.substring(1);
        if(stUrlId==undefined){
          pageId=1;
        }else {
          pageId=parseInt(stUrlId);
        }
        row1[0].innerHTML='';
        row1[1].innerHTML='';
        row1[2].innerHTML='';
        row1[0].innerHTML='<a href="#1" class="page-number-a">'+(1)+'</a>';
        if(fileCount>1){
          row1[0].innerHTML+='<a href="#2" class="page-number-a">'+(2)+'</a>';
        }
        if(fileCount>2){
          row1[0].innerHTML+='<a href="#3" class="page-number-a">'+(3)+'</a>';
        }
        if(pageId>5){
          row1[1].innerHTML+='<span class="page-number-span">...</span>';
        }
        for (var i =pageId;i<(pageId+3);i++) {
          if(i>4 && i<(fileCount-1)){
            row1[1].innerHTML+='<a href="#'+(i-1)+'" class="page-number-a">'+(i-1)+'</a>';
          }
        }
        if( pageId<(fileCount-4)){
          row1[1].innerHTML+='<span class="page-number-span">...</span>';
        }
        if(fileCount>5){
          row1[2].innerHTML+= '<a href="#'+(fileCount-2)+'" class="page-number-a">'+(fileCount-2)+'</a>';
        }
          if(fileCount>4){
          row1[2].innerHTML+='<a href="#'+(fileCount-1)+'" class="page-number-a">'+(fileCount-1)+'</a>';
        }
          if(fileCount>3){
          row1[2].innerHTML+='<a href="#'+fileCount+'" class="page-number-a">'+(fileCount)+'</a>';
        }


        pageNumberA=document.querySelectorAll('.page-number-a');

        pageNumberA.forEach(item => {
          item.addEventListener('click', event => {
            selectAll(item.innerHTML);

          })
        });






      }else if (choise=='uploadImage') {
        pageNumberA=document.querySelectorAll('.page-number-a');

        pageNumberA.forEach(item => {
          // item.addEventListener('click', event => {
            selectAll(1);

          // })
        })
      }else if (choise=='delete') {
        // window.location='http://localhost/order#1';
        // selectFile();
        pageNumberA=document.querySelectorAll('.page-number-a');

        pageNumberA.forEach(item => {
          // item.addEventListener('click', event => {
            selectAll(1);

          // })
        })
      }else if (choise=='selectSecend') {


              var id;
              var gram;
              var cassette;
              var size;
              var form;
              var price;
              var handel;
              var handelColor;
              var firstColor;
              var secondColor;
              var number;
              var print;
              var title;
              var uploadImg;
              var uploadImg2;

        // e('table-blog').innerHTML='';
        e('tbody-blog').innerHTML='';
        e('tbody-blog-nopey').innerHTML='';
        e('tbody-blog-send').innerHTML='';
        console.log(myObj.Data3);
        var countPey=0;
        for (var i = 0; i < myObj.Data3.length; i++) {


          if (myObj.Data3[i]['sended']==3) {
            countPey=countPey+1;
          id=myObj.Data3[i]['buy_castomer_id'];
          gram=myObj.Data3[i]['garma'];
          cassette=myObj.Data3[i]['cassette'];
          size=myObj.Data3[i]['size'];
          form=myObj.Data3[i]['form'];
          price=myObj.Data3[i]['price'];
          handel=myObj.Data3[i]['handel'];
          handelColor=myObj.Data3[i]['handel_color'];
          firstColor=myObj.Data3[i]['first_color'];
          secondColor=myObj.Data3[i]['second_color'];
          number=myObj.Data3[i]['number'];
          title=myObj.Data3[i]['title'];
          // number=myObj.Data3[i]['print'];
          uploadImg=myObj.Data3[i]['file_name'];
          uploadImg2=myObj.Data7[i]['file_name'];
          if(uploadImg==null){
            uploadImg='logo2.png';
          }
          if(uploadImg2==null){
            uploadImg2='logo2.png';
          }

          if(myObj.Data3[i]['address']==null){
            e('tbody-blog').innerHTML+='<tr><td>'+countPey+'</td><td>'+title+'</td><td class="number-buy">'+number+'</td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg+'"></td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg2+'"></td><td>'+price+'</td><td style="color:red;" onclick="viewBuy('+id+','+0+')" class="cursor" id="send"><input type="checkbox" class="warning-input" name="warning-input" id="warning-input" onchange="warningInput('+id+')" ></td></tr>';
          }else {
            e('tbody-blog').innerHTML+='<tr><td>'+countPey+'</td><td>'+title+'</td><td class="number-buy">'+number+'</td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg+'"></td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg2+'"></td><td>'+price+'</td><td style="color:green;" onclick="viewBuy('+id+','+0+')" class="cursor" id="send"><input type="checkbox" class="warning-input" name="warning-input" id="warning-input" onchange="warningInput('+id+')" ></td></tr>';

          }
          // if(myObj.Data3[i]['address']==null){
          //   e('tbody-blog').innerHTML+='<tr><td>'+countPey+'</td><td>'+title+'</td><td class="number-buy">'+number+'</td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg+'"></td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg2+'"></td><td>'+price+'</td><td style="color:red;" onclick="viewBuy('+id+','+0+')" class="cursor" id="send"><input type="checkbox" class="warning-input" name="warning-input" id="warning-input" onchange="warningInput('+id+')" ></td></tr>';
          // }else {
          //   e('tbody-blog').innerHTML+='<tr><td>'+countPey+'</td><td>'+title+'</td><td class="number-buy">'+number+'</td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg+'"></td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg2+'"></td><td>'+price+'</td><td style="color:green;" onclick="viewBuy('+id+','+0+')" class="cursor" id="send"><label  id="three-tab" for="three">ارسال بار</label><input type="checkbox" class="warning-input" name="warning-input" id="warning-input" onchange="warningInput('+id+')" ></td></tr>';
          //
          // }
        }

        }
        var countNopey=0;
        for (var i = 0; i < myObj.Data3.length; i++) {
          // if (myObj.Data3[i]['pey']!=1) {
          countNopey=countNopey+1;
          id=myObj.Data3[i]['buy_castomer_id'];
          gram=myObj.Data3[i]['garma'];
          cassette=myObj.Data3[i]['cassette'];
          size=myObj.Data3[i]['size'];
          form=myObj.Data3[i]['form'];
          price=myObj.Data3[i]['price'];
          handel=myObj.Data3[i]['handel'];
          handelColor=myObj.Data3[i]['handel_color'];
          firstColor=myObj.Data3[i]['first_color'];
          secondColor=myObj.Data3[i]['second_color'];
          number=myObj.Data3[i]['number'];
          title=myObj.Data3[i]['title'];
          // number=myObj.Data3[i]['print'];
          uploadImg=myObj.Data3[i]['file_name'];
          uploadImg2=myObj.Data7[i]['file_name'];
          if(uploadImg==null){
            uploadImg='logo2.png';
          }
          if(uploadImg2==null){
            uploadImg2='logo2.png';
          }
          if (myObj.Data3[i]['pey']==1) {
            var textPey="پرداخت شده";
          }
          else if (myObj.Data3[i]['pey']!=1) {
            var textPey="پرداخت نشده";
          }
          e('tbody-blog-nopey').innerHTML+='<tr><td >'+countNopey+'</td><td>'+title+'</td><td class="number-buy">'+number+'</td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg+'"></td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg2+'"></td><td>'+price+'</td><td>'+textPey+'</td><td style="color:red;display: none;" onclick="viewBuy('+id+',1)" class="cursor" id="send"><label  id="three-tab" for="three">مشاهده</label></td></tr>';
        // }

        }
        var countSended=0;
        for (var i = 0; i < myObj.Data3.length; i++) {
          // if ((myObj.Data3[i]['sended']==2 || myObj.Data3[i]['sended']==2 || myObj.Data3[i]['sended']==1 || myObj.Data3[i]['sended']==0 || myObj.Data3[i]['sended']==null) && myObj.Data3[i]['pey']==1 ) {
            countSended=countSended+1;
          id=myObj.Data3[i]['buy_castomer_id'];
          gram=myObj.Data3[i]['garma'];
          cassette=myObj.Data3[i]['cassette'];
          size=myObj.Data3[i]['size'];
          form=myObj.Data3[i]['form'];
          price=myObj.Data3[i]['price'];
          handel=myObj.Data3[i]['handel'];
          handelColor=myObj.Data3[i]['handel_color'];
          firstColor=myObj.Data3[i]['first_color'];
          secondColor=myObj.Data3[i]['second_color'];
          number=myObj.Data3[i]['number'];
          title=myObj.Data3[i]['title'];
          // number=myObj.Data3[i]['print'];
          uploadImg=myObj.Data3[i]['file_name'];
          uploadImg2=myObj.Data7[i]['file_name'];
          if(uploadImg==null){
            uploadImg='logo2.png';
          }
          if(uploadImg2==null){
            uploadImg2='logo2.png';
          }
          if (myObj.Data3[i]['sended']==0 || myObj.Data3[i]['sended']==null) {
            var textSend="درحال بررسی";
          }
          else if (myObj.Data3[i]['sended']==2) {
            var textSend="درحال تولید";
          }
          else if (myObj.Data3[i]['sended']==3) {
            var textSend="آماده تحویل";
          }
          else if (myObj.Data3[i]['sended']==1) {
            var textSend="ارسال شد";
          }
          e('tbody-blog-send').innerHTML+='<tr><td>'+countSended+'</td><td>'+title+'</td><td class="number-buy">'+number+'</td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg+'"></td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg2+'"></td><td>'+price+'</td><td class="number-buy">'+textSend+'</td></tr>';
          // e('tbody-blog-send').innerHTML+='<tr><td>'+countSended+'</td><td>'+title+'</td><td class="number-buy">'+number+'</td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg+'"></td><td class="img-buy"><img style="width: 90%;"  src="<?=$GLOBALS['countBack'].'uploads/'?>'+uploadImg2+'"></td><td>'+price+'</td><td class="number-buy">'+textSend+'</td><td style="color:red;" onclick="viewBuy('+id+',1)" class="cursor" id="send"><label  id="three-tab" for="three">مشاهده</label></td></tr>';
        // }

        }
        var name;
        var family;
        var password;

        name=myObj.Data4[0]['name'];
        family=myObj.Data4[0]['family'];
        // password=myObj.Data4['password'];
        e('profile-name-input').value=name;
        e('profile-family-input').value=family;
        // e('profile-pass-input').value=password;
        // e('profile-reppass-input').value=password;

      }
  }
  // var testimg=e('color-orderasd').src;
  // e('dropbtn-orderr').style.backgroundImage='url('+testimg+')';
  // var firstColoUser=document.querySelectorAll(".second-color-user");
}
function showFile(name,id) {
  // console.log(id);
  if(generalValue==1){
  e('hidden-id-file').value=id;
  e('image-name').style.display="block";
  e('image-name').src='../uploads/'+name;
  }
  else if(generalValue==2){
    e('hidden-id-file2').value=id;
      e('image-name2').style.display="block";
    e('image-name2').src='../uploads/'+name;
  }
  closeBlur();
  // console.log('oooooooooooooo');
  // galleyImg=document.querySelectorAll('.galley-img');
  // galleyImg.forEach(item => {
  //   item.addEventListener('click', event => {
  //     document.getElementById('image-name').value=item.src;
  //     document.getElementById('imageURL').value=item.src;
  //     document.getElementById('blur').style.display='none';
  //   })
  // })
}

if(window.location.search=='?list-order'){
  e('two').checked=true;
}

setInterval(firstPrice, 1000);
function firstPrice() {
  if (e('c1').checked==true) {
    e('style-handel-color').style.display="block";
  }
  else if (e('c2').checked==true) {
    e('style-handel-color').style.display="none";
  }
  var eprint = document.getElementById("print");
  var printValue = eprint.value;
 if (printValue=="one") {
   e('ask-print').style.display="block";
   e('upload-img').style.display="table";
   e('upload-img2').style.display="none";

 }
 else if (printValue=="two") {
   e('ask-print').style.display="block";
   e('upload-img2').style.display="table";
   e('upload-img2').style.float="left";
   e('upload-img').style.display="table";
   e('upload-img').style.float="right";
 }
 else if (printValue=="no") {
   e('ask-print').style.display="none";
   e('upload-img').style.display="none";
   }



  var formObj=[];
  for (var i = 0; i < (myObj.Data).length; i++) {


    var form;
    var forms=document.getElementsByName('form');
    for (var j = 0; j < forms.length; j++) {
      if(forms[j].checked){
        form=forms[j].value;
        break;
      }
    }
    if(myObj.Data[i]['form']==form){
      formObj.push(myObj.Data[i]);
    }
  }




  var cassetteObj=[];
  for (var i = 0; i < formObj.length; i++) {
    var cassette;
    var cassettes=document.getElementsByName('cassette');
    for (var j = 0; j < cassettes.length; j++) {
      if(cassettes[j].checked){
        cassette=cassettes[j].value;
        break;
      }
    }
    if(formObj[i]['cassette']==cassette){
      cassetteObj.push(formObj[i]);
    }
  }

  var gramObj=[];
  for (var i = 0; i < cassetteObj.length; i++) {
    var gram;
    var grams=document.getElementsByName('gram');
    for (var j = 0; j < grams.length; j++) {
      if(grams[j].checked){
        gram=grams[j].value;
        break;
      }
    }
    if(cassetteObj[i]['gram']==gram){
      gramObj.push(cassetteObj[i]);
    }
  }


  var sizeObj=[];

  var eSize = document.getElementById("size");
  var sizeValue = eSize.value;
  // var textSize = eSize.options[eSize.selectedIndex].text;


  for (var i = 0; i < gramObj.length; i++) {
    // var selectOrder;
    // var selectOrders=document.getElementsByName('size');
    // for (var j = 0; j < selectOrders.length; j++) {
    //   if(selectOrders[j].checked){
    //     selectOrder=selectOrders[j].value;
    //     break;
    //   }
    // }





    if(gramObj[i]['size']==sizeValue){
      sizeObj.push(gramObj[i]);
    }
  }




  // document.getElementById('final').value=sizeObj[0].price;
if (sizeObj.length>0) {
var final=Number(sizeObj[0].price);
final=final+(final/100*myObj.Data2[0]['add_Percent']);
  // if (e('i7').checked==true) {
  //   final=Number(sizeObj[0].price)+Number(myObj.Data2[0]['golden']);
  // }
  //
  // else if (e('i5').checked==true) {
  //   final=Number(sizeObj[0].price)+Number(myObj.Data2[0]['white']);
  // }
  //
  // else if (e('i3').checked==true) {
  //   final=Number(sizeObj[0].price)+Number(myObj.Data2[0]['silver']);
  // }
  //
  // else if (e('i1').checked==true) {
  //   final=Number(sizeObj[0].price)+Number(myObj.Data2[0]['phosphoric']);
  // }
  // else if (e('i2').checked==true || e('i4').checked==true || e('i6').checked==true || e('i8').checked==true || e('i9').checked==true || e('i10').checked==true || e('i11').checked==true || e('i13').checked==true ) {
  //   final=Number(sizeObj[0].price)+Number(myObj.Data2[0]['price_first_color']);
  // }


  // if ((e('i1').checked==e('j1').checked) &&(e('i2').checked==e('j2').checked) && (e('i3').checked==e('j3').checked) && (e('i4').checked==e('j4').checked) && (e('i5').checked==e('j5').checked) && (e('i6').checked==e('j6').checked) &&(e('i7').checked==e('j7').checked) &&(e('i8').checked==e('j8').checked) &&(e('i9').checked==e('j9').checked) &&(e('i10').checked==e('j10').checked) &&(e('i11').checked==e('j11').checked) &&(e('i13').checked==e('j13').checked) ) {

// if (((e('i1').checked==true && e('j1').checked==true ) ||(e('i2').checked==true && e('j2').checked==true ) || (e('i3').checked==true && e('j3').checked==true ) || (e('i4').checked==true && e('j4').checked==true ) || (e('i5').checked==true && e('j5').checked==true ) || (e('i6').checked==true && e('j6').checked==true ) ||(e('i7').checked==true && e('j7').checked==true ) ||(e('i8').checked==true && e('j8').checked==true ) ||(e('i9').checked==true && e('j9').checked==true ) ||(e('i10').checked==true && e('j10').checked==true ) ||(e('i11').checked==true && e('j11').checked==true ) ||(e('i13').checked==true && e('j13').checked==true ))&&((e('i1').checked==false && e('j1').checked==false ) ||(e('i2').checked==false && e('j2').checked==false ) || (e('i3').checked==false && e('j3').checked==false ) || (e('i4').checked==false && e('j4').checked==false ) || (e('i5').checked==false && e('j5').checked==false ) || (e('i6').checked==false && e('j6').checked==false ) ||(e('i7').checked==false && e('j7').checked==false ) ||(e('i8').checked==false && e('j8').checked==false ) ||(e('i9').checked==false && e('j9').checked==false ) ||(e('i10').checked==false && e('j10').checked==false ) ||(e('i11').checked==false && e('j11').checked==false ) ||(e('i13').checked==false && e('j13').checked==false )) ) {
// final=final+Number(myObj.Data2[0]['choose_second_color']);
// }else {
//
// }

if((e('i1').checked!=e('j1').checked
  || e('i2').checked!=e('j2').checked
  || e('i3').checked!=e('j3').checked
  || e('i4').checked!=e('j4').checked
  || e('i5').checked!=e('j5').checked
  || e('i6').checked!=e('j6').checked
  || e('i7').checked!=e('j7').checked
  || e('i8').checked!=e('j8').checked
  || e('i9').checked!=e('j9').checked
  || e('i10').checked!=e('j10').checked
  || e('i11').checked!=e('j11').checked
  || e('i13').checked!=e('j13').checked)
   &&(e('j1').checked==true
   ||e('j2').checked==true
   ||e('j3').checked==true
   ||e('j4').checked==true
   ||e('j5').checked==true
   ||e('j6').checked==true
   ||e('j7').checked==true
   ||e('j8').checked==true
   ||e('j9').checked==true
   ||e('j10').checked==true
   ||e('j11').checked==true
   ||e('j13').checked==true)){
  final=final+Number(myObj.Data2[0]['choose_second_color']);
}





  if (e('c1').checked==true && e('sad').checked==true) {
    final=final+Number(myObj.Data2[0]['zanbil_handel_60']);
  }

  else if (e('c1').checked==true && e('happy').checked==true) {
    final=final+Number(myObj.Data2[0]['zanbil_handel_90']);

  }

  else if (e('c1').checked==true && e('innormal').checked==true) {
    final=final+Number(myObj.Data2[0]['zanbil_handel_40']);

  }
 //  var eprint = document.getElementById("print");
 //  var printValue = eprint.value;
 // if (printValue=="one") {
 //   final=final+Number(myObj.Data2[0]['print_one']);
 // }
 // else if (printValue=="two") {
 //   final=final+Number(myObj.Data2[0]['print_two']);
 // }
 // var eprintColor = document.getElementById("print-color");
 // var printValueColor = eprintColor.value;
 // if (printValueColor=="silver") {
 //   final=final+Number(myObj.Data2[0]['silver']);
 //
 // }else if (printValueColor=="white") {
 //   final=final+Number(myObj.Data2[0]['white']);
 //
 // }else if (printValueColor=="golden") {
 //   final=final+Number(myObj.Data2[0]['golden']);
 //
 // }else if (printValueColor=="phosphor") {
 //   final=final+Number(myObj.Data2[0]['phosphoric']);
 //
 // }

 var eprint = document.getElementById("print");
 var printValue = eprint.value;

 var eprintColor = document.getElementById("print-color");
 var printValueColor = eprintColor.value;

if (printValue=="one") {


  if (printValueColor=="silver") {
      final=final+Number(myObj.Data2[0]['silver']);

  }else if (printValueColor=="white") {
    final=final+Number(myObj.Data2[0]['white']);

  }else if (printValueColor=="golden") {
    final=final+Number(myObj.Data2[0]['golden']);

  }else if (printValueColor=="phosphor") {
    final=final+Number(myObj.Data2[0]['phosphoric']);

  }else if (printValueColor=="nocolor") {
      final=final+Number(myObj.Data2[0]['print_one']);
  }

}
else if (printValue=="two") {
  // final=final+Number(myObj.Data2[0]['print_one'])+Number(myObj.Data2[0]['print_one']);

  if (printValueColor=="silver") {
    final=final+Number(myObj.Data2[0]['silver'])+Number(myObj.Data2[0]['silver']);
  }else if (printValueColor=="white") {
    final=final+Number(myObj.Data2[0]['white'])+Number(myObj.Data2[0]['white']);

  }else if (printValueColor=="golden") {
    final=final+Number(myObj.Data2[0]['golden'])+Number(myObj.Data2[0]['golden']);

  }else if (printValueColor=="phosphor") {
    final=final+Number(myObj.Data2[0]['phosphoric'])+Number(myObj.Data2[0]['phosphoric']);

  }else if (printValueColor=="nocolor") {
final=final+Number(myObj.Data2[0]['print_one'])+Number(myObj.Data2[0]['print_one']);
  }

}
// var eprintColor = document.getElementById("print-color");
// var printValueColor = eprintColor.value;
// if (printValueColor=="silver") {
//   final=final+Number(myObj.Data2[0]['silver']);
//
// }else if (printValueColor=="white") {
//   final=final+Number(myObj.Data2[0]['white']);
//
// }else if (printValueColor=="golden") {
//   final=final+Number(myObj.Data2[0]['golden']);
//
// }else if (printValueColor=="phosphor") {
//   final=final+Number(myObj.Data2[0]['phosphoric']);
//
// }





final=final*Number(document.getElementById('number').value);
document.getElementById('final-hidden').value=final;
 final=final.toString();
 final=ToRial(final);
document.getElementById('final').value=final+"ریال";
document.getElementById('hidden-id').value=<?=$_SESSION['id_user']?>;
}

}
function changeDescription() {
  var eprintColor = document.getElementById("print-color");
  var printValueColor = eprintColor.value;
  if (printValueColor=="silver") {
    e('description-print').style.display="none";
  }else if (printValueColor=="white") {
    e('description-print').style.display="block";
  }else if (printValueColor=="golden") {
    e('description-print').style.display="none";
  }else if (printValueColor=="phosphor") {
    e('description-print').style.display="block";
  }else{
    e('description-print').style.display="block";
  }
}




var idSlells = [];
function warningInput(az) {
  var test1=idSlells.length+1;
  for (i = 0; i < test1; i++) {
    if (idSlells[i] === az) {
      var index = idSlells.indexOf(az);
        // idSlells.splice(i);
        idSlells.splice(index, 1);
        console.log("zazazazazaza");
        var check=2;
        break;
    }
    else {
      var check=1;
        // break;
    }
}
if (check==1) {
  idSlells.push(az);
}
  console.log(idSlells);
}
function noneColor() {
  for (var j = 1; j < 12; j++) {
    var colorSelect1="j"+j;
    e(colorSelect1).checked=false;
  }
  for (var j = 14; j < 22; j++) {
    var colorSelect1="j"+j;
    e(colorSelect1).checked=false;
  }
    e('j13').checked=false;
    e('dropbtnOrderUser1-3').style.backgroundColor="#cacaca";
    e('dropbtnOrderUser1-3').style.backgroundImage='none';

    e('color-3').style.backgroundColor=e('color-2').style.backgroundColor;
    e('color-3').style.backgroundImage='none';
    document.getElementById("dropbtnOrderUser1-3").value="رنگ دوم:";
    // e('color-3').style.backgroundImage=e('color-2').style.backgroundImage;
}

function noneColorK() {
  for (var k = 1; k < 12; k++) {
    var colorSelect3="k"+k;
    e(colorSelect3).checked=false;
  }
  for (var k = 14; k < 22; k++) {
    var colorSelect3="k"+k;
    e(colorSelect3).checked=false;
  }
    e('k13').checked=false;
    e('dropbtnOrderUser1-1').style.backgroundColor="#cacaca";
    e('dropbtnOrderUser1-1').style.backgroundImage='none';

    e('color-1').style.backgroundColor="#ff000000";
    e('color-1').style.backgroundImage='none';
    document.getElementById("dropbtnOrderUser1-1").value="رنگ دسته";
}



















function gramColor(gramColor) {
  const coloriii= document.querySelectorAll(".coloriii");
  const colorjjj= document.querySelectorAll(".colorjjj");
  const colorkkk= document.querySelectorAll(".colorkkk");
  if (gramColor==40) {
    coloriii[0].style.display = "none";

    for (var i = 0; i < 21; i++) {
        coloriii[i].style.display = "none";
        colorjjj[i].style.display = "none";
        colorkkk[i].style.display = "none";
    }
    coloriii[2].style.display="table";
    coloriii[5].style.display="table";
    coloriii[7].style.display="block";
    coloriii[9].style.display="block";
    coloriii[12].style.display="block";
    coloriii[13].style.display="block";
    coloriii[14].style.display="block";
    coloriii[17].style.display="block";

    colorjjj[2].style.display="table";
    colorjjj[5].style.display="table";
    colorjjj[7].style.display="block";
    colorjjj[10].style.display="block";
    colorjjj[12].style.display="block";
    colorjjj[13].style.display="block";
    colorjjj[14].style.display="block";
    colorjjj[17].style.display="block";

    colorkkk[2].style.display="table";
    colorkkk[5].style.display="table";
    colorkkk[7].style.display="block";
    colorkkk[9].style.display="block";
    colorkkk[12].style.display="block";
    colorkkk[13].style.display="block";
    colorkkk[14].style.display="block";
    colorkkk[17].style.display="block";

  }

  if (gramColor==90) {
    for (var i = 0; i < 21; i++) {
        coloriii[i].style.display = "none";
        colorjjj[i].style.display = "none";
        colorkkk[i].style.display = "none";
    }
    coloriii[0].style.display="table";
    coloriii[2].style.display="table";
    coloriii[4].style.display="table";
    coloriii[5].style.display="table";
    coloriii[6].style.display="table";
    coloriii[7].style.display="block";
    coloriii[8].style.display="block";
    coloriii[15].style.display="block";
    coloriii[8].style.display="block";
    coloriii[12].style.display="block";
    coloriii[13].style.display="block";
    coloriii[14].style.display="block";
    coloriii[17].style.display="block";

    colorjjj[0].style.display="table";
    colorjjj[2].style.display="table";
    colorjjj[4].style.display="table";
    colorjjj[5].style.display="table";
    colorjjj[6].style.display="table";
    colorjjj[7].style.display="block";
    colorjjj[8].style.display="block";
    colorjjj[15].style.display="block";
    colorjjj[8].style.display="block";
    colorjjj[12].style.display="block";
    colorjjj[13].style.display="block";
    colorjjj[14].style.display="block";
    colorjjj[17].style.display="block";

    colorkkk[0].style.display="table";
    colorkkk[2].style.display="table";
    colorkkk[4].style.display="table";
    colorkkk[5].style.display="table";
    colorkkk[6].style.display="table";
    colorkkk[7].style.display="block";
    colorkkk[8].style.display="block";
    colorkkk[15].style.display="block";
    colorkkk[8].style.display="block";
    colorkkk[12].style.display="block";
    colorkkk[13].style.display="block";
    colorkkk[14].style.display="block";
    colorkkk[17].style.display="block";

  }
  if (gramColor==60) {
    for (var i = 0; i < 21; i++) {
        coloriii[i].style.display = "block";
        colorjjj[i].style.display = "block";
        colorkkk[i].style.display = "block";
    }
  }

}







const coloriii1= document.querySelectorAll(".coloriii");
const colorjjj1= document.querySelectorAll(".colorjjj");
const colorkkk1= document.querySelectorAll(".colorkkk");

document.addEventListener("input", (e) => {
    if ( "handle-color" == e.target.getAttribute("name")) {
        switch (e.target.id) {
          case "k1":
              (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/001.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/001.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k1").value);
              break;
          case "k2":
              (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/002.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/002.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k2").value);
              break;
          case "k3":
              (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/003.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/003.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k3").value);
              break;
          case "k4":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/004.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/004.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k4").value);
              break;
          case "k5":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/006.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/006.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k5").value);
            break;
          case"k6":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/005.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/005.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k6").value);
              break;
          case "k7":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/007.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/007.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k7").value);
              break;
          case "k8":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/008.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/008.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k8").value);
              break;
          case "k9":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/009.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/009.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k9").value);
              break;
          case "k10":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/11.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/11.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k10").value);
              break;
          case "k11":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/12.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/12.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k11").value);
              break;
          case "k13":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/13.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/13.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k13").value);
              break;
          case "k14":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/14.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/14.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k14").value);
              break;
          case "k15":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/15.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/15.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k15").value);
              break;
          case "k16":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/16.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/16.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k16").value);
              break;
          case "k17":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/17.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/17.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k17").value);
              break;
          case "k18":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/18.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/18.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k18").value);
              break;
          case "k19":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/19.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/19.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k19").value);
              break;
          case "k20":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/200.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/200.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k20").value);
              break;
          case "k21":
          (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/21.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/21.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k21").value);
              break;
              case "k22":
              (document.getElementById("color-1").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/100.jpg')"), (document.getElementById("dropbtnOrderUser1-1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/100.jpg')"),(document.getElementById("dropbtnOrderUser1-1").value=document.getElementById("k22").value);
              break;
          default:
              console.log("error");
        }
        document.getElementById("myDropdownOrderHandle").classList.toggle("show-order-handle");
    }
    if ("first-color" == e.target.getAttribute("name")) {
        switch (e.target.id) {
            case "i1":
                (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/001.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/001.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i1").value);
                break;
            case "i2":
                (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/002.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/002.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i2").value);
                break;
            case "i3":
                (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/003.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/003.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i3").value);
                break;
            case "i4":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/004.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/004.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i4").value);
                break;
            case "i5":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/006.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/006.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i5").value);
              break;
            case "i6":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/005.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/005.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i6").value);
                break;
            case "i7":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/007.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/007.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i7").value);
                break;
            case "i8":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/008.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/008.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i8").value);
                break;
            case "i9":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/009.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/009.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i9").value);
                break;
            case "i10":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/11.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/11.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i10").value);
                break;
            case "i11":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/12.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/12.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i11").value);
                break;
            case "i13":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/13.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/13.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i13").value);
                break;
            case "i14":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/14.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/14.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i14").value);
                break;
            case "i15":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/15.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/15.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i15").value);
                break;
            case "i16":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/16.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/16.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i16").value);
                break;
            case "i17":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/17.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/17.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i17").value);
                break;
            case "i18":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/18.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/18.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i18").value);
                break;
            case "i19":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/19.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/19.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i19").value);
                break;
            case "i20":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/200.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/200.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i20").value);
                break;
            case "i21":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/21.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/21.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i21").value);
                break;
            case "i22":
            (document.getElementById("color-2").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/100.jpg')"), (document.getElementById("dropbtnOrderUser1").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/100.jpg')"),(document.getElementById("dropbtnOrderUser1").value=document.getElementById("i22").value);
                break;
            default:
                console.log("error");
        }
        document.getElementById("myDropdownOrder").classList.toggle("show-order");
    }
    if ("second-color" == e.target.getAttribute("name")) {
        switch (e.target.id) {
          case "j1":
              (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/001.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/001.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j1").value);
              break;
          case "j2":
              (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/002.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/002.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j2").value);
              break;
          case "j3":
              (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/003.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/003.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j3").value);
              break;
          case "j4":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/004.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/004.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j4").value);
              break;
          case "j5":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/006.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/006.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j5").value);
            break;
          case "j6":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/005.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/005.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j6").value);
              break;
          case "j7":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/007.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/007.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j7").value);
              break;
          case "j8":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/008.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/008.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j8").value);
              break;
          case "j9":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/009.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/009.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j9").value);
              break;
          case "j10":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/11.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/11.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j10").value);
              break;
          case "j11":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/12.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/12.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j11").value);
              break;
          case "j13":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/13.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/13.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j13").value);
              break;
          case "j14":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/14.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/14.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j14").value);
              break;
          case "j15":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/15.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/15.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j15").value);
              break;
          case "j16":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/16.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/16.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j16").value);
              break;
          case "j17":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/17.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/17.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j17").value);
              break;
          case "j18":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/18.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/18.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j18").value);
              break;
          case "j19":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/19.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/19.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j19").value);
              break;
          case "j20":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/200.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/200.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j20").value);
              break;
          case "j21":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/21.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/21.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j21").value);
              break;
          case "j22":
          (document.getElementById("color-3").style.backgroundImage  = "url('<?= $countBack ?>frontend/web_view/themes/images/100.jpg')"), (document.getElementById("dropbtnOrderUser1-3").style.backgroundImage = "url('<?= $countBack ?>frontend/web_view/themes/images/100.jpg')"),(document.getElementById("dropbtnOrderUser1-3").value=document.getElementById("j22").value);
              break;
          default:
              console.log("error");
        }
        document.getElementById("myDropdownOrderTwo").classList.toggle("show-order-two");
    }
})
