var deleteId=0;
var priceFinal=0;
var deleteFinal=0;
var pe=0;
var oldId=0;
var ccc=0;
var generalValue=0;
var allBuy=[];
var trCookie='';
var finalCookie=0;

//
// setCookie('mytable','',5);
// setCookie('finalCookie',0,5);
// setCookie('buyCookie','',5);
// setCookie('deleteCookie','',5);
function setCookie(cname, cvalue, exdays)
{
console.log(cvalue)
var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}

function getCookie(cname)
{
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++)
    {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
}


function someFunction(ee) {
  console.log('fff');
  console.log(ee);
    console.log('wwww');
}
function select() {
  document.getElementById('hidden-id').value=<?=$_SESSION['id_user']?>;
  var bb=getCookie('buyCookie');
  if(getCookie('buyCookie')!=null && getCookie('buyCookie')!='' && getCookie('buyCookie')!='NaN' &&  getCookie('buyCookie')!=NaN ){
  // e('tbody-blog-wait').innerHTML=JSON.parse(bb);
  e("price-final").setAttribute('value',getCookie('finalCookie'));
  e('price-final-view').value=ToRial(Number(getCookie('finalCookie')).toString())+" ریال ";

  e("input-all-buy-hidden").setAttribute('value',getCookie('buyCookie'));

  // console.log(JSON.parse(e('input-all-buy-hidden').value));

// run();

      allBuyCookie=JSON.parse(getCookie('buyCookie'));
      e('tbody-blog-wait').innerHTML='';
      for (var i = 0; i < allBuyCookie.length; i++) {
        e('tbody-blog-wait').innerHTML+="<tr class='trCookieClass' id='deletetr"+i+"'><td>"+allBuyCookie[i]["nameBuy"]+"</td><td class='number-buy'>"+allBuyCookie[i]["number"]+"</td><td class='img-buy img-ris'><img style='width: 90%'  src='"+allBuyCookie[i]["selectImg11"]+"'></td><td class='img-buy img-ris'><img style='width: 90%'  src='"+allBuyCookie[i]["selectImg21"]+"'></td><td id='finaltr"+i+"'>"+allBuyCookie[i]["finalSelect"]+"</td><td class='deleteTr' onclick='delete2("+i+")'>حذف</td></tr>";

      }


run();





  }



// choise='select';
choise='selectSecend';
var rnd = Math.random();
var token = e("token");
var formdata = new FormData();
formdata.append("id",rnd);
formdata.append("id_page",1);
formdata.append("parent",0);
formdata.append("token_client",token.value);
var url = "frontend/api/order/select_all.php";
postRequestFile(url,formdata);
return 1;
}





function run() {
var hiddenA=JSON.parse(e('input-all-buy-hidden').value);
var all = document.querySelectorAll('.deleteTr');
var allTrCookieClass=document.querySelectorAll('.trCookieClass');
for (let i = 0; i < all.length; i++) {
    all[i].addEventListener("click", function() {

       delete hiddenA[i];

       var filtered = hiddenA.filter(function (el) {
         return el != null;
        });


        e("input-all-buy-hidden").setAttribute('value',JSON.stringify(filtered));
       // e('input-all-buy-hidden').value=JSON.stringify(filtered);
       setCookie('buyCookie',JSON.stringify(filtered),5);


    });



}

}







function selectFile(value) {
generalValue=value;
document.getElementById('blur').style.display="block";

}
function uploadImage() {
choise='uploadImage';
var rnd = Math.random();
var token = e("token");
var  fileUpload=e('file-upload').files[0];
var formdata = new FormData();
formdata.append("id",rnd);

formdata.append("file[0]", fileUpload);
formdata.append("type","file");
formdata.append("p",pe);
// document.getElementById('result').innerHTML=pic;
formdata.append("token_client",token.value);
var url = "kernel/plugins/files_manager/insert.php";
postRequestFile(url,formdata);
}
function creatFolder() {
choise='uploadImage';
var rnd = Math.random();
var token = e("token");
var  nameFolder=e('name-folder').value;
var formdata = new FormData();
formdata.append("id",rnd);

formdata.append("name_folder", nameFolder);
formdata.append("type","folder");
formdata.append("p",pe);
// document.getElementById('result').innerHTML=pic;
formdata.append("token_client",token.value);
var url = "kernel/plugins/files_manager/insert.php";
postRequestFile(url,formdata);
}
selectContent();
function selectContent() {
selectAll(1);
}
function selectAll(idPage) {
choise='select';
var rnd = Math.random();
var token = e("token");
var formdata = new FormData();
formdata.append("id",rnd);
formdata.append("id_page",idPage);
formdata.append("parent",pe);
formdata.append("token_client",token.value);
var url = "frontend/api/order/select_all.php";
postRequestFile(url,formdata);
}
function inToFolder(idPage) {
pe=idPage;
choise='select';
var rnd = Math.random();
var token = e("token");
var formdata = new FormData();
formdata.append("id",rnd);
formdata.append("id_folder",idPage);
formdata.append("token_client",token.value);
var url = "frontend/api/order/select.php";
postRequestFile(url,formdata);
}
function closeBlur() {
document.getElementById('blur').style.display="none";
}
function myDropdownOrderTwo() {
e("myDropdownOrderTwo").classList.toggle("show-order-two");
}
function myDropdownOrderHandle() {
e("myDropdownOrderHandle").classList.toggle("show-order-handle");
}
function myDropdownOrder() {
e("myDropdownOrder").classList.toggle("show-order");
}
window.addEventListener("click", function(event) {
if(e("myDropdownOrder").style.display=="none"){

}else{
  // e("myDropdownOrder").style.display="none";
}
});
// var choise='';

// function select() {
//   choise='select';
//     // var username = document.getElementById("username").value;
//     // var password = document.getElementById("password").value;
//     var token = document.getElementById("token").value;
//     var rnd = Math.random();
//     var url = countBack+"frontend/api/contact/select.php?id=" + rnd +"&token_client=" + token;
//     postRequest(url);
// }
function confirmComment() {
if(e('comment-answer').value==''){
  alert('سوال امنیتی را پاسخ دهید.')
}else{
if (confirm('آیا با ثبت سفارش موافق هستید؟')) {
  // window.location = '/login'
  insertComment();
};
}
}
// function confirmComment() {
//   if(e('comment-answer').value==''){
//     alert('سوال امنیتی را پاسخ دهید.')
//   }else{
//   if (confirm('آیا با ثبت سفارش موافق هستید؟')) {
//     window.location = '/login'
//     insertComment();
//   };
//   }
// }

function insertComment() {
choise='insert';
var gram;
var token = document.getElementById("token").value;
var grams=document.getElementsByName('gram');
for (var i = 0; i < grams.length; i++) {
  if(grams[i].checked){
    gram=grams[i].value;
    break;
  }
}
var cassette;
var cassettes=document.getElementsByName('cassette');
for (var i = 0; i < cassettes.length; i++) {
  if(cassettes[i].checked){
    cassette=cassettes[i].value;
    break;
  }
}
var firstColor;
  var firstColors=document.getElementsByName('first-color');
for (var i = 0; i < firstColors.length; i++) {
  if(firstColors[i].checked){
    firstColor=firstColors[i].value;
    break;
  }
}
var secondColor;
var secondColors=document.getElementsByName('second-color');
for (var i = 0; i < secondColors.length; i++) {
  if(secondColors[i].checked){
    secondColor=secondColors[i].value;
    break;
  }
}
var form;
var forms=document.getElementsByName('form');
for (var i = 0; i < forms.length; i++) {
  if(forms[i].checked){
    form=forms[i].value;
    break;
  }
}
var handle;
var handles=document.getElementsByName('handle');
for (var i = 0; i < handles.length; i++) {
  if(handles[i].checked){
    handle=handles[i].value;
    break;
  }
}
var handleColor;
var handleColors=document.getElementsByName('handle-color');
for (var i = 0; i < handleColors.length; i++) {
  if(handleColors[i].checked){
    handleColor=handleColors[i].value;
    break;
  }
}
var eSize = document.getElementById("size");
var sizeValue = eSize.value;
var textSize = eSize.options[eSize.selectedIndex].text;

var ePrint = document.getElementById("print");
var printValue = ePrint.value;
var textPrint = ePrint.options[ePrint.selectedIndex].text;

var ePrintColor = document.getElementById("print-color");
var printValueColor = ePrintColor.value;
var textPrintColor = ePrintColor.options[ePrintColor.selectedIndex].text;

var number=document.getElementById('number').value;
var price=document.getElementById('final').value;
var hiddenId=document.getElementById('hidden-id').value;

var nameBuy=e('title-buy').value
var selectImg11=e('image-name').src
var selectImg21=e('image-name2').src
var selectImg=e('hidden-id-file').value
var selectImg2=e('hidden-id-file2').value
var garmaSelect=0;
if (e('sad').checked) {
    garmaSelect=60;
}
else if (e('happy').checked) {
    garmaSelect=90;
}
else if (e('innormal').checked) {
    garmaSelect=40;
}

var formSelect=0;
if (e('d2').checked) {
    formSelect="افقی";
}
else if (e('d1').checked) {
    formSelect="عمودی";
}

var handelSelect=0;
if (e('c1').checked) {
    handelSelect="زنبیل";
}
else if (e('c2').checked) {
    handelSelect="عادی";
}

var cassettSelect=0;
if (e('a').checked) {
    cassettSelect="بدون کاست";
}
else if (e('b').checked) {
    cassettSelect="کف کاست";
}
else if (e('c').checked) {
    cassettSelect="سه طرف کاست";
}

var printSelect = document.getElementById("print");
// var printSelectValue = printSelect.innerHTML;
var printSelectValue = printSelect.options[printSelect.selectedIndex].text;
var descriptionPrint = e('description-print').value
var sizeSelect = document.getElementById("size");
// var sizeSelectValue = printSelect.value;
var sizeSelectValue = sizeSelect.options[sizeSelect.selectedIndex].text;

var finalSelect=e('final-hidden').value;









if (nameBuy!="") {

  priceFinal=Number(getCookie('finalCookie'))+Number(finalSelect);
  e('price-final').value=priceFinal;
  e('price-final-view').value=ToRial(priceFinal.toString())+" ریال ";
  // final=final.toString();
  // final=ToRial(final);
  if(selectImg11=="https://iranbag.ir/order"){
    selectImg11="<?=$GLOBALS['countBack'].'uploads/'?>logo2.png";
  }
  if(selectImg21=="https://iranbag.ir/order"){
    selectImg21="<?=$GLOBALS['countBack'].'uploads/'?>logo2.png";
  }
  var bb=getCookie('buyCookie');
  if(bb!=null && bb!=""){

  trCookie=JSON.parse(bb);
}
// setCookie('deleteCookie',deleteId,5);
if(getCookie('buyCookie')==null || getCookie('buyCookie')=='' || getCookie('buyCookie')=='NaN' ||  getCookie('buyCookie')==NaN ){
  console.log('11111111');
  deleteId=0;
  setCookie('deleteCookie',deleteId,5);
  console.log('oooooooooo');
  console.log(getCookie('deleteCookie'));
  console.log('ooooooo');
}else{
  console.log('2222222222');
  console.log(getCookie('deleteCookie'));
  console.log('2222222222');
  deleteId=Number(getCookie('deleteCookie'))+1;
  setCookie('deleteCookie',deleteId,5);
  console.log('mmmmmmmmmmm');
  console.log(getCookie('deleteCookie'));
  console.log('mmmmmmmmmmm');
}

console.log('fffffff');
console.log(getCookie('deleteCookie'));
console.log('fffffff');

  // trCookie+="<tr class='trCookieClass' id='deletetr"+deleteId+"'><td>"+nameBuy+"</td><td class='number-buy'>"+number+"</td><td class='img-buy img-ris'><img style='width: 90%'  src='"+selectImg11+"'></td><td class='img-buy img-ris'><img style='width: 90%'  src='"+selectImg21+"'></td><td id='finaltr"+deleteId+"'>"+finalSelect+"</td><td class='deleteTr' onclick='delete2("+deleteId+")'>حذف</td></tr>";







// finalCookie+=Number(finalSelect);
console.log(finalCookie);
// e('tbody-blog-wait').innerHTML=trCookie;
  var aa=trCookie;
  var cc=JSON.stringify(aa);
  setCookie('mytable',cc,5);

  setCookie('finalCookie',Number(finalSelect)+Number(getCookie('finalCookie')),5);

// var eee=Number(getCookie('finalCookie'))+finalSelect;
// e("price-final").setAttribute('value',getCookie('finalCookie'));
  deleteId=deleteId+1;
  deleteFinal=deleteFinal+1;
  e('sad').checked=false;
  e('happy').checked=false;
  e('innormal').checked=false;
  e('d1').checked=false;
  e('d2').checked=false;
  e('c1').checked=false;
  e('c2').checked=false;
  e('a').checked=false;
  e('b').checked=false;
  e('c').checked=false;
  for (var i = 1; i < 12; i++) {
    var colorSelect="i"+i;
    e(colorSelect).checked=false;
  }
  for (var i = 14; i < 22; i++) {
    var colorSelect3="i"+i;
    e(colorSelect3).checked=false;
  }
  e('i13').checked=false;
  for (var j = 1; j < 12; j++) {
    var colorSelect1="j"+j;
    e(colorSelect1).checked=false;
  }
  for (var j = 14; j < 22; j++) {
    var colorSelect3="j"+j;
    e(colorSelect3).checked=false;
  }
  e('j13').checked=false;
  for (var k = 1; k < 12; k++) {
    var colorSelect2="k"+k;
    e(colorSelect2).checked=false;
  }
  e('k13').checked=false;
  for (var k = 14; k < 22; k++) {
    var colorSelect3="k"+k;
    e(colorSelect3).checked=false;
  }
  e('image-name').src="";
  e('image-name2').src="";

  e('print')[0].selected = 'selected';
  e('print-color')[0].selected = 'selected';
  e('k13').checked=false;
  e('color-1').style.backgroundColor='initial';
  e('color-2').style.backgroundColor='initial';
  e('color-3').style.backgroundColor='initial';
  e('final').value="";
  e('title-buy').value="";
  e('number').value="";
  e('description-print').value="";
  e('style-handel-color').style.display="none";






  allBuyList={'gram':gram,'cassette':cassette,'firstColor':firstColor,'secondColor':secondColor,'form':form,'handle':handle,'handleColor':handleColor, 'textSize':sizeValue ,'textPrint':printValue ,'textPrintColor':printValueColor ,'descriptionPrint':descriptionPrint ,'number':number ,'nameBuy':nameBuy ,'selectImg':selectImg ,'selectImg2':selectImg2,'selectImg11':selectImg11 ,'selectImg21':selectImg21,'finalSelect':finalSelect};
  // allBuy[deleteId]=allBuyList;
  // allBuy.push(allBuyList);





  if(getCookie('buyCookie')==null || getCookie('buyCookie')=='' || getCookie('buyCookie')=='NaN' ||  getCookie('buyCookie')==NaN ){
    allBuy=[];
    allBuy.push(allBuyList);
    var jsonAllBuy=JSON.stringify(allBuy);
    setCookie('buyCookie',jsonAllBuy,5);
    allBuyCookie=JSON.parse(getCookie('buyCookie'));
    e('tbody-blog-wait').innerHTML='';
    for (var i = 0; i < allBuyCookie.length; i++) {
      e('tbody-blog-wait').innerHTML+="<tr class='trCookieClass' id='deletetr"+i+"'><td>"+allBuyCookie[i]["nameBuy"]+"</td><td class='number-buy'>"+allBuyCookie[i]["number"]+"</td><td class='img-buy img-ris'><img style='width: 90%'  src='"+allBuyCookie[i]["selectImg11"]+"'></td><td class='img-buy img-ris'><img style='width: 90%'  src='"+allBuyCookie[i]["selectImg21"]+"'></td><td id='finaltr"+i+"'>"+allBuyCookie[i]["finalSelect"]+"</td><td class='deleteTr' onclick='delete2("+i+")'>حذف</td></tr>";

    }

  }else{

    allBuy=[];
    var allBuyCookie=JSON.parse(getCookie('buyCookie'));

    for (var i = 0; i < allBuyCookie.length; i++) {
      allBuy.push(allBuyCookie[i]);
    }


    allBuy.push(allBuyList);

    setCookie('buyCookie',JSON.stringify(allBuy),5);

    allBuyCookie=JSON.parse(getCookie('buyCookie'));
    e('tbody-blog-wait').innerHTML='';
    for (var i = 0; i < allBuyCookie.length; i++) {
      e('tbody-blog-wait').innerHTML+="<tr class='trCookieClass' id='deletetr"+i+"'><td>"+allBuyCookie[i]["nameBuy"]+"</td><td class='number-buy'>"+allBuyCookie[i]["number"]+"</td><td class='img-buy img-ris'><img style='width: 90%'  src='"+allBuyCookie[i]["selectImg11"]+"'></td><td class='img-buy img-ris'><img style='width: 90%'  src='"+allBuyCookie[i]["selectImg21"]+"'></td><td id='finaltr"+i+"'>"+allBuyCookie[i]["finalSelect"]+"</td><td class='deleteTr' onclick='delete2("+i+")'>حذف</td></tr>";

    }


  }




  var jsonAllBuy=JSON.stringify(allBuy);
  // e('input-all-buy-hidden').value=jsonAllBuy;

    e("input-all-buy-hidden").setAttribute('value',jsonAllBuy);
  // allBuyList=[gram,cassette,firstColor,secondColor,form,handle,handleColor, textSize ,textPrint ,textPrintColor ,number ,nameBuy ,selectImg ,selectImg2];
  // allBuy[deleteId]=allBuyList;
  run();
}

// var username = document.getElementById("username").value;
// var phone = document.getElementById("phone").value;
// var name = document.getElementById("name").value;
// var family = document.getElementById("family").value;
// var email = document.getElementById("email").value;
// var password = document.getElementById("password").value;
// var address = document.getElementById("address").value;
// var answer = document.getElementById("comment-answer").value;
// var rnd = Math.random();
// var url = countBack+"frontend/api/authentication/signin/insert.php?id=" + rnd +"&token_client=" + token+"&username=" + username+"&name=" + name+"&family=" + family+"&email=" + email+"&password=" + password+"&address=" + address+"&answer=" + answer;
// postRequest(url);

var inputAllBuyHidden=e('input-all-buy-hidden').value;
var answer = document.getElementById("comment-answer").value;
var  fileUpload=e('file-upload').files[0];
var rnd = Math.random();
var formdata = new FormData();
// formdata.append("id",rnd);
// formdata.append("token_client",token);
// formdata.append("answer",answer);
// formdata.append("gram", gram);
// formdata.append("cassette", cassette);
// formdata.append("first_color", firstColor);
// formdata.append("second_color", secondColor);
// formdata.append("form", form);
// formdata.append("handle", handle);
// formdata.append("handle_color", handleColor);
// formdata.append("size", sizeValue);
// formdata.append("number", number);
// formdata.append("price", price);
// formdata.append("hidden-id", hiddenId);
// formdata.append("print", 1);
// formdata.append("print_color", textPrintColor);
// formdata.append("json_all_buy", inputAllBuyHidden);
// var url = "frontend/api/order/insert.php";/////////////////////////////////////
// postRequestFile(url,formdata);deleteFinal/////////////////////////////////////////
e('dropbtnOrderUser1').style.backgroundColor="#cacaca";
e('dropbtnOrderUser1-3').style.backgroundColor="#cacaca";
e('dropbtnOrderUser1-1').style.backgroundColor="#cacaca";
e('dropbtnOrderUser1').style.backgroundImage='none';
e('dropbtnOrderUser1-3').style.backgroundImage='none';
e('dropbtnOrderUser1-1').style.backgroundImage='none';
}
function closeColorUser(){
  // e('myDropdownOrder').style.display="none";
  // e('dropbtnOrderUser1-3').style.display="none";
  // e('dropbtnOrderUser1-1').style.display="none";
}





function delete2(deleteSelect){
var deleteVar="deletetr"+deleteSelect;
e(deleteVar).style.display='none';
var finalVar="finaltr"+deleteSelect;
 var finalEnd=e(finalVar).innerHTML;
 var finalStart=e('price-final').value;
 e('price-final').value=Number(finalStart)-Number(finalEnd);
 priceFinal=Number(finalStart)-Number(finalEnd);
 e('price-final-view').value=ToRial(e('price-final').value.toString());
 // delete (allBuy[deleteSelect]);
 // delete allBuy[deleteSelect];
 // var jsonAllBuy=JSON.stringify(allBuy);
 // e('input-all-buy-hidden').value=jsonAllBuy;

run();
// setCookie('finalCookie',Number(finalSelect)+Number(getCookie('finalCookie')),5);
setCookie('finalCookie',e('price-final').value,5);
window.location='order';
// setCookie('buyCookie',JSON.stringify(allBuy),5);
console.log('wwww');


}









function viewBuy(id,type) {
var cassette;
// cassette=myObj.Data3[17]['cassette'];


for (var i = 0; i < myObj.Data3.length; i++) {
if(myObj.Data3[i]['buy_castomer_id']==id){
  e('dell0').innerHTML=myObj.Data3[i]['buy_castomer_id'];
  e('dell1').innerHTML="گرماژ: "+myObj.Data3[i]['garma'];
  e('dell2').innerHTML="کاست: "+myObj.Data3[i]['cassette'];
  e('dell3').innerHTML="سایز: "+myObj.Data3[i]['size'];
  e('dell4').innerHTML="فرم: "+myObj.Data3[i]['form'];
  e('dell5').innerHTML="قیمت: "+myObj.Data3[i]['price'];
  e('dell6').innerHTML="دسته: "+myObj.Data3[i]['handel'];
  e('dell7').innerHTML="رنگ دسته: "+myObj.Data3[i]['handel_color'];
  e('dell8').innerHTML="رنگ اول: "+myObj.Data3[i]['first_color'];
  e('dell9').innerHTML="رنگ دوم: "+myObj.Data3[i]['second_color'];
  e('dell10').innerHTML="تعداد: "+myObj.Data3[i]['number'];
  e('transport-phone').value=myObj.Data3[i]['mobile'];
  e('transport-phone3').value=myObj.Data3[i]['mobile2'];
  e('transport-phone2').value=myObj.Data3[i]['phone'];
  e('transport-city').value=myObj.Data3[i]['city'];
  e('transport-state').value=myObj.Data3[i]['state'];
  e('panel-div-input').value=myObj.Data3[i]['address'];
}
if(type==1){
  e('transport-phone').style.display='none';
  e('transport-phone').style.display='none';
  e('transport-phone3').style.display='none';
  e('transport-phone2').style.display='none';
  e('transport-city').style.display='none';
  e('transport-state').style.display='none';
  e('panel-div-input').style.display='none';
  e('transport').style.display='none';
  e('sendTransport').style.display='none';
}
}



// e('three-panel').style.display='block';
}

function sendTransport() {
  for (var i = 0; i < idSlells.length; i++) {
var rnd = Math.random();
var formdata = new FormData();
formdata.append("id",rnd);
formdata.append("token_client",token);

var idBuy = idSlells[i];
var transportPhone = e('transport-phone').value;
var transportPhone2 = e('transport-phone2').value;
var transportPhone3 = e('transport-phone3').value;
var transportCity = e('transport-city').value;
var transportState = e('transport-state').value;
var panelDivInput = e('panel-div-input').value;


var transport = document.getElementById("transport");
var textTransport = transport.options[transport.selectedIndex].text;


formdata.append("id_buy", idBuy);
formdata.append("mobile", transportPhone);
formdata.append("mobile2", transportPhone2);
formdata.append("phone", transportPhone3);
formdata.append("transport_city", transportCity);
formdata.append("transport_state", transportState);
formdata.append("panel_div_input", panelDivInput);
formdata.append("text_transport", textTransport);







var url = "frontend/api/order/update.php";
postRequestFile(url,formdata);
}
  if (confirm("درخواست ارسال بار انجام شد.")) {
  window.location="/order";
  }
}
function imgDelete(idDelete,imageName){
choise='delete';
var rnd = Math.random();
var token = e("token");
var formdata = new FormData();
formdata.append("id",rnd);
formdata.append("id_delete",idDelete);
formdata.append("image_name",imageName);
formdata.append("token_client",token.value);
var url = "kernel/plugins/files_manager/delete.php";
postRequestFile(url,formdata);
}

function sendProfile() {
  var rnd = Math.random();
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("token_client",token);

  var idUser=<?=@$_SESSION['id_user']?>;
  var name=e('profile-name-input').value;
  var family=e('profile-family-input').value;
  var password=e('profile-pass-input').value;
  var repPassword=e('profile-reppass-input').value;


  formdata.append("id_user", idUser);
  formdata.append("name", name);
  formdata.append("family", family);
  formdata.append("password", password);



  if (password==repPassword) {
    var url = "frontend/api/profile/update.php";
    postRequestFile(url,formdata);
    alert('موفقیت آمیز')
  }
  else {
    alert('گذرواژه با تکرار آن یکی نیست.')
  }



  if (password=='') {
    alert('گذرواژه خالی می باشد.');
  }
}
function pageSendSell() {
  e('three').checked=true;
//   for (var i = 0; i < idSlells.length; i++) {
//     // idSlells[i]
//
//
//
//
//
//
//
//
//   var rnd = Math.random();
//   var formdata = new FormData();
//   formdata.append("id",rnd);
//   formdata.append("token_client",token);
//
//   var idBuy = idSlells[i];
//   var transportPhone = e('transport-phone').value;
//   var transportPhone2 = e('transport-phone2').value;
//   var transportPhone3 = e('transport-phone3').value;
//   var transportCity = e('transport-city').value;
//   var transportState = e('transport-state').value;
//   var panelDivInput = e('panel-div-input').value;
//
//
//   var transport = document.getElementById("transport");
//   var textTransport = transport.options[transport.selectedIndex].text;
//
//
//   formdata.append("id_buy", idBuy);
//   formdata.append("mobile", transportPhone);
//   formdata.append("mobile2", transportPhone2);
//   formdata.append("phone", transportPhone3);
//   formdata.append("transport_city", transportCity);
//   formdata.append("transport_state", transportState);
//   formdata.append("panel_div_input", panelDivInput);
//   formdata.append("text_transport", textTransport);
//
//
//
//
//
//
//
//   var url = "frontend/api/order/update.php";
//   postRequestFile(url,formdata);
// }
//     if (confirm("درخواست ارسال بار انجام شد.")) {
//     window.location="/order";
//     }

























}
function deleteCookie(){
  setCookie('mytable','',5);
  setCookie('finalCookie',0,5);
  setCookie('buyCookie','',5);
  setCookie('deleteCookie','',5);
}
