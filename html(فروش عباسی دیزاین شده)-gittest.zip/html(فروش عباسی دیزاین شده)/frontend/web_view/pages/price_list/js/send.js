function select() {
  updatepage();
}
// function login() {
//     // var username = document.getElementById("username").value;
//     // var password = document.getElementById("password").value;
//     var token = document.getElementById("token").value;
//     var rnd = Math.random();
//     var url = countBack+"frontend/api/price_list/select.php?id=" + rnd +"&token_client=" + token;
//     postRequest(url);
// }
// login();
