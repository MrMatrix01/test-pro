function updatepage() {
   // var myObj = JSON.parse(str);
  if(myObj.messageCode.code=="110"){
    e('about-all').innerHTML=myObj.Data[0]['content'];
  }else{
    // document.getElementById("result").innerHTML = myObj.messageCode.code;
  }
}
// function updatepage(str) {
//    var myObj = JSON.parse(str);
//   if(myObj.messageCode.code=="110"){
//     e('about-all').innerHTML=myObj.Data[0]['content'];
//   }else{
//     // document.getElementById("result").innerHTML = myObj.messageCode.code;
//   }
// }
