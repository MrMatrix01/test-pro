<?php onload('frontend/api/price_list/select.php')?>
<main>
  <div class="about">
    <div class="about-content">
      <h3 class="about-h3">لیست قیمت ها</h3>
      <div id="about-all">

      </div>
    </div>
  </div>
</main>
