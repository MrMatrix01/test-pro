var choise='';
function select() {
  choise='select';
  updatepage();
}
// function select() {
//   choise='select';
//     // var username = document.getElementById("username").value;
//     // var password = document.getElementById("password").value;
//     var token = document.getElementById("token").value;
//     var rnd = Math.random();
//     var url = countBack+"frontend/api/contact/select.php?id=" + rnd +"&token_client=" + token;
//     postRequest(url);
// }
function confirmComment() {
  if (confirm('آیا با ثبت نظر موافق هستید؟')) {
    // window.location = '?del='+id
    insertComment();
  };
}
function insertComment() {
  choise='insert';
  var token = document.getElementById("token").value;
  var name = document.getElementById("comment-name").value;
  var family = document.getElementById("comment-family").value;
  var email = document.getElementById("comment-email").value;
  var title = document.getElementById("comment-title").value;
  var content = document.getElementById("comment-content").value;
  var answer = document.getElementById("comment-answer").value;
  var rnd = Math.random();
  var url = countBack+"frontend/api/comment/insert.php?id=" + rnd +"&token_client=" + token+"&name=" + name+"&family=" + family+"&email=" + email+"&title=" + title+"&content=" + content+"&answer=" + answer;
  postRequest(url);
}
