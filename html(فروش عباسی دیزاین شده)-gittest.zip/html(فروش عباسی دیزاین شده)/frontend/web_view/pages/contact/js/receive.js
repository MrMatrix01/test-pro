function updatepage(str) {
  if (str != undefined) {
    myObj = JSON.parse(str);
  }
  if (myObj.messageCode.code == "110") {
    if (choise == 'select') {
      e('about-all').innerHTML = myObj.Data[0]['content'];
    } else if (choise == 'insert') {
      alert('نظر با موفقیت ثبت شد.');
      // var delayInMilliseconds = 1000; //1 second
      window.location = "./";
    }
  } else if (myObj.messageCode.code == "107") {
    alert('کد امنیتی نا معتبر می باشد');
    window.location = "contact";
    // document.getElementById("result").innerHTML = myObj.messageCode.code;

  }

}
// function updatepage(str) {
//   console.log(str);
//    var myObj = JSON.parse(str);
//   if(myObj.messageCode.code=="110"){
//     if(choise=='select'){
//     e('about-all').innerHTML=myObj.Data[0]['content'];
//   }else if(choise=='insert'){
//     alert('نظر با موفقیت ثبت شد.');
//   }
//   }else{
//     // document.getElementById("result").innerHTML = myObj.messageCode.code;
//
//   }
//
// }
