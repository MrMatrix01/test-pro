<?php
onload('frontend/api/contact/select.php');
?>
<main>
  <div class="about">
    <div class="about-content">
      <h3 class="about-h3">تماس با ما</h3>
      <div id="about-all">

      </div>
    </div>
    <div class="comment">
      <h3 class="about-h3">فرم تماس</h3>
        <form class="form-comment" action="index.html" method="post">
          <div class="row-comment">
            <div class="colomn-comment">
              <div class="title-coment">
                نام:
              </div>
              <div class="input-comment">
                <input type="text" class="input-text-comment" id="comment-name" name="" value="">
              </div>
            </div>
            <div class="colomn-comment">
              <div class="title-coment">
                نام خانوادگی:
              </div>
              <div class="input-comment">
                <input type="text" class="input-text-comment" id="comment-family" name="" value="">
              </div>
            </div>
          </div>
          <div class="row-comment">
            <div class="title-coment">
            ایمیل:
            </div>
            <input type="email" class="input-text-wide-comment"  id="comment-email" name="" value="">
          </div>
          <div class="row-comment">
            <div class="title-coment">
            موضوع:
            </div>
            <input type="text" class="input-text-wide-comment" name="" id="comment-title" value="">
          </div>
          <div class="row-comment">
            <div class="title-comment">
            متن پیام:
            </div>
            <textarea name="name" class="textarea-comment" id="comment-content"></textarea>
          </div>
          <div class="row-comment">
            <div class="title-coment">
            لطفا جواب سوال روبرو را در کادر پایین بنویسید:
            <img src="kernel/lib/captcha.php" class="captcha" alt="">
            </div>
            <input type="text" class="input-text-wide-comment" id="comment-answer" name="" value="">
          </div>
          <div class="row-comment">
            <input type="button" onclick="confirmComment()" name="" class="submit-comment" value="ارسال">
          </div>
        </form>
    </div>
  </div>
</main>
