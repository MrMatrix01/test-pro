<?php onload('frontend/api/slide_more/select.php')?>
<main>
  <div class="blog" id="blog">
    <div id="receive">
    <div class="blog-more-content" id="blog-content">
      <h1 class="blog-h4"></h1>
      <div class="blog-div-min">
        <img src="api/uploads/parsgraphic-office-1.jpg" class="blog-more-img" alt="">
        <p class="blog-p">
        </p>
      </div>
    </div>
    </div>
  </div>
</main>
<div id="result">

</div>
