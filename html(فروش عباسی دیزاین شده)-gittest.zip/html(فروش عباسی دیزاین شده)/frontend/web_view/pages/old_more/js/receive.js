function updatepage() {
  // var myObj = JSON.parse(str);
  if(myObj.messageCode.code=="110"){
    for (var i = 1; i < myObj.Data.length; i++) {
      // document.getElementById("result").innerHTML += myObj.Data[i].id;
      document.getElementById('blog').innerHTML+=document.getElementById('receive').innerHTML;
      // blogH4[2].innerHTML='i';

    }
    let blogH4 =  document.querySelectorAll('.blog-h4');
    let blogImg =  document.querySelectorAll('.blog-more-img');
    let blogP =  document.querySelectorAll('.blog-p');
    let blogA =  document.querySelectorAll('.blog-a');
    let blogDiv =  document.querySelectorAll('.blog-div-min');
    for (var j = 0; j < blogH4.length; j++) {
       // document.getElementById("result").innerHTML = myObj.Data[i]['img'];
       if(myObj.Data[j]['post_title']==undefined){
         window.location = "/";
       }else{
       console.log(myObj.Data[j]['post_title']);
      blogH4[j].innerHTML =myObj.Data[j]['post_title'];
      // if(myObj.Data[j]['id']>9199){
      // blogImg[j].style.display='none';
        blogDiv[j].style.width="100%";
    // }else {
      blogImg[j].src =myObj.Data[j]['guid'];

    // }

      blogP[j].innerHTML =myObj.Data[j]['post_content'];
      // blogA[j].href +=myObj.Data[j]['id'];
    }
    }
  }

}

// function updatepage(str) {
//   // document.getElementById("result").innerHTML =str;
//   var myObj = JSON.parse(str);
//   if(myObj.messageCode.code=="110"){
//     for (var i = 1; i < myObj.Data.length; i++) {
//       // document.getElementById("result").innerHTML += myObj.Data[i].id;
//       document.getElementById('blog').innerHTML+=document.getElementById('receive').innerHTML;
//       // blogH4[2].innerHTML='i';
//
//     }
//     let blogH4 =  document.querySelectorAll('.blog-h4');
//     let blogImg =  document.querySelectorAll('.blog-more-img');
//     let blogP =  document.querySelectorAll('.blog-p');
//     let blogA =  document.querySelectorAll('.blog-a');
//     let blogDiv =  document.querySelectorAll('.blog-div-min');
//     for (var j = 0; j < blogH4.length; j++) {
//        // document.getElementById("result").innerHTML = myObj.Data[i]['img'];
//        if(myObj.Data[j]['post_title']==undefined){
//          window.location = "/";
//        }else{
//        console.log(myObj.Data[j]['post_title']);
//       blogH4[j].innerHTML =myObj.Data[j]['post_title'];
//       // if(myObj.Data[j]['id']>9199){
//       // blogImg[j].style.display='none';
//         blogDiv[j].style.width="100%";
//     // }else {
//       blogImg[j].src =myObj.Data[j]['guid'];
//
//     // }
//
//       blogP[j].innerHTML =myObj.Data[j]['post_content'];
//       // blogA[j].href +=myObj.Data[j]['id'];
//     }
//     }
//     //   window.location = "../../doshboard";
//     // }else{
//     //   // document.getElementById("result").innerHTML = myObj.messageCode.code;
//     //
//   }
//
// }
// // if(myObj.Data[j]['post_title']==undefined){
// //   window.location = "/";
// // }else{
// // console.log(myObj.Data[j]['post_title']);
