function updatepage() {
  // var myObj = JSON.parse(str);
  if(myObj.messageCode.code=="110"){
    var bas=e('receive').innerHTML;
    e('blog').innerHTML='';
    for (var i = 1; i < myObj.Data.length; i++) {
      e('blog').innerHTML+=bas;
    }
    let blogH4 =  document.querySelectorAll('.blog-h4');
    let blogImg =  document.querySelectorAll('.blog-img');
    let blogP =  document.querySelectorAll('.blog-p');
    let blogDiv =  document.querySelectorAll('.blog-div');
    let blogA =  document.querySelectorAll('.blog-a');
    var blogCount=Math.ceil(myObj.Data2['blog_count']/20);
    var blogPageNumber=e('blog-page-number');
    var row1=document.querySelectorAll('.row1');
    for (var j = 0; j < blogH4.length; j++) {
      blogH4[j].innerHTML =myObj.Data[j]['post_title'];
      blogImg[j].src =myObj.Data[j]['guid'];
      // blogP[j].innerHTML =myObj.Data[j]['post_content'];
      blogA[j].href ='gallery/more/'+myObj.Data[j]['id']+'/'+myObj.Data[j]['seo_url'];
    }
    var intUrlId=parseInt(urlId);
    var intBlogCount=parseInt(blogCount);
    // -------------------------------------------------------------------------------
    row1[0].innerHTML='<a href="gallery?page=1" class="page-number-a">'+(1)+'</a>';
    if(blogCount>1){
      row1[0].innerHTML+='<a href="gallery?page=2" class="page-number-a">'+(2)+'</a>';
    }
    if(blogCount>2){
      row1[0].innerHTML+='<a href="gallery?page=3" class="page-number-a">'+(3)+'</a>';
    }
    if(urlId>5){
      row1[1].innerHTML+='<span class="page-number-span">...</span>';
    }
    for (var i =urlId;i<(urlId+3);i++) {
      if(i>4 && i<(blogCount-1)){
        row1[1].innerHTML+='<a href="gallery?page='+(i-1)+'" class="page-number-a">'+(i-1)+'</a>';
      }
    }
    if((urlId )<(blogCount-4)){
      row1[1].innerHTML+='<span class="page-number-span">...</span>';
    }
    if(blogCount>5){
      row1[2].innerHTML+= '<a href="gallery?page='+(blogCount-2)+'" class="page-number-a">'+(blogCount-2)+'</a>';
    }
    if(blogCount>4){
      row1[2].innerHTML+='<a href="gallery?page='+(blogCount-1)+'" class="page-number-a">'+(blogCount-1)+'</a>';
    }
    if(blogCount>3){
      row1[2].innerHTML+='<a href="gallery?page='+blogCount+'" class="page-number-a">'+(blogCount)+'</a>';
    }
  }
}
// function updatepage(str) {
//   var myObj = JSON.parse(str);
//   if(myObj.messageCode.code=="110"){
//     var bas=e('receive').innerHTML;
//     e('blog').innerHTML='';
//     for (var i = 1; i < myObj.Data.length; i++) {
//       e('blog').innerHTML+=bas;
//     }
//     let blogH4 =  document.querySelectorAll('.blog-h4');
//     let blogImg =  document.querySelectorAll('.blog-img');
//     let blogP =  document.querySelectorAll('.blog-p');
//     let blogDiv =  document.querySelectorAll('.blog-div');
//     let blogA =  document.querySelectorAll('.blog-a');
//     var blogCount=Math.ceil(myObj.Data2['blog_count']/20);
//     var blogPageNumber=e('blog-page-number');
//     var row1=document.querySelectorAll('.row1');
//     for (var j = 0; j < blogH4.length; j++) {
//       blogH4[j].innerHTML =myObj.Data[j]['post_title'];
//       blogImg[j].src =myObj.Data[j]['guid'];
//       // blogP[j].innerHTML =myObj.Data[j]['post_content'];
//       blogA[j].href ='gallery/more/'+myObj.Data[j]['id']+'/'+myObj.Data[j]['seo_url'];
//     }
//     var intUrlId=parseInt(urlId);
//     var intBlogCount=parseInt(blogCount);
//     // -------------------------------------------------------------------------------
//     row1[0].innerHTML='<a href="gallery?page=1" class="page-number-a">'+(1)+'</a>';
//     if(blogCount>1){
//       row1[0].innerHTML+='<a href="gallery?page=2" class="page-number-a">'+(2)+'</a>';
//     }
//     if(blogCount>2){
//       row1[0].innerHTML+='<a href="gallery?page=3" class="page-number-a">'+(3)+'</a>';
//     }
//     if(urlId>5){
//       row1[1].innerHTML+='<span class="page-number-span">...</span>';
//     }
//     for (var i =urlId;i<(urlId+3);i++) {
//       if(i>4 && i<(blogCount-1)){
//         row1[1].innerHTML+='<a href="gallery?page='+(i-1)+'" class="page-number-a">'+(i-1)+'</a>';
//       }
//     }
//     if((urlId )<(blogCount-4)){
//       row1[1].innerHTML+='<span class="page-number-span">...</span>';
//     }
//     if(blogCount>5){
//       row1[2].innerHTML+= '<a href="gallery?page='+(blogCount-2)+'" class="page-number-a">'+(blogCount-2)+'</a>';
//     }
//     if(blogCount>4){
//       row1[2].innerHTML+='<a href="gallery?page='+(blogCount-1)+'" class="page-number-a">'+(blogCount-1)+'</a>';
//     }
//     if(blogCount>3){
//       row1[2].innerHTML+='<a href="gallery?page='+blogCount+'" class="page-number-a">'+(blogCount)+'</a>';
//     }
//   }
// }
