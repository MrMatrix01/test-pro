<?php onload('frontend/api/home/select_all.php')?>
<script type="text/javascript" language="javascript" src="frontend/web_view/themes/js/slide.js" charset="utf-8"></script>
<main>
  <div class="slide">
    <div class="carousel">
      <div class="carousel-inner" id="carousel-inner">
        <a href="#" class="carousel-item">
          <img src="" alt="" class="carousel-item-img" alt="">
          <h2 class="carousel-item-h3"></h2>
        </a>
        <!-- <div class="carousel-item">
          <img src="" class="carousel-item-img" alt="">
          <h2 class="carousel-item-h3">سلام</h2>
        </div> -->
      </div>
      <div class="carousel-controls">
        <div class="prev">
          <i class="fa fa-chevron-left"></i>
        </div>
        <div class="next">
          <i class="fa fa-chevron-right"></i>
        </div>
      </div>
      <div class="carousel-indicators"></div>
    </div>
  </div>
  <div class="border-gallery-product">
    <div class="titr-gallery">
      گالری محصولات
    </div>
    <a class="all-view"  href="./gallery">
      مشاهده همه
    </a>
    <div class="gallery-product">
      <div class="carousel-gallery">
        <div class="carousel-inner-gallery" id="carousel-inner-gallery">
          <div class="img-gallery">
            <a href="#" class="carousel-item-gallery">
              <img src="" alt="" class="image-gallery" alt="">
              <h2 class="word-gallery"></h2>
            </a>
            <a href="#" class="carousel-item-gallery">
              <img src="" alt="" class="image-gallery" alt="">
              <h2 class="word-gallery">
              </h2>
            </a>
          </div>
        </div>
        <div class="carousel-indicators-gallery"></div>
      </div>
      <div class="carousel-controls-gallery">
        <div class="prev-gallery">
          <i class="fa fa-chevron-left"></i>
        </div>
        <div class="next-gallery">
          <i class="fa fa-chevron-right"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="border-gallery-product">
    <div class="titr-gallery">
      آخرین مقالات
    </div>
    <a class="all-view" href="./blog">
      مشاهده همه
    </a>
    <div class="gallery-product">

      <div class="carousel-article">
        <div class="carousel-inner-article" id="carousel-inner-article">
            <div class="img-article">
              <div class="carousel-item-article">
                <img src="" class="image-article" alt="">
                <div class="triangle">
                  <div class="square-right"></div>
                  <div class="triangle-down"></div>
                  <div class="square-left"></div>
                </div>
              </div>
              <div class="content-article">
                <div class="child-article">
                  <a href="#" class="a-article">
                  <h2 class="h4-article">
                  </h2>
                  </a>
                  <div class="p-content-article"></div>
                </div>
              </div>
              <!-- <a href="#" class="a-article">aaa</a> -->
            </div>
        </div>
        <div class="carousel-indicators-article"></div>
      </div>
      <div class="carousel-controls-article">
        <div class="prev-article">
          <i class="fa fa-chevron-left"></i>
        </div>
        <div class="next-article">
          <i class="fa fa-chevron-right"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="border-gallery-product">
    <div class="titr-gallery">
      چرا ایران بگ را انتخاب می کنند؟
    </div>
    <div class="gallery-product" id="why-gallery-product">
      <!-- <div class="gallery-why"> -->
      <div class="why-description">
        <a href="#" class="why-a"></a>
        <p class="why-p">
        </p>
      </div>
    </div>
  </div>
  <div class="border-gallery-product">
    <a href="./about" class="titr-gallery">
      درباره ایران بگ
    </a>
    <div class="gallery-product">
      <p class="p-about" id="p-about">
      </p>
    </div>
  </div>
</main>
