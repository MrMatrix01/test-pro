function updatepage() {
  // var myObj = JSON.parse(str);
  if(myObj.messageCode.code=="110"){

    var htmlData=e('carousel-inner-gallery').innerHTML;
    for (var i = 0; i < (myObj.Data['gallery'].length/2) && i<7; i++) {
      htmlData+=e('carousel-inner-gallery').innerHTML;
    }
    e('carousel-inner-gallery').innerHTML=htmlData;
    let imageGallery =  document.querySelectorAll('.image-gallery');
    let wordGallery =  document.querySelectorAll('.word-gallery');
    let aWordGallery =  document.querySelectorAll('.a-word-gallery');
    let carouselItemGallery =  document.querySelectorAll('.carousel-item-gallery');
    // e('carousel-inner-article').innerHTML="";
    for (var j = 0; j < myObj.Data['gallery'].length  && j<16; j++) {
      imageGallery[j].src=myObj.Data['gallery'][j]['Preview_image'];
      imageGallery[j].alt=myObj.Data['gallery'][j]['gallery_title'];
      wordGallery[j].innerHTML=myObj.Data['gallery'][j]['gallery_title'];
      carouselItemGallery[j].href='gallery/more/'+myObj.Data['gallery'][j]['id']+'/'+myObj.Data['gallery'][j]['seo_url'];
      // aWordGallery[j].href="a/";
      // aArticle[j].href='blog/more/'+myObj.Data[j]['id'];
    }
    var htmlData=e('carousel-inner').innerHTML;
    for (var i = 0; i < myObj.Data['slide'].length && i<7; i++) {
      htmlData+=e('carousel-inner').innerHTML;
    }
    e('carousel-inner').innerHTML=htmlData;
    let carouselItemImg =  document.querySelectorAll('.carousel-item-img');
    let carouselItem =  document.querySelectorAll('.carousel-item');
    let carouselItemH3 =  document.querySelectorAll('.carousel-item-h3');
    // let h4Article =  document.querySelectorAll('.h4-article');
    // let pContentArticle =  document.querySelectorAll('.p-content-article');
    for (var j = 0; j < myObj.Data['slide'].length && j<8; j++) {
      carouselItemImg[j].src=myObj.Data['slide'][j]['img_slide'];
      carouselItem[j].href='slide/more/'+myObj.Data['slide'][j]['id']+'/'+myObj.Data['slide'][j]['seo_url'];
      carouselItemH3[j].innerHTML=myObj.Data['slide'][j]['title'];
      carouselItemImg[j].alt=myObj.Data['slide'][j]['title'];
    }
    // --------------------why---------
    var htmlWhy=e('why-gallery-product').innerHTML;
    for (var i = 0; i < myObj.Data['why'].length && i<5; i++) {
      htmlWhy+=e('why-gallery-product').innerHTML;
    }
    e('why-gallery-product').innerHTML=htmlWhy;
    let whyA =  document.querySelectorAll('.why-a');
    let whyP =  document.querySelectorAll('.why-p');
    for (var j = 0; j < myObj.Data['why'].length && j<6; j++) {
      whyA[j].innerHTML=myObj.Data['why'][j]['title'];
      whyA[j].href='why/more/'+myObj.Data['why'][j]['id']+'/'+myObj.Data['why'][j]['seo_url'];
      whyP[j].innerHTML=myObj.Data['why'][j]['min_content'];
    }
    // --------------------about---------
    e('p-about').innerHTML=myObj.Data['about'][0]['min_content'];
    // --------------------------
    var htmlData=e('carousel-inner-article').innerHTML;
    for (var i = 0; i < myObj.Data['article'].length && i<7; i++) {
      htmlData+=e('carousel-inner-article').innerHTML;
    }
    e('carousel-inner-article').innerHTML=htmlData;
    let imageArticle =  document.querySelectorAll('.image-article');
    let h4Article =  document.querySelectorAll('.h4-article');
    let pContentArticle =  document.querySelectorAll('.p-content-article');
    let aArticle =  document.querySelectorAll('.a-article');
    let imgArticle =  document.querySelectorAll('.img-article');
    // e('carousel-inner-article').innerHTML="";
    for (var j = 0; j < myObj.Data['article'].length && j<8; j++) {
      imageArticle[j].src=myObj.Data['article'][j]['guid'];
      imageArticle[j].alt=myObj.Data['article'][j]['post_title'];
      h4Article[j].innerHTML=myObj.Data['article'][j]['post_title'];
      pContentArticle[j].innerHTML=myObj.Data['article'][j]['post_content'];
      if(myObj.Data['article'][j]['url']!==null){
        console.log(myObj.Data['article'][j]['url']);
        aArticle[j].href ='../'+myObj.Data['article'][j]['url'];
      }else{
        aArticle[j].href='blog/more/'+myObj.Data['article'][j]['id']+'/'+myObj.Data['article'][j]['seo_url'];
      }
      //   e('carousel-inner-article').innerHTML+='<div class="img-article"><div class="carousel-item-article"><img src="'+myObj.Data[i]["guid"]+'" class="image-article" alt=""><div class="triangle"><div class="square-right"></div><div class="triangle-down"></div><div class="square-left"></div></div></div><div class="content-article"><h4 class="h4-article">'+myObj.Data[i]["post_title"]+'</h4><div class="p-content-article">'+myObj.Data[i]["post_content"]+'</div></div><a href="#" class="a-article">ادامه مطلب</a></div>';
    }
  }else{
  }
  slide();
}
// function updatepage(str) {
//   var myObj = JSON.parse(str);
//   if(myObj.messageCode.code=="110"){
//
//     var htmlData=e('carousel-inner-gallery').innerHTML;
//     for (var i = 0; i < (myObj.Data['gallery'].length/2) && i<7; i++) {
//       htmlData+=e('carousel-inner-gallery').innerHTML;
//     }
//     e('carousel-inner-gallery').innerHTML=htmlData;
//     let imageGallery =  document.querySelectorAll('.image-gallery');
//     let wordGallery =  document.querySelectorAll('.word-gallery');
//     let aWordGallery =  document.querySelectorAll('.a-word-gallery');
//     let carouselItemGallery =  document.querySelectorAll('.carousel-item-gallery');
//     // e('carousel-inner-article').innerHTML="";
//     for (var j = 0; j < myObj.Data['gallery'].length  && j<16; j++) {
//       imageGallery[j].src=myObj.Data['gallery'][j]['Preview_image'];
//       imageGallery[j].alt=myObj.Data['gallery'][j]['gallery_title'];
//       wordGallery[j].innerHTML=myObj.Data['gallery'][j]['gallery_title'];
//       carouselItemGallery[j].href='gallery/more/'+myObj.Data['gallery'][j]['id']+'/'+myObj.Data['gallery'][j]['seo_url'];
//       // aWordGallery[j].href="a/";
//       // aArticle[j].href='blog/more/'+myObj.Data[j]['id'];
//     }
//     var htmlData=e('carousel-inner').innerHTML;
//     for (var i = 0; i < myObj.Data['slide'].length && i<7; i++) {
//       htmlData+=e('carousel-inner').innerHTML;
//     }
//     e('carousel-inner').innerHTML=htmlData;
//     let carouselItemImg =  document.querySelectorAll('.carousel-item-img');
//     let carouselItem =  document.querySelectorAll('.carousel-item');
//     let carouselItemH3 =  document.querySelectorAll('.carousel-item-h3');
//     // let h4Article =  document.querySelectorAll('.h4-article');
//     // let pContentArticle =  document.querySelectorAll('.p-content-article');
//     for (var j = 0; j < myObj.Data['slide'].length && j<8; j++) {
//       carouselItemImg[j].src=myObj.Data['slide'][j]['img_slide'];
//       carouselItem[j].href='slide/more/'+myObj.Data['slide'][j]['id']+'/'+myObj.Data['slide'][j]['seo_url'];
//       carouselItemH3[j].innerHTML=myObj.Data['slide'][j]['title'];
//       carouselItemImg[j].alt=myObj.Data['slide'][j]['title'];
//     }
//     // --------------------why---------
//     var htmlWhy=e('why-gallery-product').innerHTML;
//     for (var i = 0; i < myObj.Data['why'].length && i<5; i++) {
//       htmlWhy+=e('why-gallery-product').innerHTML;
//     }
//     e('why-gallery-product').innerHTML=htmlWhy;
//     let whyA =  document.querySelectorAll('.why-a');
//     let whyP =  document.querySelectorAll('.why-p');
//     for (var j = 0; j < myObj.Data['why'].length && j<6; j++) {
//       whyA[j].innerHTML=myObj.Data['why'][j]['title'];
//       whyA[j].href='why/more/'+myObj.Data['why'][j]['id']+'/'+myObj.Data['why'][j]['seo_url'];
//       whyP[j].innerHTML=myObj.Data['why'][j]['min_content'];
//     }
//     // --------------------about---------
//     e('p-about').innerHTML=myObj.Data['about'][0]['min_content'];
//     // --------------------------
//     var htmlData=e('carousel-inner-article').innerHTML;
//     for (var i = 0; i < myObj.Data['article'].length && i<7; i++) {
//       htmlData+=e('carousel-inner-article').innerHTML;
//     }
//     e('carousel-inner-article').innerHTML=htmlData;
//     let imageArticle =  document.querySelectorAll('.image-article');
//     let h4Article =  document.querySelectorAll('.h4-article');
//     let pContentArticle =  document.querySelectorAll('.p-content-article');
//     let aArticle =  document.querySelectorAll('.a-article');
//     let imgArticle =  document.querySelectorAll('.img-article');
//     // e('carousel-inner-article').innerHTML="";
//     for (var j = 0; j < myObj.Data['article'].length && j<8; j++) {
//       imageArticle[j].src=myObj.Data['article'][j]['guid'];
//       imageArticle[j].alt=myObj.Data['article'][j]['post_title'];
//       h4Article[j].innerHTML=myObj.Data['article'][j]['post_title'];
//       pContentArticle[j].innerHTML=myObj.Data['article'][j]['post_content'];
//       if(myObj.Data['article'][j]['url']!==null){
//         console.log(myObj.Data['article'][j]['url']);
//         aArticle[j].href ='../'+myObj.Data['article'][j]['url'];
//       }else{
//         aArticle[j].href='blog/more/'+myObj.Data['article'][j]['id']+'/'+myObj.Data['article'][j]['seo_url'];
//       }
//       //   e('carousel-inner-article').innerHTML+='<div class="img-article"><div class="carousel-item-article"><img src="'+myObj.Data[i]["guid"]+'" class="image-article" alt=""><div class="triangle"><div class="square-right"></div><div class="triangle-down"></div><div class="square-left"></div></div></div><div class="content-article"><h4 class="h4-article">'+myObj.Data[i]["post_title"]+'</h4><div class="p-content-article">'+myObj.Data[i]["post_content"]+'</div></div><a href="#" class="a-article">ادامه مطلب</a></div>';
//     }
//   }else{
//   }
//   slide();
// }
