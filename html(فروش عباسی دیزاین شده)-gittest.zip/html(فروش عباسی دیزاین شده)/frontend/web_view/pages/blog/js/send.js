function select() {
  updatepage();
}
// function select() {
//     // var username = document.getElementById("username").value;
//     // var password = document.getElementById("password").value;
//     var token = document.getElementById("token").value;
//     var rnd = Math.random();
//     var url = countBack+"frontend/api/blog/select_all.php?id=" + rnd +"&blog_id="+urlId+"&token_client=" + token;
//     postRequest(url);
// }
