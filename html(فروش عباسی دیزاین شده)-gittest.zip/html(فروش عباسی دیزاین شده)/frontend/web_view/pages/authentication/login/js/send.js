var choise='';
function select() {
  choise='select';
  // updatepage();
}
// function select() {
//   choise='select';
//     // var username = document.getElementById("username").value;
//     // var password = document.getElementById("password").value;
//     var token = document.getElementById("token").value;
//     var rnd = Math.random();
//     var url = countBack+"frontend/api/contact/select.php?id=" + rnd +"&token_client=" + token;
//     postRequest(url);
// }
function confirmComment() {
  if (confirm('آیا با ثبت نظر موافق هستید؟')) {
    // window.location = '?del='+id
    insertComment();
  };
}
function insertComment() {
  choise='insert';
  var token = document.getElementById("token").value;
  var phone = e("phone").value;
  var password = document.getElementById("password").value;
    var answer = document.getElementById("comment-answer").value;
  var rnd = Math.random();
  console.log(countBack);
  var url = countBack+"frontend/api/authentication/login/select.php?id=" + rnd +"&token_client=" + token+"&phone=" + phone+"&password=" + password+"&answer=" + answer;
  postRequest(url);
}
