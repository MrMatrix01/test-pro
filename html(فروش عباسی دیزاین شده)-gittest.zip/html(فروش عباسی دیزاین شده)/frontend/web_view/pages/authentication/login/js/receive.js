<?php
if (isset($_SESSION['username'])) {
  ?>
  window.location = "order";
  <?php
}
?>
function updatepage(str) {
  var myObj = JSON.parse(str);
  if (myObj.messageCode.code == "110") {
    if (choise == 'select') {
      // e('about-all').innerHTML=myObj.Data[0]['content'];
    } else if (choise == 'insert') {
      console.log('myObj');
      // alert('ورود با موفقیت انجام شد.');
      // var delayInMilliseconds = 1000; //1 second
      window.location = "order";
    }
  } else if (myObj.messageCode.code == "107") {
    alert('کد امنیتی نا معتبر می باشد');
    window.location = "login";
    // document.getElementById("result").innerHTML = myObj.messageCode.code;

  } else if (myObj.messageCode.code == "109") {
    alert('نام کاربری یا گذرواژه نامعتبر می باشد.');
    window.location = "login";
    // document.getElementById("result").innerHTML = myObj.messageCode.code;

  } else if (myObj.messageCode.code == "400") {
    alert('شماره تلفن صحیح نمی باشد');
    window.location = "login";
    // document.getElementById("result").innerHTML = myObj.messageCode.code;

  }

}
// function updatepage(str) {
//   console.log(str);
//    var myObj = JSON.parse(str);
//   if(myObj.messageCode.code=="110"){
//     if(choise=='select'){
//     e('about-all').innerHTML=myObj.Data[0]['content'];
//   }else if(choise=='insert'){
//     alert('نظر با موفقیت ثبت شد.');
//   }
//   }else{
//     // document.getElementById("result").innerHTML = myObj.messageCode.code;
//
//   }
//
// }
