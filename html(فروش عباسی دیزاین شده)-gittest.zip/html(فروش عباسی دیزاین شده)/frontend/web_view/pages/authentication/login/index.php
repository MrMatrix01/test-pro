<?php
// onload('frontend/api/authentication/signin/select.php');
?>
<main>
  <div class="about">
    <div class="about-content" style="display:none">
      <h3 class="about-h3">ثبت نام</h3>
      <div id="about-all">

      </div>
    </div>
    <div class="comment-signin">
      <h3 class="about-h3">ورود با گذرواژه ثابت</h3>
        <form class="form-comment" action="index.html" method="post">
          <div class="row-comment-singin">
            <div class="colomn-comment-singin">
              <!-- <div class="title-coment">
                موبایل :
              </div> -->
              <!-- <div class="input-comment"> -->
              <!-- </div> -->
              <div class="row-comment-singin">
                <input type="text" class="input-text-comment-login" id="phone" name="" value="" placeholder="شماره خود را وارد  کنید">
                <input type="text" class="input-text-comment-login-pass" id="password" name="" value="" placeholder="گذرواژه را وارد کنید:">
                <!-- <a href="login"><input type="button"  class="submit-comment-login" value="ورودبا گذرواژه ثابت"></a> -->
              </div>

                  <!-- <div class="input-comment"> -->
                  <!-- </div> -->
                  <div class="row-comment">
                    <div class="title-coment">
                    لطفا جواب سوال روبرو را در کادر پایین بنویسید:
                    <img src="kernel/lib/captcha.php" class="captcha" alt="">
                    </div>
                    <input type="text" class="input-text-wide-comment" id="comment-answer" name="" value="">
                  </div>
                    <div class="submit-comment-singin-pass-div">
                      <input type="button" onclick="insertComment()" name="" class="submit-comment-login-input" value="ارسال">
                      <!-- <input type="button" onclick="confirmCommentPass()" name="" id="input-phone-pass" class="submit-comment-singin-pass" value="ارسال"> -->

                    </div>
            </div>
            <!-- <div class="colomn-comment">
              <div class="title-coment">
                موبایل :
              </div>
              <div class="input-comment">
                <input type="text" class="input-text-comment" id="phone" name="" value="">
              </div>
            </div> -->
          </div>
          <!-- <div class="row-comment">
            <div class="colomn-comment">
              <div class="title-coment">
                گذرواژه:
              </div>
              <div class="input-comment">
                <input type="text" class="input-text-comment" id="password" name="" value="">
              </div>
            </div>
            <div class="colomn-comment">
              <div class="title-coment">
                تکرار گذرواژه:
              </div>
              <div class="input-comment">
                <input type="text" class="input-text-comment" id="re-password" name="" value="">
              </div>
            </div>
          </div> -->
          <!-- <div class="row-comment">
            <div class="colomn-comment">
              <div class="title-coment">
                نام:
              </div>
              <div class="input-comment">
                <input type="text" class="input-text-comment" id="name" name="" value="">
              </div>
            </div>
            <div class="colomn-comment">
              <div class="title-coment">
                نام خانوادگی:
              </div>
              <div class="input-comment">
                <input type="text" class="input-text-comment" id="family" name="" value="">
              </div>
            </div>
          </div> -->
          <!-- <div class="row-comment">
            <div class="title-coment">
            ایمیل:
            </div>
            <input type="email" class="input-text-wide-comment"  id="email" name="" value="">
          </div> -->
          <!-- <div class="row-comment">
            <div class="title-comment">
            آدرس:
            </div>
            <textarea name="name" class="textarea-comment" id="address"></textarea>
          </div> -->
          <!-- <div class="row-comment">
            <div class="title-coment">
            لطفا جواب سوال روبرو را در کادر پایین بنویسید:
            <img src="kernel/lib/captcha.php" class="captcha" alt="">
            </div>
            <input type="text" class="input-text-wide-comment" id="comment-answer" name="" value="">
          </div> -->
        </form>
    </div>
  </div>
</main>
