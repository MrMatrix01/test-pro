<?php
// onload('frontend/api/authentication/signin/select.php');
?>
<main>
  <div class="warpper">
    <input class="radio" id="one2" name="group" type="radio" checked>
    <input class="radio" id="two2" name="group" type="radio">
    <div style="display:none;" class="tabs">
    <label class="tab-1" id="one-tab2" for="one2">ثبت خرید</label>
    <label class="tab-1" id="two-tab2" for="two2">درخواست ارسال </label>
    </div>
  <div class="about">
    <div class="panels">
        <div class="panel" id="one-panel2">


        <div class="about-content" style="display:none">
          <h3 class="about-h3">ثبت نام</h3>
          <div id="about-all">

          </div>
        </div>
        <div class="comment-signin">
          <h3 class="about-h3">ثبت نام</h3>
            <form class="form-comment" action="index.html" method="post">
              <div class="row-comment-singin">
                <div class="colomn-comment-singin">
                  <!-- <div class="title-coment">
                    موبایل :
                  </div> -->
                  <!-- <div class="input-comment"> -->
                  <!-- </div> -->
                  <div class="row-comment-singin">
                    <input type="text" class="input-text-comment-singin" id="phone" name="" value="" placeholder="شماره خود را وارد  کنید">
                    <input type="button" onclick="confirmComment()" name="" class="submit-comment-singin" value="ارسال کد">

                  </div>

                      <!-- <div class="input-comment"> -->
                      <!-- </div> -->
                        <!-- <div class="submit-comment-singin-pass-div">
                          <input type="text" class="input-text-comment-singin-pass" id="phone-pass" name="" value="" placeholder="رمز ارسال شده به شماره را وارد کنید:">
                          <input type="button" onclick="confirmCommentPass()" name="" id="input-phone-pass" class="submit-comment-singin-pass" value="ورود">

                        </div> -->
                        <div class="row-comment-singin">
                          <a href="login"><input type="button"  class="submit-comment-login" value="ورودبا گذرواژه ثابت"></a>
                        </div>
                </div>
                <!-- <div class="colomn-comment">
                  <div class="title-coment">
                    موبایل :
                  </div>
                  <div class="input-comment">
                    <input type="text" class="input-text-comment" id="phone" name="" value="">
                  </div>
                </div> -->
              </div>
              <!-- <div class="row-comment">
                <div class="colomn-comment">
                  <div class="title-coment">
                    گذرواژه:
                  </div>
                  <div class="input-comment">
                    <input type="text" class="input-text-comment" id="password" name="" value="">
                  </div>
                </div>
                <div class="colomn-comment">
                  <div class="title-coment">
                    تکرار گذرواژه:
                  </div>
                  <div class="input-comment">
                    <input type="text" class="input-text-comment" id="re-password" name="" value="">
                  </div>
                </div>
              </div> -->
              <!-- <div class="row-comment">
                <div class="colomn-comment">
                  <div class="title-coment">
                    نام:
                  </div>
                  <div class="input-comment">
                    <input type="text" class="input-text-comment" id="name" name="" value="">
                  </div>
                </div>
                <div class="colomn-comment">
                  <div class="title-coment">
                    نام خانوادگی:
                  </div>
                  <div class="input-comment">
                    <input type="text" class="input-text-comment" id="family" name="" value="">
                  </div>
                </div>
              </div> -->
              <!-- <div class="row-comment">
                <div class="title-coment">
                ایمیل:
                </div>
                <input type="email" class="input-text-wide-comment"  id="email" name="" value="">
              </div> -->
              <!-- <div class="row-comment">
                <div class="title-comment">
                آدرس:
                </div>
                <textarea name="name" class="textarea-comment" id="address"></textarea>
              </div> -->
              <!-- <div class="row-comment">
                <div class="title-coment">
                لطفا جواب سوال روبرو را در کادر پایین بنویسید:
                <img src="kernel/lib/captcha.php" class="captcha" alt="">
                </div>
                <input type="text" class="input-text-wide-comment" id="comment-answer" name="" value="">
              </div> -->
            </form>
          </div>
        </div>
        <div class="panel" id="two-panel2">


                  <div class="about-content" style="display:none">
                    <h3 class="about-h3">ثبت نام</h3>
                    <div id="about-all">

                    </div>
                  </div>
                  <div class="comment-signin">
                    <h3 class="about-h3">ثبت نام</h3>
                      <form class="form-comment" action="index.html" method="post">
                        <div class="row-comment-singin">
                          <div class="colomn-comment-singin">
                            <!-- <div class="title-coment">
                              موبایل :
                            </div> -->
                            <!-- <div class="input-comment"> -->
                            <!-- </div> -->
                            <div class="row-comment-singin">
                              <input type="text" disabled class="input-text-comment-singin" id="phone2" name="" value="" placeholder="شماره خود را وارد  کنید">
                              <input type="button" onclick="confirmComment2()" name="" class="submit-comment-singin" value="اصلاح شماره">

                            </div>

                                <!-- <div class="input-comment"> -->
                                <!-- </div> -->
                                  <div class="submit-comment-singin-pass-div">
                                    <input type="text" class="input-text-comment-singin-pass" id="phone-pass" name="" value="" placeholder="رمز ارسال شده به شماره را وارد کنید:">
                                    <input type="button" onclick="confirmCommentPass()" name="" id="input-phone-pass" class="submit-comment-singin-pass" value="ورود">

                                  </div>

                          </div>

                        </div>

                      </form>
                    </div>
        </div>
    </div>
  </div>
</div>
</main>
