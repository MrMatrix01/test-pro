var choise='';
function select() {
  // choise='select';
  // updatepage();
}
// function select() {
//   choise='select';
//     // var username = document.getElementById("username").value;
//     // var password = document.getElementById("password").value;
//     var token = document.getElementById("token").value;
//     var rnd = Math.random();
//     var url = countBack+"frontend/api/contact/select.php?id=" + rnd +"&token_client=" + token;
//     postRequest(url);
// }
function confirmComment() {
  // if (confirm('آیا با ثبت نام موافق هستید؟')) {
    // window.location = '?del='+id
    insertComment();
    // insertCommentPass();
    e('phone-pass').style.display='block';
    e('input-phone-pass').style.display='block';
    e('two2').checked=true;
    e('phone2').value=e('phone').value
  // };
}
function confirmComment2() {
  // if (confirm('آیا با ثبت نام موافق هستید؟')) {
    // window.location = '?del='+id
    insertComment();
    // insertCommentPass();

    e('one2').checked=true;
  // };
}
function insertComment() {
  choise='insert';
  var token = document.getElementById("token").value;
  // var username = document.getElementById("username").value;
  var phone = document.getElementById("phone").value;
  // var name = document.getElementById("name").value;
  // var family = document.getElementById("family").value;
  // var email = document.getElementById("email").value;
  // var password = document.getElementById("password").value;
  // var address = document.getElementById("address").value;
  // var answer = document.getElementById("comment-answer").value;
  var rnd = Math.random();
  // var url = countBack+"frontend/api/authentication/signin/insert.php?id=" + rnd +"&token_client=" + token+"&username=" + username+"&name=" + name+"&family=" + family+"&email=" + email+"&password=" + password+"&address=" + address+"&answer=" + answer;
  var url = countBack+"frontend/api/authentication/signin/insert.php?id=" + rnd +"&phone=" + phone+"&token_client=" + token;
  postRequest(url);
}
function confirmCommentPass() {
  choise='select';
  var token = document.getElementById("token").value;
  // var username = document.getElementById("username").value;
  var phone = document.getElementById("phone").value;
  var phonePass = document.getElementById("phone-pass").value;
  // var name = document.getElementById("name").value;
  // var family = document.getElementById("family").value;
  // var email = document.getElementById("email").value;
  // var password = document.getElementById("password").value;
  // var address = document.getElementById("address").value;
  // var answer = document.getElementById("comment-answer").value;
  var rnd = Math.random();
  // var url = countBack+"frontend/api/authentication/signin/insert.php?id=" + rnd +"&token_client=" + token+"&username=" + username+"&name=" + name+"&family=" + family+"&email=" + email+"&password=" + password+"&address=" + address+"&answer=" + answer;
  var url = countBack+"frontend/api/authentication/signin/select.php?id=" + rnd +"&phone=" + phone+"&phone_pass=" + phonePass+"&token_client=" + token;
  postRequest(url);
}
