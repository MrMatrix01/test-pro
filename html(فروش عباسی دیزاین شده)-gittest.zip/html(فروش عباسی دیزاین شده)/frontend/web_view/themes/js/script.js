function qac(e) {
    return document.querySelectorAll(e);
}
function getParameterByName(e, o = window.location.href) {
    e = e.replace(/[\[\]]/g, "\\$&");
    o = new RegExp("[?&]" + e + "(=([^&#]*)|&|#|$)").exec(o);
    return o ? (o[2] ? decodeURIComponent(o[2].replace(/\+/g, " ")) : "") : null;
}
function e(e) {
    if ("localhost" == window.location.hostname || "iranbag.ir" == window.location.hostname) return document.getElementById(e);
}
function pricee() {
    console.log(e("number").value), e("number").value < 1e3 && (alert("تعداد سفارش باید بالای ۱۰۰۰ عدد باشد."), (e("number").value = 1e3));
}
function myDropdown() {
    e("myDropdown").classList.toggle("show");
}
function myFunctionSearch() {
    e("myDropdown2").classList.toggle("show2");
}

    (window.onclick = function (e) {
        if (!e.target.matches(".dropbtn"))
            for (var o = document.getElementsByClassName("dropdown-content"), r = 0; r < o.length; r++) {
                var t = o[r];
                t.classList.contains("show") && t.classList.remove("show");
            }
    }),
    (window.onclick = function (e) {
        if (!e.target.matches(".dropbtn2"))
            for (var o = document.getElementsByClassName("dropdown-content2"), r = 0; r < o.length; r++) {
                var t = o[r];
                t.classList.contains("show2") && t.classList.remove("show2");
            }
    });


function ToRial(str) {

str = str.replace(/\,/g, '');
    var objRegex = new RegExp('(-?[0-9]+)([0-9]{3})');

    while (objRegex.test(str)) {
        str = str.replace(objRegex, '$1,$2');
    }

    return str;
}
