<?php
session_start();
require_once 'frontend/web_view/routes/web.php';
header("X-Frame-Options:DENY");
?>
<link rel="stylesheet" href="<?=$countBack?>frontend/web_view/themes/css/style.css">
<link rel="stylesheet" href="<?=$countBack?>frontend/web_view/themes/css/all.min.css">
<link rel="stylesheet" href="<?=$countBack?>frontend/web_view/themes/css/slide.css">
<link rel="shortcut icon" href="<?=$countBack?>frontend/web_view/themes/images/favicon.ico" type="image/x-icon">
<?php

function makeToken()
{
  return $_SESSION['token'] = base64_encode(md5(microtime()));
}
?>
<div  id="token" value="<?= makeToken() ?>"></div>
<script type="text/javascript" language="javascript" src="<?=$countBack?>frontend/web_view/themes/js/gtag.js?id=G-PGV4Z5J6YE"></script>
<script type="text/javascript" language="javascript" src="<?=$countBack?>frontend/web_view/themes/js/ajax.js" charset="utf-8"></script>
<script type="text/javascript" language="javascript" src="<?=$countBack?>frontend/web_view/themes/js/script.js" charset="utf-8"></script>
<?php
// if($uri=='/'){
?>

<?php
// }
?>
