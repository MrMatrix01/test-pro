<script type="text/javascript">
var countBack='<?=@$countBack?>';
var urlId='<?=@$url_id?>';
<?php
if(!empty($response)){
 ?>
var myObj=<?=$response?>;
<?php
}
include $route_page.'js/send.js';
include $route_page.'js/receive.js';
?>
</script>
