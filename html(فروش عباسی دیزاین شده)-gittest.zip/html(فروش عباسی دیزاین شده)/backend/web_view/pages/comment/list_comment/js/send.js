stUrlId=window.location.hash.substring(1);
if(stUrlId==undefined){
  pageId=1;
}else {
  pageId=parseInt(stUrlId);
}
var choise='';
function edit_blog(id) {
  console.log(id);
  window.location = 'view_comment?edit='+id
}
function deleteContent(deleteId) {
  choise='deleteContent';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("delete_id",deleteId);
  formdata.append("token_client",token.value);

  var url = "api/pages/blog/delete.php";
  postRequest(url,formdata);

}
// function select(idPage=1) {
//   choise='select';
//   var rnd = Math.random();
//   var token = e("token");
//   var formdata = new FormData();
//   formdata.append("id",rnd);
//   formdata.append("id_page",idPage);
//   formdata.append("token_client",token.value);
//   var url = "api/pages/comment/select_all.php";
//   postRequest(url,formdata);
// }

function select() {
  choise='select';
updatepage();

}
function searchFile() {
  choise='select';
  var rnd = Math.random();
  var token = e("token");
  var valueSearch=e("value-search");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("search_value",valueSearch.value);
  formdata.append("token_client",token.value);
  var url = "api/pages/comment/search.php";
  postRequest(url,formdata);
}
function alertImgDelete(idDelete,imageName){
alert();
}
