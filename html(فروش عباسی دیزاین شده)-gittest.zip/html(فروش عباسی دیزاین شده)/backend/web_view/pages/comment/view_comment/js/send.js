var choise='';
// var editUrl=getParameterByName('edit');

// select(editUrl);
function select() {
    choise='select';
  updatepage();

  // var rnd = Math.random();
  // var token = e("token");
  // var formdata = new FormData();
  // formdata.append("id",rnd);
  // formdata.append("id_page",idPage);
  // formdata.append("token_client",token.value);
  // var url = "api/pages/comment/select.php";
  // postRequest(url,formdata);
}
select();
// var choise='';
// var editUrl=getParameterByName('edit');
//
// selectContent(editUrl);
// function selectContent(idPage) {
//   choise='select';
//   var rnd = Math.random();
//   var token = e("token");
//   var formdata = new FormData();
//   formdata.append("id",rnd);
//   formdata.append("id_page",idPage);
//   formdata.append("token_client",token.value);
//   var url = "api/pages/comment/select.php";
//   postRequest(url,formdata);
// }
