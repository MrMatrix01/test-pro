var pageId=window.location.hash.substring(1);
var fileCount=0;
function updatepage(str) {
  // var myObj = JSON.parse(str);
  console.log('aaaaaa');
  console.log(myObj);
  if(myObj.messageCode.code=="110" && <?=$_SESSION['id']?>!== 'undefined'){
if(choise=='select') {
  console.log(myObj.Data['content']);
      var id;
      var content;
        id=myObj.Data['id'];
        content=myObj.Data['content'];
        e('comment-name').value=myObj.Data['name']+' '+myObj.Data['family'];
        e('comment-email').value=myObj.Data['email'];
        e('comment-title').value=myObj.Data['title'];
        e('min-content').value=content;
    }
  }else{
    // document.getElementById("result").innerHTML = myObj.messageCode.code;
  }

}
// var pageId=window.location.hash.substring(1);
// var fileCount=0;
// function updatepage(str) {
//   var myObj = JSON.parse(str);
//   var imageName=myObj.Data["image_name"];
//   var imageId=myObj.Data['image_id'];
//   if(myObj.messageCode.code=="110" && <?=$_SESSION['id']?>!== 'undefined'){
// if(choise=='select') {
//   console.log(myObj.Data['content']);
//       var id;
//       var content;
//         id=myObj.Data['id'];
//         content=myObj.Data['content'];
//         console.log(content);
//         e('min-content').value=content;
//     }
//   }else{
//     // document.getElementById("result").innerHTML = myObj.messageCode.code;
//   }
//
// }
