<?php
$post_id['id_page']=$_GET['edit'];
onload('backend/api/pages/comment/select.php',$post_id);
?>
<div class="main-center">
  <div class="topbar">

    <div class="home">
      صفحه اصلی
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>
  <div class="page-wrapper box-content">
    <div class="">
      نام:
    </div>
    <input type="text" id="comment-name" class="blog-pre-image" name="blog-pre-image" value="">
    <div class="">
      ایمیل:
    </div>
    <input type="text" id="comment-email" class="blog-pre-image" name="blog-pre-image" value="">
    <div class="">
      عنوان:
    </div>
    <input type="text" id="comment-title" class="blog-pre-image"  name="blog-pre-image" value="">
    <textarea class="content" id="min-content" name="example"></textarea>
    <button type="button" name="button" onclick="insertContent()" class="button-send">ثبت</button>
  </div>
  <div id="alert-delete">

  </div>
<div class="result">

</div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
