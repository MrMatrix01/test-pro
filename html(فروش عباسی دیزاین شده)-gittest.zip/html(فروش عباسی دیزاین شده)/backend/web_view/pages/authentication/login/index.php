<form class="form">
  <div class="input">
    <span>نام کاربری:</span>
    <div class="">
      <input type="text" name="usename"  id="username" class="textbox">
    </div>
  </div>
  <div class="input">
    <span>گذرواژه:</span>
    <input type="password" name="password" id="password" class="textbox">
  </div>
  <div id="result">

  </div>
  <input type="button" class="button-login" onclick="signin()" name="send" value="ارسال" id="login">
</form>
