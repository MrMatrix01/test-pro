function updatepage(str) {
   var myObj = JSON.parse(str);
  if(myObj.messageCode.code=="110"){
  window.location = "./add_blog";
  }else{
     document.getElementById("result").innerHTML = 'نام کاربری یا گذرواژه نا معتبر می باشد.';

  }

}
