function signin() {
  var rnd = Math.random();
  var username = document.getElementById("username");
  var password = document.getElementById("password");
  var token = document.getElementById("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("username",username.value);
  formdata.append("password",password.value);
  formdata.append("token_client",token.value);
  var url = "api/authentication/login/select.php";
  postRequest(url,formdata);
  // var  pic=document.getElementById("pic").files[0];

  // formdata.append("file[0]", pic);
}
