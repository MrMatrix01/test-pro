
<div class="main-center">
  <div class="topbar">

    <div class="home">
      لیست کارمندان
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>
  <div class="table">
    <div class="select"  style="margin:10px 0 10px 0; display:none;">
      <input type="button" name="button" class="select-file" onclick="searchFile()" value="جستجو">
      <input type="text" id="value-search" value="" placeholder="نام کاربری">
    </div>
    <table>
      <thead>
        <tr>
          <td>id</td>
          <td>نام کاربری</td>
          <td>نام</td>
          <td>نام خانوادگی</td>
          <td style="display:none;">وضعیت</td>
          <td style="display:none;">edit</td>
        </tr>
      </thead>
      <tbody id="table-blog">

      </tbody>
    </table>
    <div id="blog-page-number">
      <div class="row1">
      </div>
      <div class="row1">
      </div>
      <div class="row1">
      </div>
    </div>
  </div>
  <div id="alert-delete">

  </div>
<div class="result">

</div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
