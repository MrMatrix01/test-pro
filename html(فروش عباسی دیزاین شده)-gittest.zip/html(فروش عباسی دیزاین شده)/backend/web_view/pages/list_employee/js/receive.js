function updatepage(str) {
  var myObj = JSON.parse(str);
  var imageName=myObj.Data["image_name"];
  var imageId=myObj.Data['image_id'];
  if(myObj.messageCode.code=="110" && <?=$_SESSION['id']?>!== 'undefined'){
    if(choise=='select') {
      e('table-blog').innerHTML='';
      for (var i = 0; i < myObj.Data.length; i++) {
        console.log(myObj.Data[i]);
        id=myObj.Data[i]['id'];
        name=myObj.Data[i]['name'];
        family=myObj.Data[i]['family'];
        username=myObj.Data[i]['username'];
        if(myObj.Data[i]['status']==1){
          var status='فعال';
        }else {
          var status='غیر فعال';
        }
        e('table-blog').innerHTML+='<tr><td>'+id+'</td><td>'+username+'</td><td>'+name+'</td><td>'+family+'</td><td style="display:none;">'+status+'</td><td style="display:none;" class="cursor" onclick="edit_employee('+id+')">ویرایش</td></tr>';
      }
      // paging(myObj);
    }
  }
}
