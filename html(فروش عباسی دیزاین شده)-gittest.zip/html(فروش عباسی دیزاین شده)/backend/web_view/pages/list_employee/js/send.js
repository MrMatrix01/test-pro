stUrlId=window.location.hash.substring(1);
function select() {
  return 1;
}
if(stUrlId==undefined){
  pageId=1;
}else {
  pageId=parseInt(stUrlId);
}
var choise='';
function edit_employee(id) {
  console.log(id);
  window.location = 'edit_employee?edit='+id
}
selectAll(1);
function selectAll(idPage) {
  choise='select';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_page",idPage);
  formdata.append("token_client",token.value);
  var url = "api/pages/employee/select_all.php";
  postRequest(url,formdata);
}
function searchFile() {
  choise='select';
  var rnd = Math.random();
  var token = e("token");
  var valueSearch=e("value-search");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("search_value",valueSearch.value);
  formdata.append("token_client",token.value);
  var url = "api/pages/employee/search.php";
  postRequest(url,formdata);
}
