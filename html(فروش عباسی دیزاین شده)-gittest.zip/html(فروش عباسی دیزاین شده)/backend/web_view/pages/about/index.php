
<div class="main-center">
  <div class="topbar">

    <div class="home">
      صفحه اصلی
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>



  <div class="page-wrapper box-content">
    <div class="select">
      <button type="button" name="button" class="select-file" onclick="selectFile()">انتخاب عکس</button>
      <input type="text" id="image-name" value="">
    </div>
    <!-- <div class="">
    درباره ما:
    </div> -->
    <div class="">
      متن پیش نمایش:
    </div>
    <textarea class="content" id="min-content" name="example"></textarea>
    <div class="">
      متن اصلی:
    </div>
    <textarea class="content2" id="max-content" name="example2"></textarea>
    <button type="button" name="button" onclick="confirmUpdate()" class="button-send">ثبت</button>
  </div>
  <div id="blur">
    <div class="show-select-file">
      <i class="fa fa-close close-blur"  onclick="closeBlur()"></i>
      <form class="upload-image" action="index.html" method="post" enctype="multipart/form-data">
        <!-- <label for="fileUpload">Upload file</label>   -->
        <input type="file" id="file-upload" value="" class="input"  accept="image/*">
        <button type="button" class="pic-button" name="button" onclick="uploadImage()">بارگذاری تصویر</button>
        <div id="blog-page-number">
          <div class="row1">
          </div>
          <div class="row1">
          </div>
          <div class="row1">
          </div>
          <!-- <div id="row2">
          </div>
          <div id="row3">
          </div> -->
        </div>
      </form>
      <div id="box-gallery">
      </div>
    </div>
  </div>
  <div id="alert-delete">

  </div>
<div class="result">

</div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
