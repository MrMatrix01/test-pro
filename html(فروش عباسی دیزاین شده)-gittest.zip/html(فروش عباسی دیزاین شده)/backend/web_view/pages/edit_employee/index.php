<div class="main-center">
  <div class="topbar">
    <div class="home">
      ویرایش کارمند
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>
  <div class="page-wrapper box-content">
    <div class="">
      نام کاربری:
    </div>
    <input type="text" id="username" class="title" name="username" value="">
    <div class="">
      نام:
    </div>
    <input type="text" id="name" class="title" name="name" value="">
    <div class="">
      نام خانوادگی:
    </div>
    <div class="">
      وضعیت:
    </div>
    <input type="checkbox" name="employee_status" id="employee_status"  value="active">
    <input type="text" id="family" class="title" name="family" value="">
    <div class="">
      گذرواژه:
    </div>
    <input type="password" id="password" class="title" name="password" value="">
    <div class="">
      تکرار گذر واژه:
    </div>
    <input type="password" id="re_password" class="title" name="re_password" value="">
    <input type="button" name="button" onclick="confirmUpdate('کارمند')"  value="ویرایش" class="button-send">
  </div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
