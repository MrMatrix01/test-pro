var fileCount=0;
function updatepage(str) {
  var myObj = JSON.parse(str);
  var imageName=myObj.Data["image_name"];
  var imageId=myObj.Data['image_id'];
  if(myObj.messageCode.code=="110" && <?=$_SESSION['id']?>!== 'undefined'){
    if(choise=='selectContent'){
      e('name').value=myObj.Data['name'];
      e('family').value=myObj.Data['family'];
      e('username').value=myObj.Data['username'];
      if(myObj.Data['status']==1){
        e('employee_status').checked=true;
      }
    }else if(choise=='content'){
      alert('تغییر انجام شد');
      selectContent(editUrl);
    }
  }
}
