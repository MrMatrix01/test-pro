var editUrl=getParameterByName('edit');
function select() {
  return 1;
}
var choise='';
selectContent(editUrl);
function selectContent(idEmployee) {
  choise='selectContent';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_employee",idEmployee);
  formdata.append("token_client",token.value);
  var url = "api/pages/employee/select.php";
  postRequest(url,formdata);
}
function updateContent() {
  if(e("re_password").value===e("password").value){
    choise='content';
    var rnd = Math.random();
    var token = e("token");
    var formdata = new FormData();
    if(e('employee_status').checked==true){
      var status=1;
    }else {
      var status=0;
    }
    formdata.append("id",rnd);
    formdata.append("id_employee", editUrl);
    formdata.append("name", e("name").value);
    formdata.append("family", e("family").value);
    formdata.append("username", e("username").value);
    formdata.append("password", e("password").value);
    formdata.append("status", status);
    formdata.append("token_client",token.value);
    var url = "api/pages/employee/update.php";
    postRequest(url,formdata);
  }else {
    alert('گذرواژه با تکرارش برابر نمی باشد.');
  }
}
