var fileCount=0;
function updatepage(str) {
  var myObj = JSON.parse(str);
  var imageName=myObj.Data["image_name"];
  var imageId=myObj.Data['image_id'];
  if(myObj.messageCode.code=="110" && <?=$_SESSION['id']?>!== 'undefined'){
    if (choise=='insert') {
      e('image-name').value='../uploads/'+imageName;
      e('imageURL').value='..//uploads/'+imageName;
      e('box-gallery').innerHTML='<div class="column-gallery"><button class="delete-gallery" onclick="imgDelete(\''+imageId+'\',\''+imageName+'\')"><i class="fa fa-trash"></i></button><img src="../uploads/'+imageName+'" class="galley-img" alt=""></div>'
      +e('box-gallery').innerHTML;
      // setTimeout(function(){  e('blur').style.display='none';}, 2000);
      showFile();
      console.log(choise);
    }else if(choise=='select') {
      e('box-gallery').innerHTML='';
      var id;
      var fileName;
      for (var i = 0; i < myObj.Data.length; i++) {
        id=myObj.Data[i]['id'];
        fileName=myObj.Data[i]['file_name'];
        e('box-gallery').innerHTML+='<div class="column-gallery"><button class="delete-gallery" onclick="imgDelete(\''+id+'\',\''+fileName+'\')"><i class="fa fa-trash"></i></button><img src="../uploads/'+fileName+'" class="galley-img" alt=""></div>';
        showFile();
      }


      if(myObj.Data2!=undefined){
        fileCount=Math.ceil(myObj.Data2['file_count']/15);
      }
      var row1=document.querySelectorAll('.row1');
      stUrlId=window.location.hash.substring(1);
      if(stUrlId==undefined){
        pageId=1;
      }else {
        pageId=parseInt(stUrlId);
      }
      row1[0].innerHTML='';
      row1[1].innerHTML='';
      row1[2].innerHTML='';
      row1[0].innerHTML='<a href="#1" class="page-number-a">'+(1)+'</a>';
      if(fileCount>1){
        row1[0].innerHTML+='<a href="#2" class="page-number-a">'+(2)+'</a>';
      }
      if(fileCount>2){
        row1[0].innerHTML+='<a href="#3" class="page-number-a">'+(3)+'</a>';
      }
      if(pageId>5){
        row1[1].innerHTML+='<span class="page-number-span">...</span>';
      }
      for (var i =pageId;i<(pageId+3);i++) {
        if(i>4 && i<(fileCount-1)){
          row1[1].innerHTML+='<a href="#'+(i-1)+'" class="page-number-a">'+(i-1)+'</a>';
        }
      }
      if( pageId<(fileCount-4)){
        row1[1].innerHTML+='<span class="page-number-span">...</span>';
      }
      if(fileCount>5){
        row1[2].innerHTML+= '<a href="#'+(fileCount-2)+'" class="page-number-a">'+(fileCount-2)+'</a>';
      }
        if(fileCount>4){
        row1[2].innerHTML+='<a href="#'+(fileCount-1)+'" class="page-number-a">'+(fileCount-1)+'</a>';
      }
        if(fileCount>3){
        row1[2].innerHTML+='<a href="#'+fileCount+'" class="page-number-a">'+(fileCount)+'</a>';
      }


      pageNumberA=document.querySelectorAll('.page-number-a');

      pageNumberA.forEach(item => {
        item.addEventListener('click', event => {
          selectAll(item.innerHTML);

        })
      })
    }else if(choise=='selectContent'){
      e('blog-title').value=myObj.Data['post_title'];
      e('blog-pre-image').value=myObj.Data['guid'];
      e('min-content').value=myObj.Data['min_content'];
      e('max-content').value=myObj.Data['max_content'];
      selectAll(1);
    }else if(choise=='content'){
      change();
      selectContent(editUrl);
    }
    else {
      selectAll(1);
    }
  }else{
    // document.getElementById("result").innerHTML = myObj.messageCode.code;
  }

}

showFile();
// pageNumberA=document.querySelectorAll('.page-number-a');
// pageNumberA.forEach(item => {
//   item.addEventListener('click', event => {
//     selectAll(item.innerHTML);
//   })
// })
// let close =  document.querySelectorAll('.richText-dropdown-close');
