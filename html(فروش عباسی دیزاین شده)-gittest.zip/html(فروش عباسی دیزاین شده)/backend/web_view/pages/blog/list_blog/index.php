
<div class="main-center">
  <div class="topbar">

    <div class="home">
      لیست مقالات آموزشی
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>
  <div class="table">
    <div class="select" style="margin:10px 0 10px 0">
      <button type="button" name="button" class="select-file" onclick="searchFile()">جستجو</button>
      <input type="text" id="value-search" value="">
    </div>
    <table id="table-blog">
      <tr>
        <td>id</td>
        <td>title</td>
        <td>edit</td>
        <td>update</td>
      </tr>
    </table>
    <div id="blog-page-number">
      <div class="row1">
      </div>
      <div class="row1">
      </div>
      <div class="row1">
      </div>
    </div>
  </div>
  <div id="alert-delete">

  </div>
<div class="result">

</div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
