stUrlId=window.location.hash.substring(1);
if(stUrlId==undefined){
  pageId=1;
}else {
  pageId=parseInt(stUrlId);
}
var choise='';
function uploadImage() {
  choise='insert';
  var rnd = Math.random();
  var token = e("token");
  var  fileUpload=e('file-upload').files[0];
  var formdata = new FormData();
  formdata.append("id",rnd);

  formdata.append("file[0]", fileUpload);
  // document.getElementById('result').innerHTML=pic;
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/insert.php";
  postRequest(url,formdata);
}
selectAll(1);
function selectAll(idPage) {
  choise='select';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_page",idPage);
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/select_all.php";
  postRequest(url,formdata);
}
function alertImgDelete(idDelete,imageName){
alert();
}
function imgDelete(idDelete,imageName){
  console.log('llllllll');
  choise='delete';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_delete",idDelete);
  formdata.append("image_name",imageName);
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/delete.php";
  console.log(imageName);
  postRequest(url,formdata);
}
function insertContent() {
  choise='content';
  var rnd = Math.random();
  var token = e("token");
  var blogTitle=e("blog-title");
  var blogPreImage=e("blog-pre-image");
  var minContent=e("min-content");
  var maxContent=e("max-content");
  var formdata = new FormData();
  formdata.append("id",rnd);

  formdata.append("blog_title", blogTitle.value);
  formdata.append("blog_pre_image", blogPreImage.value);
  formdata.append("min_content", minContent.value);
  formdata.append("max_content", maxContent.value);
  // document.getElementById('result').innerHTML=pic;
  formdata.append("token_client",token.value);
  var url = "api/pages/blog/insert.php";
  postRequest(url,formdata);
}
