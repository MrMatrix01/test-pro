var fileCount=0;
var globalMyObj;
function updatepage(str) {
  var myObj = JSON.parse(str);
  globalMyObj=myObj;
  var imageName=myObj.Data["image_name"];
  var imageId=myObj.Data['image_id'];
  if(myObj.messageCode.code=="110" && <?=$_SESSION['id']?>!== 'undefined'){
    if (choise=='insert') {
      e('image-name').value='../uploads/'+imageName;
      e('imageURL').value='..//uploads/'+imageName;
      e('box-gallery').innerHTML='<div class="column-gallery"><button class="delete-gallery" onclick="imgDelete(\''+imageId+'\',\''+imageName+'\')"><i class="fa fa-trash"></i></button><img src="../uploads/'+imageName+'" class="galley-img" alt=""></div>'
      +e('box-gallery').innerHTML;
      setTimeout(function(){  e('blur').style.display='none';}, 2000);
      showFile();
    }else if(choise=='select') {
      // var id;
      // var handel;
      // var handelColor;
      // var firstColor;
      // var secondColor;
      // var number;
      // var print
      // var price
      // var garma
      // var form
      // var cassette
      // var size
      // var rtlUsersId
      // var address
      // var transport
      // var mobile
      // var mobile2
      // var phone
      // var city
      // var state

      e('table-blog').innerHTML='';
      for (var i = 0; i < myObj.Data.length; i++) {
        id=myObj.Data[i]['id_buy_castomer'];
        handel=myObj.Data[i]['handel'];
        handelColor=myObj.Data[i]['handel_color'];
        firstColor=myObj.Data[i]['first_color'];
        secondColor=myObj.Data[i]['second_color'];
        number=myObj.Data[i]['number'];
        print=myObj.Data[i]['print'];
        price=myObj.Data[i]['price'];
        garma=myObj.Data[i]['garma'];
        form=myObj.Data[i]['form'];
        cassette=myObj.Data[i]['cassette'];
        size=myObj.Data[i]['size'];
        rtlUsersId=myObj.Data[i]['rtl_users_id'];
        address=myObj.Data[i]['address'];
        transport=myObj.Data[i]['transport'];
        mobile=myObj.Data[i]['mobile'];
        mobile2=myObj.Data[i]['mobile2'];
        phone=myObj.Data[i]['phone'];
        city=myObj.Data[i]['city'];
        state=myObj.Data[i]['state'];
        phoneUser=myObj.Data[i]['phone_user'];
        authority=myObj.Data[i]['authority'];
        refid=myObj.Data[i]['refid'];
        if(refid==null){
          s='ناموفق';
        }else {
          s='موفق';
        }
        e('table-blog').innerHTML+='<tr><td>'+id+'</td><td>'+phoneUser+'</td><td>'+number+'</td><td>'+price+'</td><td>'+authority+'</td><td>'+refid+'</td><td>'+s+'</td><td>'+transport+'</td><td class="cursor" onclick="editGallery('+i+')">مشاهده</td></tr>';
        showFile();
      }

//------------------------------------------------------------------------
      if(myObj.Data2!=undefined){

        fileCount=Math.ceil(myObj.Data2['blog_count']/10);
      }
      var row1=document.querySelectorAll('.row1');
       stUrlId=window.location.hash.substring(1);
       if(stUrlId==undefined){
         pageId=1;
       }else {
         pageId=parseInt(stUrlId);
       }
      row1[0].innerHTML='';
      row1[1].innerHTML='';
      row1[2].innerHTML='';
      row1[0].innerHTML='<a href="#1" class="page-number-a">'+(1)+'</a>';
      if(fileCount>1){
        row1[0].innerHTML+='<a href="#2" class="page-number-a">'+(2)+'</a>';
      }
      if(fileCount>2){
        row1[0].innerHTML+='<a href="#3" class="page-number-a">'+(3)+'</a>';
      }
      if(pageId>5){
        row1[1].innerHTML+='<span class="page-number-span">...</span>';
      }
      for (var i =pageId;i<(pageId+3);i++) {
        console.log(pageId);
        if(i>4 && i<(fileCount-1)){
          row1[1].innerHTML+='<a href="#'+(i-1)+'" class="page-number-a">'+(i-1)+'</a>';
        }
      }
      if( pageId<(fileCount-4)){
        row1[1].innerHTML+='<span class="page-number-span">...</span>';
      }
      if(fileCount>5){
        row1[2].innerHTML+= '<a href="#'+(fileCount-2)+'" class="page-number-a">'+(fileCount-2)+'</a>';
      }
        if(fileCount>4){
        row1[2].innerHTML+='<a href="#'+(fileCount-1)+'" class="page-number-a">'+(fileCount-1)+'</a>';
      }
        if(fileCount>3){
        row1[2].innerHTML+='<a href="#'+fileCount+'" class="page-number-a">'+(fileCount)+'</a>';
      }


      pageNumberA=document.querySelectorAll('.page-number-a');

      pageNumberA.forEach(item => {
        item.addEventListener('click', event => {

          selectAll(item.innerHTML);

        })
      })
    }else if(choise=='content'){
      location.reload();
    }
    else if (choise=='deleteContent') {
      selectAll(1);
      alert('حذف با موفقیت انجام شد');
    }
    else if (choise=='insert-check') {
      alert('تغییر با موفقیت انجام شد.');
      window.location='list_sells';
    }
    else {
      selectAll(1);
    }
  }else{
    // document.getElementById("result").innerHTML = myObj.messageCode.code;
  }

}

function a(i) {
  e('info-sells').style.display='block';
  e('info-sell-input1').value="شماره همراه: "+globalMyObj.Data[i]['mobile'];
  e('info-sell-input2').value="شماره همراه ۲: "+globalMyObj.Data[i]['mobile2'];
  e('info-sell-input3').value="شماره ثابت: "+globalMyObj.Data[i]['phone'];
  e('info-sell-input4').value="شهر: "+globalMyObj.Data[i]['city'];
  e('info-sell-input5').value="استان: "+globalMyObj.Data[i]['state'];
  e('info-sell-input6').value="آدرس: "+globalMyObj.Data[i]['address'];
  e('info-sell-input7').value="رنگ دسته: "+globalMyObj.Data[i]['handel_color'];
  e('info-sell-input8').value="رنگ اول: "+globalMyObj.Data[i]['first_color'];
  e('info-sell-input9').value="رنگ دوم: "+globalMyObj.Data[i]['second_color'];
  e('info-sell-input10').value="چاپ: "+globalMyObj.Data[i]['print'];
  if (globalMyObj.Data[i]['sended']==1) {
      e('info-sell-input12').checked=true;
  }else {
      e('info-sell-input12').checked=false;
  }

  e('info-sell-input11').src='<?=$GLOBALS['countBack'].'uploads/'?>'+globalMyObj.Data[i]['file_name'];
  // e('info-sell-input13').onclick='sendTik('+globalMyObj.Data[i]["id"]+')';
  var sendedId=globalMyObj.Data[i]["id_buy_castomer"];
  // e('div-check').innerHTML='<input id="info-sell-input13" style="background-color: #999;" class="info-sell-input" type="button" name="" value="ثبت" onclick="sendTik('+sendedId+')">';
}
showFile();
// pageNumberA=document.querySelectorAll('.page-number-a');
// pageNumberA.forEach(item => {
//   item.addEventListener('click', event => {
//     selectAll(item.innerHTML);
//   })
// })
// let close =  document.querySelectorAll('.richText-dropdown-close');
