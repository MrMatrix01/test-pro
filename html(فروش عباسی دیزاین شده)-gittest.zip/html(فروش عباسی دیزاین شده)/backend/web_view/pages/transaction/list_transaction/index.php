
<div class="main-center">
  <div class="topbar">

    <div class="home">
      ویرایش کالا
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>
  <div id="info-sells" class="info-sells">
    <input id="info-sell-input1" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input2" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input3" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input4" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input5" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input7" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input8" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input9" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input10" class="info-sell-input" type="text" name="" value="">
    <div class="info-sell-input">
      <div style="float: right;margin-top: 10px;" class="">
          ارسال شد
      </div>
      <input class="info-sell-input" style="margin-right: 35%;margin-top: 0%;" id="info-sell-input12"  type="checkbox" name="" value="ارسال">
    </div>
    <input id="info-sell-input6" class="info-sell-input" type="text" name="" value="">
    <div id='div-check'>

    </div>
    <!-- <input id="info-sell-input11" class="info-sell-input" type="text" name="" value=""> -->
    <img src="" id="info-sell-input11"  alt="">
  </div>
  <div class="table">
    <table>
      <thead>
      <tr>
        <td>ردیف</td>
        <td>شماره خریدار</td>
        <td>تعداد</td>
        <td>قیمت</td>
        <td>authority</td>
        <td>refid</td>
        <td>پرداخت</td>
        <td>باربری</td>
        <!-- <td>price</td>
        <td>price</td>
        <td>price</td> -->
        <!-- <td>price</td> -->
        <!-- <td>price</td> -->
        <!-- <td>price</td>
        <td>price</td>
        <td>price</td>
        <td>price</td>
        <td>price</td> -->
        <!-- <td>price</td> -->

        <td>مشاهده</td>
        <!-- <td>update</td> -->
      </tr>
    </thead>
    <tbody id="table-blog">

    </tbody>
    </table>
    <div id="blog-page-number">
      <div class="row1">
      </div>
      <div class="row1">
      </div>
      <div class="row1">
      </div>
    </div>
  </div>
  <div id="alert-delete">

  </div>
<div class="result">

</div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
