
<div class="main-center">
  <div class="topbar">

    <div class="home">
      اضافه کردن سفارش کالا
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>



  <div class="page-wrapper box-content">
    <div class="">
      گرماژ:
    </div>
    <select style="width: 200px;font-size: 17px;" name="gram" id="garma">
      <option value="40">40</option>
      <option value="60">60</option>
      <option value="90">90</option>
    </select>
    <div class="">
      کاست:
    </div>
    <select style="width: 200px;font-size: 17px;" name="gram" id="kaset">
      <option value="none">بدون کاست</option>
      <option value="bottom">کف کاست</option>
      <option value="three">سه طرف کاست</option>
    </select>
    <div class="">
      اندازه:
    </div>
    <select style="width: 200px;font-size: 17px;" id="size" name="gram">
      <option value="20*25">20 &times; 25</option>
      <option value="20*30">20 &times; 30</option>
      <option value="25*30">25 &times; 30</option>
      <option value="25*35">25 &times; 35</option>
      <option value="30*30">30 &times; 30</option>
      <option value="30*35">30 &times; 35</option>
      <option value="30*40">30 &times; 40</option>
      <option value="35*35">35 &times; 35</option>
      <option value="35*40">35 &times; 40</option>
      <option value="35*45">35 &times; 45</option>
      <option value="40*40">40 &times; 40</option>
      <option value="40*45">40 &times; 45</option>
      <option value="40*50">40 &times; 50</option>
      <option value="45*45">45 &times; 45</option>
      <option value="45*50">45 &times; 50</option>
      <option value="45*55">45 &times; 55</option>
      <option value="50*50">50 &times; 50</option>
      <option value="50*55">50 &times; 55</option>
      <option value="55*55">55 &times; 55</option>
      <option value="50*60">50 &times; 60</option>
      <option value="55*60">55 &times; 60</option>
    </select>
    <div class="">
      فرم:
    </div>
    <select style="width: 200px;font-size: 17px;" name="gram" id="halat">
      <option value="عمودی">عمودی</option>
      <option value="افقی">افقی</option>
    </select>
    <!-- <div class="">
      دسته:
    </div>
    <select style="width: 200px;font-size: 17px;" name="gram">
      <option value="دارد">دارد</option>
      <option value="ندارد">ندارد</option>
    </select> -->
    <div class="">
      مبلغ:
    </div>
    <input type="text" id="order-price" name="price" value="">
    <button type="button" name="button" onclick="confirmInsert()" class="button-send">ثبت</button>

  </div>
  <div id="alert-delete">

  </div>
<div class="result">

</div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
