stUrlId=window.location.hash.substring(1);
if(stUrlId==undefined){
  pageId=1;
}else {
  pageId=parseInt(stUrlId);
}
var choise='';
function uploadImage() {
  choise='insert';
  var rnd = Math.random();
  var token = e("token");
  var  fileUpload=e('file-upload').files[0];
  var formdata = new FormData();
  formdata.append("id",rnd);

  formdata.append("file[0]", fileUpload);
  // document.getElementById('result').innerHTML=pic;
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/insert.php";
  postRequest(url,formdata);
}
function select(){
  return 'a';
}
selectAll(1);
function selectAll(idPage) {
  choise='select';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_page",idPage);
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/select_all.php";
  postRequest(url,formdata);
}
function alertImgDelete(idDelete,imageName){
alert();
}
function imgDelete(idDelete,imageName){
  console.log('llllllll');
  choise='delete';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_delete",idDelete);
  formdata.append("image_name",imageName);
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/delete.php";
  console.log(imageName);
  postRequest(url,formdata);
}
function insertContent() {
  choise='content';
  var rnd = Math.random();
  var token = e("token");


  var eSize = e("size");
  var sizeValue = eSize.value;
  // var textSize = eSize.options[eSize.selectedIndex].text;

  var eHalat = document.getElementById("halat");
  var halatValue = eHalat.value;
  var textHalat = eHalat.options[eHalat.selectedIndex].text;

  var eGarma = document.getElementById("garma");
  var garmaValue = eGarma.value;
  var textGarma = eGarma.options[eGarma.selectedIndex].text;

  var eKaset = document.getElementById("kaset");
  var kasetValue = eKaset.value;
  var textKaset = eKaset.options[eKaset.selectedIndex].text;

    var orderPrice  = document.getElementById("order-price").value;

console.log(orderPrice);
  var formdata = new FormData();
  formdata.append("id",rnd);

  formdata.append("size", sizeValue);
  formdata.append("halat", textHalat);
  formdata.append("garma", textGarma);
  formdata.append("kaset", textKaset);
  formdata.append("order_price", orderPrice);

  // document.getElementById('result').innerHTML=pic;
  formdata.append("token_client",token.value);
  var url = "api/pages/order/add_order/insert.php";
  postRequest(url,formdata);
}
