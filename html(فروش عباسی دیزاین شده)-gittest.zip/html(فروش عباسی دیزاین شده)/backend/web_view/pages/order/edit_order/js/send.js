// const queryString = window.location.search;
// const urlParams = new URLSearchParams(queryString);
// const product = urlParams.get('edit');
// console.log(product);
// console.log(product);
var editUrl=getParameterByName('edit');

stUrlId=window.location.hash.substring(1);
if(stUrlId==undefined){
  pageId=1;
}else {
  pageId=parseInt(stUrlId);
}
var choise='';
function uploadImage() {
  choise='insert';
  var rnd = Math.random();
  var token = e("token");
  var  fileUpload=e('file-upload').files[0];
  var formdata = new FormData();
  formdata.append("id",rnd);

  formdata.append("file[0]", fileUpload);
  // document.getElementById('result').innerHTML=pic;
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/insert.php";
  postRequest(url,formdata);
}
selectContent(editUrl);
function selectContent(idPage) {
  console.log(11);
  choise='selectContent';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_page",idPage);
  formdata.append("token_client",token.value);
  var url = "api/pages/order/add_order/select.php";
  postRequest(url,formdata);
}

function select() {
  return 'ok';
}

// selectAll(1);
function selectAll(idPage) {
  choise='select';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_page",idPage);
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/select_all.php";
  postRequest(url,formdata);
}
function alertImgDelete(idDelete,imageName){
alert();
}
function imgDelete(idDelete,imageName){
  console.log('llllllll');
  choise='delete';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_delete",idDelete);
  formdata.append("image_name",imageName);
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/delete.php";
  console.log(imageName);
  postRequest(url,formdata);
}
function confirmUpdate() {
  choise='content';
  var rnd = Math.random();
  var token = e("token");



    var eSize = e("size");
    var sizeValue = eSize.value;
    // var textSize = eSize.options[eSize.selectedIndex].text;

    var eHalat = document.getElementById("halat");
    var textHalat = eHalat.options[eHalat.selectedIndex].text;

    var eGarma = document.getElementById("garma");
    var textGarma = eGarma.options[eGarma.selectedIndex].text;

    var eKaset = document.getElementById("kaset");
    var textKaset = eKaset.options[eKaset.selectedIndex].text;

      var orderPrice  = document.getElementById("order-price").value;

    var formdata = new FormData();
    formdata.append("id",rnd);

    formdata.append("size", sizeValue);
    formdata.append("halat", textHalat);
    formdata.append("garma", textGarma);
    formdata.append("kaset", textKaset);
    formdata.append("order_price", orderPrice);
    formdata.append("blog_id", editUrl);
    // document.getElementById('result').innerHTML=pic;
    formdata.append("token_client",token.value);
  //
  // var gram=e("blog-title");
  // var cassette=e("price_second_color");
  // var size=e("choose_second_color");
  // var form=e("zanbil_handel_90");
  // var price=e("zanbil_handel_60");
  //
  //
  // var formdata = new FormData();
  // formdata.append("id",rnd);
  //
  // formdata.append("garm", gram.value);
  // formdata.append("cassette", cassette.value);
  // formdata.append("size", size.value);
  // formdata.append("form", form.value);
  // formdata.append("price", price.value);
  // // formdata.append("silver", silver.value);
  // // formdata.append("phosphoric", phosphoric.value);
  // // formdata.append("golden", golden.value);
  // // formdata.append("white", white.value);
  // // formdata.append("add_Percent", addPercent.value);
  // formdata.append("blog_id", editUrl);
  //
  //
  // // document.getElementById('result').innerHTML=pic;
  // formdata.append("token_client",token.value);
  var url = "api/pages/order/add_order/update.php";
  postRequest(url,formdata);
}
