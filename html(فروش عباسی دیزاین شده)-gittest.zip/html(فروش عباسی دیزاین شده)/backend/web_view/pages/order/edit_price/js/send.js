// const queryString = window.location.search;
// const urlParams = new URLSearchParams(queryString);
// const product = urlParams.get('edit');
// console.log(product);
// console.log(product);
var editUrl=getParameterByName('edit');
function select() {
  return 1;
}
stUrlId=window.location.hash.substring(1);
if(stUrlId==undefined){
  pageId=1;
}else {
  pageId=parseInt(stUrlId);
}
var choise='';
function uploadImage() {
  choise='insert';
  var rnd = Math.random();
  var token = e("token");
  var  fileUpload=e('file-upload').files[0];
  var formdata = new FormData();
  formdata.append("id",rnd);

  formdata.append("file[0]", fileUpload);
  // document.getElementById('result').innerHTML=pic;
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/insert.php";
  postRequest(url,formdata);
}
selectContent(editUrl);
function selectContent(idPage) {
  console.log(11);
  choise='selectContent';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_page",idPage);
  formdata.append("token_client",token.value);
  var url = "api/pages/order/add_price/select.php";
  postRequest(url,formdata);
}



// selectAll(1);
function selectAll(idPage) {
  choise='select';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_page",idPage);
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/select_all.php";
  postRequest(url,formdata);
}
function alertImgDelete(idDelete,imageName){
alert();
}
function imgDelete(idDelete,imageName){
  console.log('llllllll');
  choise='delete';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_delete",idDelete);
  formdata.append("image_name",imageName);
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/delete.php";
  console.log(imageName);
  postRequest(url,formdata);
}
function confirmUpdate() {
  choise='content';
  var rnd = Math.random();
  var token = e("token");
  var blogTitle=e("blog-title");
  var priceSecondColor=e("price_second_color");
  var chooseSecondColor=e("choose_second_color");
  var zanbilHandel90=e("zanbil_handel_90");
  var zanbilHandel60=e("zanbil_handel_60");
  var zanbilHandel40=e("zanbil_handel_40");
  var silver=e("silver");
  var phosphoric=e("phosphoric");
  var golden=e("golden");
  var white=e("white");
  var print1=e("print1");
  var print2=e("print2");
  var addPercent=e("add_Percent");
  var addPercent=Number(addPercent.value);
  console.log(addPercent);
  console.log(addPercent);
  console.log(addPercent);
  console.log(addPercent);

  var formdata = new FormData();
  formdata.append("id",rnd);

  formdata.append("blog_title", blogTitle.value);
  formdata.append("price_second_color", priceSecondColor.value);
  formdata.append("choose_second_color", chooseSecondColor.value);
  formdata.append("zanbil_handel_90", zanbilHandel90.value);
  formdata.append("zanbil_handel_60", zanbilHandel60.value);
  formdata.append("zanbil_handel_40", zanbilHandel40.value);
  formdata.append("silver", silver.value);
  formdata.append("phosphoric", phosphoric.value);
  formdata.append("golden", golden.value);
  formdata.append("white", white.value);
  formdata.append("print1", print1.value);
  formdata.append("print2", print2.value);
  formdata.append("add_Percent", addPercent);
  formdata.append("blog_id", editUrl);


  // document.getElementById('result').innerHTML=pic;
  formdata.append("token_client",token.value);
  var url = "api/pages/order/add_price/update.php";
  postRequest(url,formdata);
}
