
<div class="main-center">
  <div class="topbar">

    <div class="home">
      ویرایش گالری
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>



  <div class="page-wrapper box-content">

    <div class="">
      قیمت رنگ اول:
    </div>
    <input type="text" id="blog-title" name="title" value="">
    <div class="">
      قیمت رنگ دوم:
    </div>
    <input type="text" class="edit-price"id="price_second_color" name="title" value="">
    <div class="">
      قیمت انتخاب رنگ دوم:
    </div>
    <input type="text" class="edit-price" id="choose_second_color" name="title" value="">
    <div class="">
      قیمت دسته زنبیلی ۹۰ گرم:
    </div>
    <input type="text" class="edit-price" id="zanbil_handel_90" name="title" value="">
    <div class="">
            قیمت دسته زنبیلی ۶۰ گرم:
    </div>
    <input type="text" class="edit-price" id="zanbil_handel_60" name="title" value="">
    <div class="">
            قیمت دسته زنبیلی ۴۰ گرم:
    </div>
    <input type="text" class="edit-price" id="zanbil_handel_40" name="title" value="">
    <div class="">
      قیمت رنگ نقره ای:
    </div>
    <input type="text" class="edit-price" id="silver" name="title" value="">
    <div class="">
      قیمت رنگ فسفوری:
    </div>
    <input type="text" class="edit-price" id="phosphoric" name="title" value="">
    <div class="">
      قیمت رنگ طلایی:
    </div>
    <input type="text" class="edit-price" id="golden" name="title" value="">
    <div class="">
      قیمت رنگ سفید:
    </div>
    <input type="text" class="edit-price" id="white" name="title" value="">
    <div class="">
      قیمت چاپ یک طرفه:
    </div>
    <input type="text" class="edit-price" id="print1" name="title" value="">
    <div class="">
      قیمت چاپ دوطرفه:
    </div>
    <input type="text" class="edit-price" id="print2" name="title" value="">
    <div class="">
      درصد افزایش قیمت:
    </div>
    <input type="text" class="edit-price" id="add_Percent" name="title" value="">

  </div>
  <button type="button" name="button" onclick="confirmUpdate()" class="button-send">ویرایش</button>

  </div>
  <div id="blur">
    <div class="show-select-file">
      <i class="fa fa-close close-blur"  onclick="closeBlur()"></i>
      <form class="upload-image" action="index.html" method="post" enctype="multipart/form-data">
        <!-- <label for="fileUpload">Upload file</label>   -->
        <input type="file" id="file-upload" value="" class="input"  accept="image/*">
        <button type="button" class="pic-button" name="button" onclick="uploadImage()">بارگذاری تصویر</button>
        <div id="blog-page-number">
          <div class="row1">
          </div>
          <div class="row1">
          </div>
          <div class="row1">
          </div>
          <!-- <div id="row2">
          </div>
          <div id="row3">
          </div> -->
        </div>
      </form>
      <div id="box-gallery">
      </div>
    </div>
  </div>
  <div id="alert-delete">

  </div>
<div class="result">

</div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
