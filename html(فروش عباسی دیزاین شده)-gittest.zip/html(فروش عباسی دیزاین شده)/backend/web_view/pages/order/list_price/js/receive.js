var fileCount=0;
function updatepage(str) {
  var myObj = JSON.parse(str);
  var imageName=myObj.Data["image_name"];
  var imageId=myObj.Data['image_id'];
  if(myObj.messageCode.code=="110" && <?=$_SESSION['id']?>!== 'undefined'){
    if (choise=='insert') {
      e('image-name').value='../uploads/'+imageName;
      e('imageURL').value='..//uploads/'+imageName;
      e('box-gallery').innerHTML='<div class="column-gallery"><button class="delete-gallery" onclick="imgDelete(\''+imageId+'\',\''+imageName+'\')"><i class="fa fa-trash"></i></button><img src="../uploads/'+imageName+'" class="galley-img" alt=""></div>'
      +e('box-gallery').innerHTML;
      setTimeout(function(){  e('blur').style.display='none';}, 2000);
      showFile();
    }else if(choise=='select') {
      var id;
      var priceFirstColor;
      var priceSecontColor;
      var zanbilHandel60;
      var zanbilHandel90;
      var silver;
      var phosphoric;
      var golden;
      var white;
      var addPercent;
      e('table-blog').innerHTML='';
      for (var i = 0; i < myObj.Data.length; i++) {
        id=myObj.Data[i]['id'];
        priceFirstColor=myObj.Data[i]['price_first_color'];
        priceSecondColor=myObj.Data[i]['price_second_color'];
        priceSecondColor=myObj.Data[i]['price_second_color'];
        chooseSecondColor=myObj.Data[i]['choose_second_color'];
        zanbilHandel90=myObj.Data[i]['zanbil_handel_90'];
        zanbilHandel60=myObj.Data[i]['zanbil_handel_60'];
        silver=myObj.Data[i]['silver'];
        phosphoric=myObj.Data[i]['phosphoric'];
        golden=myObj.Data[i]['golden'];
        white=myObj.Data[i]['white'];
        addPercent=myObj.Data[i]['add_Percent'];
        e('table-blog').innerHTML+='<tr><td>'+id+'</td><td>'+priceFirstColor+'</td><td>'+addPercent+'</td><td>'+white+'</td><td>'+golden+'</td><td>'+phosphoric+'</td><td>'+silver+'</td><td>'+zanbilHandel60+'</td><td>'+zanbilHandel90+'</td><td>'+priceSecondColor+'</td><td>'+chooseSecondColor+'</td><td class="cursor" onclick="editGallery('+id+')">ویرایش</td><td style="color:red;" onclick="confirmDelete('+id+')" class="cursor">حذف</td></tr>';
        showFile();
      }

//------------------------------------------------------------------------
      if(myObj.Data2!=undefined){

        fileCount=Math.ceil(myObj.Data2['blog_count']/10);
      }
      var row1=document.querySelectorAll('.row1');
       stUrlId=window.location.hash.substring(1);
       if(stUrlId==undefined){
         pageId=1;
       }else {
         pageId=parseInt(stUrlId);
       }
      row1[0].innerHTML='';
      row1[1].innerHTML='';
      row1[2].innerHTML='';
      row1[0].innerHTML='<a href="#1" class="page-number-a">'+(1)+'</a>';
      if(fileCount>1){
        row1[0].innerHTML+='<a href="#2" class="page-number-a">'+(2)+'</a>';
      }
      if(fileCount>2){
        row1[0].innerHTML+='<a href="#3" class="page-number-a">'+(3)+'</a>';
      }
      if(pageId>5){
        row1[1].innerHTML+='<span class="page-number-span">...</span>';
      }
      for (var i =pageId;i<(pageId+3);i++) {
        console.log(pageId);
        if(i>4 && i<(fileCount-1)){
          row1[1].innerHTML+='<a href="#'+(i-1)+'" class="page-number-a">'+(i-1)+'</a>';
        }
      }
      if( pageId<(fileCount-4)){
        row1[1].innerHTML+='<span class="page-number-span">...</span>';
      }
      if(fileCount>5){
        row1[2].innerHTML+= '<a href="#'+(fileCount-2)+'" class="page-number-a">'+(fileCount-2)+'</a>';
      }
        if(fileCount>4){
        row1[2].innerHTML+='<a href="#'+(fileCount-1)+'" class="page-number-a">'+(fileCount-1)+'</a>';
      }
        if(fileCount>3){
        row1[2].innerHTML+='<a href="#'+fileCount+'" class="page-number-a">'+(fileCount)+'</a>';
      }


      pageNumberA=document.querySelectorAll('.page-number-a');

      pageNumberA.forEach(item => {
        item.addEventListener('click', event => {

          selectAll(item.innerHTML);

        })
      })
    }else if(choise=='content'){
      location.reload();
    }
    else if (choise=='deleteContent') {
      selectAll(1);
      alert('حذف با موفقیت انجام شد');
    }
    else {
      selectAll(1);
    }
  }else{
    // document.getElementById("result").innerHTML = myObj.messageCode.code;
  }

}

showFile();
// pageNumberA=document.querySelectorAll('.page-number-a');
// pageNumberA.forEach(item => {
//   item.addEventListener('click', event => {
//     selectAll(item.innerHTML);
//   })
// })
// let close =  document.querySelectorAll('.richText-dropdown-close');
