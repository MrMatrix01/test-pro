
<div class="main-center">
  <div class="topbar">

    <div class="home">
      ویرایش قیمت
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>
  <div class="table">
    <table id="table-blog">
      <tr>
        <td>id</td>
        <td>price_first_color</td>
        <td>price_secont_color</td>
        <td>choose_second_color</td>
        <td>zanbil_handel_90</td>
        <td>zanbil_handel_60</td>
        <td>silver</td>
        <td>phosphoric</td>
        <td>golden</td>
        <td>white</td>
        <td>add_Percent</td>

        <td>edit</td>
        <td>update</td>
      </tr>
    </table>
    <div id="blog-page-number">
      <div class="row1">
      </div>
      <div class="row1">
      </div>
      <div class="row1">
      </div>
    </div>
  </div>
  <div id="alert-delete">

  </div>
<div class="result">

</div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
