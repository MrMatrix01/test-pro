
<div class="main-center">
  <div class="topbar">

    <div class="home">
      ویرایش کالا
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>
  <div class="table">
    <table>
      <thead>
      <tr>
        <td>id</td>
        <td>gram</td>
        <td>cassette</td>
        <td>size</td>
        <td>form</td>
        <td>price</td>

        <td>edit</td>
        <td>delete</td>
      </tr>
      </thead>
      <tbody id="table-blog">

      </tbody>
    </table>
    <div id="blog-page-number">
      <div class="row1">
      </div>
      <div class="row1">
      </div>
      <div class="row1">
      </div>
    </div>
  </div>
  <div id="alert-delete">

  </div>
<div class="result">

</div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
