var choise='';


selectContent();
function selectContent() {
  choise='update_content';
    var rnd = Math.random();
    var token = e("token");
    var formdata = new FormData();
    formdata.append("id",rnd);
    formdata.append("token_client",token.value);
    var url = "api/pages/price_list/select.php";
    postRequest(url,formdata);
}
function selectAll(idPage) {
  choise='select';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_page",idPage);
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/select_all.php";
  postRequest(url,formdata);
}

function uploadImage() {
  choise='insert';
  var rnd = Math.random();
  var token = e("token");
  var  fileUpload=e('file-upload').files[0];
  var formdata = new FormData();
  formdata.append("id",rnd);

  formdata.append("file[0]", fileUpload);
  // document.getElementById('result').innerHTML=pic;
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/insert.php";
  postRequest(url,formdata);
}

function alertImgDelete(idDelete,imageName){
alert();
}
function imgDelete(idDelete,imageName){
  console.log('llllllll');
  choise='delete';
  var rnd = Math.random();
  var token = e("token");
  var formdata = new FormData();
  formdata.append("id",rnd);
  formdata.append("id_delete",idDelete);
  formdata.append("image_name",imageName);
  formdata.append("token_client",token.value);
  var url = "api/plugins/files_manager/delete.php";
  console.log(imageName);
  postRequest(url,formdata);
}
function insertContent() {
  choise='content';
  var rnd = Math.random();
  var token = e("token");
  var content=e("min-content");
  var formdata = new FormData();
  formdata.append("id",rnd);

  formdata.append("content", content.value);

  // document.getElementById('result').innerHTML=pic;
  formdata.append("token_client",token.value);
  var url = "api/pages/price_list/update.php";
  postRequest(url,formdata);
}
