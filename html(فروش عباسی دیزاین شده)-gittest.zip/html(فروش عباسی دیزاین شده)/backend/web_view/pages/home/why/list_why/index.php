
<div class="main-center">
  <div class="topbar">

    <div class="home">
      چراایران بگ؟
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>
  <div class="table">
    <table id="table-blog">
      <tr>
        <td>id</td>
        <td>title</td>
        <td>edit</td>
        <td>update</td>
      </tr>
    </table>
    <div id="blog-page-number">
      <div class="row1">
      </div>
      <div class="row1">
      </div>
      <div class="row1">
      </div>
    </div>
  </div>
  <div id="alert-delete">

  </div>
<div class="result">

</div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
