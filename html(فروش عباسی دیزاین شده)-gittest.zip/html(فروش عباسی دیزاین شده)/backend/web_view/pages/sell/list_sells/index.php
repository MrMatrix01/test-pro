
<div class="main-center">
  <div class="topbar">

    <div class="home">
      ویرایش کالا
    </div>
    <div class="logout">
      خروج
    </div>
  </div>
  <div class="welcome">
    خوش آمدید
  </div>
  <div id="info-sells" class="info-sells">
    <input id="info-sell-input-2" class="info-sell-input" type="hidden" name="" value="">
    <input id="info-sell-input-1" class="info-sell-input" type="hidden" name="" value="">
    <input id="info-sell-input0" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input1" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input2" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input3" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input4" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input5" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input7" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input8" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input9" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input10" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input14" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input15" class="info-sell-input" type="text" name="" value="">
    <input id="info-sell-input16" class="info-sell-input" type="text" name="" value="">
    <div class="info-sell-input">
      <!-- <div style="float: right;margin-top: 10px;" class="">
          ارسال شد
      </div> -->
      <!-- <input class="info-sell-input" style="margin-right: 35%;margin-top: 0%;" id="info-sell-input12"  type="checkbox" name="" value="ارسال"> -->
      در حال بررسی
      <input type="radio" name="status" style="margin-left: 5px;" value="0" >
      در حال تولید
      <input type="radio" name="status" style="margin-left: 5px;" value="2" >
      آماده تحویل
      <input type="radio" name="status" style="margin-left: 5px;" value="3" >
      ارسال شده
      <input type="radio" name="status" style="margin-left: 5px;" value="1" >
    </div>
    <input id="info-sell-input6" class="info-sell-input" type="text" name="" value="">
    <img id="info-sell-input12" src="" class="info-img-sell" alt="">
    <img id="info-sell-input13" src="" class="info-img-sell" alt="">
    <div id='div-check'>

    </div>
    <!-- <input id="info-sell-input11" class="info-sell-input" type="text" name="" value=""> -->
    <!-- <img src="" id="info-sell-input11"  alt=""> -->
  </div>
  <div class="table">
    <table>
      <thead>
      <tr>
        <td>ردیف</td>
        <td>شماره خریدار</td>
        <td>دسته</td>
        <td>تعداد</td>
        <td>قیمت</td>
        <td>گرما</td>
        <td>فرم</td>
        <td>کاست</td>
        <td>سایز</td>
        <td>باربری</td>
        <!-- <td>price</td>
        <td>price</td>
        <td>price</td> -->
        <!-- <td>price</td> -->
        <!-- <td>price</td> -->
        <!-- <td>price</td>
        <td>price</td>
        <td>price</td>
        <td>price</td>
        <td>price</td> -->
        <!-- <td>price</td> -->

        <td>ویرایش</td>
        <!-- <td>update</td> -->
      </tr>
    </thead >
    <tbody id="table-blog">

    </tbody>
    </table>
    <div id="blog-page-number">
      <div class="row1">
      </div>
      <div class="row1">
      </div>
      <div class="row1">
      </div>
    </div>
  </div>
  <div id="alert-delete">

  </div>
<div class="result">

</div>
  <script>
  $(document).ready(function() {
    $('.content').richText();
    $('.content2').richText();
  });
  </script>
</div>
