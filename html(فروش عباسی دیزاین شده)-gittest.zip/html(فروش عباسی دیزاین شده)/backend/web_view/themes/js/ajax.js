function postRequest(strURL,formdata) {
    var xmlHttp;
    if (window.XMLHttpRequest) { // Mozilla, Safari, ...
        var xmlHttp = new XMLHttpRequest();
    } else if (window.ActiveXObject) { // IE
        var xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlHttp.open('POST', strURL, true);
    // xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xmlHttp.onreadystatechange = function() {
        if (xmlHttp.readyState == 4) {
            updatepage(xmlHttp.responseText);
        }
    }
    xmlHttp.send(formdata);
}
// function postRequest2(strURL) {
//     var xmlHttp;
//     if (window.XMLHttpRequest) { // Mozilla, Safari, ...
//         var xmlHttp = new XMLHttpRequest();
//     } else if (window.ActiveXObject) { // IE
//         var xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
//     }
//     xmlHttp.open('POST', strURL, true);
//     xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
//     xmlHttp.onreadystatechange = function() {
//         if (xmlHttp.readyState == 4) {
//             updatepage(xmlHttp.responseText);
//         }
//     }
//     xmlHttp.send(strURL);
// }
