
function e(x) {
  return document.getElementById(x);
}
function selectFile() {
  document.getElementById('blur').style.display="block";

}
function getParameterByName(name, url = window.location.href) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
function closeBlur() {
  document.getElementById('blur').style.display="none";
}
function uploadImage() {
  var  pic=document.getElementById("pic").files[0];
  var formdata = new FormData();
  formdata.append("file[0]", pic);
}

function showFile() {
  galleyImg=document.querySelectorAll('.galley-img');
  galleyImg.forEach(item => {
    item.addEventListener('click', event => {
      document.getElementById('image-name').value=item.src;
      document.getElementById('imageURL').value=item.src;
      document.getElementById('blur').style.display='none';
    })
  })
}
showFile();
function deleteFile() {
  galleyImg=document.querySelectorAll('.delete-gallery');
  galleyImg.forEach(item => {
    item.addEventListener('click', event => {
      document.getElementById('image-name').value=item.src;
      document.getElementById('imageURL').value=item.src;
      document.getElementById('blur').style.display='none';
    })
  });
}
deleteFile();

function confirmInsert() {
if (confirm('آیا با ثبت این مطلب موافق هستید؟')) {
  // window.location = '?del='+id
  insertContent();
};
}
function confirmUpdate() {
if (confirm('آیا با ویرایش این مطلب موافق هستید؟')) {
  // window.location = '?del='+id
  updateContent();
};
}
function confirmDelete(id) {
if (confirm('آیا با حذف این مطلب موافق هستید؟')) {
  // window.location = '?del='+id
  deleteContent(id);
};
}
function change() {
  alert('تغییرات انجام شد.');
}
// pageNumberA=document.querySelectorAll('.page-number-a');
// pageNumberA.forEach(item => {
//   item.addEventListener('click', event => {
//     selectAll(item.innerHTML);
//   })
// })
// let close =  document.querySelectorAll('.richText-dropdown-close');
