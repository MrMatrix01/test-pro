<script type="text/javascript">
<?php

if(isset($response)){
 ?>
var myObj=<?=$response?>;
<?php
}
include $route_page.'js/send.js';
include $route_page.'js/receive.js';
?>
</script>
