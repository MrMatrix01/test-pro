<?php
session_start();
require_once 'web_view/routes/web.php';
header("X-Frame-Options:DENY");
?>
<head>
  <meta charset="utf-8">
  <title></title>
  <link rel="stylesheet" href="web_view/themes/css/font-awesome.min.css">
  <link href="web_view/themes/css/style.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="web_view/themes/css/richtext.min.css">
  <!-- <link rel="shortcut icon" href="home/images/4.ico" type="image/x-icon"> -->
  <?php
  function makeToken()
  {
    return $_SESSION['token'] = base64_encode(md5(microtime()));
  }
  ?>
  <input type="hidden"  id="token" value="<?= makeToken() ?>">
  <script type="text/javascript" language="javascript" src="web_view/themes/js/jquery/3.2.1/jquery.min.js" charset="utf-8"></script>
  <script type="text/javascript" language="javascript" src="web_view/themes/js/jquery/jquery.richtext.min.js" charset="utf-8"></script>
  <script type="text/javascript" language="javascript" src="web_view/themes/js/script.js" charset="utf-8"></script>
  <script type="text/javascript" language="javascript" src="web_view/themes/js/ajax.js" charset="utf-8"></script>
</head>
