<div class="topbar">
  <a href="#">
<div class="home">
  مشاهده صفحه اصلی سایت
</div>
</a>
<a href="logout">
<div class="logout">
خروج
</div>
</a>
</div>
