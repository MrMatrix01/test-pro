<header>
  <div class="logo">
    <!-- <img src="views/images/logo.png" alt="" class="logo-image" /> -->
  </div>
  <div class="name">
    سیستم مدیریت محتوا
  </div>
</header>
