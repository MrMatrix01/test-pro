<footer>
<div class="hoghogh">

</div>
<div class="t-hoghogh">

</div>
</footer>
