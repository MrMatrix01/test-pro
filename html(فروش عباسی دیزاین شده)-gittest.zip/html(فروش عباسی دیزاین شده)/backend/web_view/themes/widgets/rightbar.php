<div class="rightbar">
  <div class="profile">
  <div class="avatar-dashboard">
    <img  id="avatar" class="avatar" />
  </div>
  <div class="name-dashboard" id="name-dashboard">
<?php
// echo $dbName;
?>
  </div>
  <div class="menu">
    <ul id="nav">

      <li>
        <a href="add_blog">اضافه کردن مقالات آموزشی</a>
      </li>
      <li>
        <a href="list_blog">ویرایش مقالات آموزشی</a>
      </li>
      <!-- <li>
        <a href="add_blog">داشبورد</a>
      </li> -->
      <li>
        <a href="add_gallery">اضافه کردن گالری</a>
      </li>
      <li>
        <a href="list_gallery">ویرایش گالری</a>
      </li>
      <li>
        <a href="list_slide">ویرایش اسلاید</a>
      </li>
      <li>
        <a href="list_why">ویرایش چرا ایران بگ</a>
      </li>

      <li>
        <a href="price_list">تصویر لیست قیمتها</a>
      </li>
      <li>
        <a href="list_comment">لیست نظرات</a>
      </li>

      <li>
        <a href="about">درباره ما</a>
      </li>
      <li>
        <a href="contact">تماس با ما</a>
      </li>
      <!-- //////////////// -->
      <li class="li-back">
        <a href="list_transaction">تمامی تراکنش ها</a>
      </li>
      <li class="li-back">
        <a href="list_sells">لیست سفارش ها</a>
      </li>
      <li class="li-back">
        <a href="edit_price?edit=1">ویرایش قیمت های ثابت</a>
      </li>
      <!-- <li class="li-back">
        <a href="add_price">افزودن قیمت های انتخابی</a>
      </li> -->
      <li class="li-back">
        <a href="add_order">اضافه کردن قیمت انتخابی</a>
      </li>
      <li class="li-back">
        <a href="list_order">لیست قیمت های انتخابی</a>
      </li>
      <li class="li-back">
        <a href="list_users">لیست کاربران</a>
      </li>
      <!-- <li class="li-back">
        <a href="list_price">لیست قیمت</a>
      </li> -->
    </ul>
  </div>
</div>
</div>
