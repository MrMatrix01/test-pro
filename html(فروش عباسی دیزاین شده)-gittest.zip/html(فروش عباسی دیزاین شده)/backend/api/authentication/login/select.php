<?php
include_once '../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$data = array(
  $checked->checkPost('username', 100, 'notNull'),
  $checked->checkPost('password', 150, 'notNull'),
);
$update_token_client = array(
  $checked->checkPost('token_client', 100, 'notNull'),
);
$output->login($data, $update_token_client);
