<?php
class DbAction extends Config
{
  public function select($data)
  {
    $host = $this->host;
    $dbname = $this->dbname;
    $user = $this->user;
    $pass = $this->pass;
    try {
      $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'SELECT * FROM `managers` WHERE `username`=? && `password`=?';

      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $this->count = $stmt->rowCount();
      $sh = $stmt->fetch();
      $this->id=@$sh['id'];
      if($this->count==1){
        // $_SESSION['id']=$sh['username'];
      $this->temp[] = array(
        "id" => $sh['id'],
        "username" => $sh['username'],
        // "password" => $sh['password'],
      );
      }

      return 'noError';
    } catch (PDOException $e) {
      return  'Error';
    }
    $conn = null;
  }
  public function update_token_client($update_token_client)
  {
    $host = $this->host;
    $dbname = $this->dbname;
    $user = $this->user;
    $pass = $this->pass;
    try {
      $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sqlUpdate = 'UPDATE `managers` SET `token_client`=? WHERE  `id`=?';
      $stmtUpdate = $conn->prepare($sqlUpdate);
      $stmtUpdate->execute($update_token_client);
      return 'noError';
    } catch (PDOException $e) {
      //echo $sql.'<br>'.$e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
}
 ?>
