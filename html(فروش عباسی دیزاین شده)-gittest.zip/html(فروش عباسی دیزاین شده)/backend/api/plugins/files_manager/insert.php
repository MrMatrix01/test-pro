<?php
include_once '../../../../kernel/config/config.php';
include_once '../../../../kernel/lib/uploads.php';
$valid_formats = array('jpg', 'png', 'jpeg', 'PNG', 'JPG');
$max_file_size = 1024 * 1024 * 10; //100 kb
$path = '../../../../uploads/'; // Upload directory
// $path2='/uploads/';
$uploads=New Uploads();
  $uploads->upload($max_file_size, $path, $valid_formats);
  $fileNew = $uploads->file;
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$data = array(
  $fileNew[0],
);
$output->insert_data($data);
