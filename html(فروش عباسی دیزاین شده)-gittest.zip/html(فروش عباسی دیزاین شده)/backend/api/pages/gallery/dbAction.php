<?php
class DbAction extends Config
{
  public function insert($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO `rtl_lnd_gallery` (`title`,`content`,`Preview_image`)
      VALUES(?,?,?)";
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
       $id = $conn->lastInsertId();
      $sh = $stmt->fetch();
      $this->temp = array(
         "gallery_id"=>$id,
        // "image_name" => $data[0],
      );
      return 'noError';
    } catch (PDOException $e) {
      echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
  public function selectAll($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT * FROM `rtl_lnd_gallery`  ORDER BY `id` DESC LIMIT $data[0],10";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();


      $sw = "SELECT * FROM  `rtl_lnd_gallery`";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count =  $qw->rowCount();
      foreach($sh as $key=>$value) {
        $content=explode("<!--more-->",@$value['content']);
        $this->temp[] = array(
          'id' => @$value['id'],
          'post_content' => @$content[0],
          'post_title' => @$value['title'],
          'guid' => @$value['Preview_image'],
        );
      }
      $this->temp2=array('blog_count' => $blog_count,);
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }

  public function delete($data)
{
 try {
   $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   $sql = 'DELETE FROM `rtl_lnd_gallery` WHERE `id` =?';
   $stmt = $conn->prepare($sql);
   $stmt->execute($data);
   $this->temp = array('id'=>$data[0]);
   return 'noError';
 } catch (PDOException $e) {
    echo $sql.'<br>'.$e->getMessage();
   return 'Error';
   //echo $sql.'<br>'.$e->getMessage();
 }

 $conn = null;
}
public function select($data)
{
   try {
  $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "SELECT * FROM `rtl_lnd_gallery` WHERE `id`=?";

  $stmt = $conn->prepare($sql);
  $stmt->execute($data);
  $sh=$stmt->fetch();
  $content=explode("<!--more-->",@$sh['content']);
  $this->temp = array(
    'id' => $sh['id'],
    'post_title'=>$sh['title'],
    'min_content'=>$content[0],
    'max_content'=>@$content[1],
    'guid'=>@$sh['Preview_image'],
  );
  return 'noError';
}catch (PDOException $e) {
    return 'Error';
    //echo $sql.'<br>'.$e->getMessage();
  }
}
public function update($data)
{
  try {
    $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = 'UPDATE `rtl_lnd_gallery` SET `title`=?,`content`=?,`Preview_image`=? WHERE `id`=?';
    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
      return 'noError';
  } catch (PDOException $e) {
    //return $e->getMessage();
    return 'Error';
  }
  $conn = null;
}
}
