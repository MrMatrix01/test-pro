<?php
class DbAction extends Config
{
  public function update($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8",$this->user,$this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $id=1;
      $sql = "UPDATE `rtl_lnd_comments_me` SET `min_content`=?,`max_content`=? WHERE `id`='$id'";
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      return 'noError';
    } catch (PDOException $e) {
      //return $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
  public function selectAll($data)
  {
    $var='post';
    $var1='attachment';
    $var2='open';
    $var3='0';
    $a=12;
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8",$this->user,$this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT * FROM `rtl_lnd_comments_me`  ORDER BY `id` DESC LIMIT $data[0],10";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $this->temp=$stmt->fetchAll();
      $sw = "SELECT * FROM  `rtl_lnd_comments_me`";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count =  $qw->rowCount();
      // foreach($sh as $key=>$value) {
      //     $this->temp[] = array(
      //       'id' => @$value['id'],
      //       'post_title' => @$value['title'],
      //       'post_content' => @$content[0],
      //       'post_date' => @$value['post_title'],
      //     );
      // }

      $this->temp2=array('blog_count' => $blog_count, );


      return 'noError';
    } catch (PDOException $e) {
      echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
  public function select($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT * FROM `rtl_lnd_comments_me` WHERE `id`=?";

      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $this->temp=$stmt->fetch();
      return 'noError';
    }catch (PDOException $e) {
      return 'Error';
      //echo $sql.'<br>'.$e->getMessage();
    }
  }
}
