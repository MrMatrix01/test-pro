<?php
include_once '../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$data = array(
  $_POST['blog_title'],
  $_POST['blog_url'],
  $_POST['min_content'].'<!--more-->'.$_POST['max_content'],
    $checked->checkPost('blog_pre_image', 200, 'null'),
    $checked->checkPost('blog_id', 11, 'notNull'),
  // ($checked->checkPost('min_content', 1500, 'notNull').
  // '<!--more-->'.
  // $checked->checkPost('max_content', 2500, 'notNull')),

);
$output->update_data($data);
