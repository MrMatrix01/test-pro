<?php
class DbAction extends Config
{
  public function insert($data)
  {
    $var='post';
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO `rtl_lnd_posts` (`post_title`,`post_content`,`post_type`,`comment_count`,`menu_order`,`post_parent`,`post_mime_type`,`post_content_filtered`,`pinged`,`to_ping`,`post_name`,`post_password`,`ping_status`,`comment_status`,`post_status`,`post_excerpt`,`guid`)
      VALUES(?,?,'$var',0,0,0,'','','','','','','','','','',?)";
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $id = $conn->lastInsertId();
      $sh = $stmt->fetch();
      $this->temp = array(
        "blog_id"=>$id,
        // "image_name" => $data[0],
      );
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
  public function selectAll($data)
  {
    $var='post';
    $var1='attachment';
    $var2='open';
    $var3='0';
    $a=12;
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8",$this->user,$this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT * FROM `rtl_lnd_posts` WHERE `post_type`='$var'  ORDER BY `ID` DESC LIMIT $data[0],10";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();
      $sw = "SELECT * FROM  `rtl_lnd_posts` WHERE `post_type`='$var'";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count =  $qw->rowCount();
      foreach($sh as $key=>$value) {
        $sqll = "SELECT * FROM `rtl_lnd_posts` WHERE `post_type`='$var1'  AND `post_parent`=?";
        $stmtl = $conn->prepare($sqll);
        $stmtl->execute(array($value['ID']));
        $shl=$stmtl->fetch();
        $content=explode("<!--more-->",@$value['post_content']);
        if(!empty($shl['guid']) || $value['ID']>9199){
          if($value['ID']>9199){
            $guid = @$value['guid'];
          }else {
            $guid = @$shl['guid'];
          }
          $this->temp[] = array(
            'id' => @$value['ID'],
            'post_date' => @$value['post_date'],
            'post_content' => @$content[0],
            'post_title' => @$value['post_title'],
            'guid' => $guid,

          );
        }
      }

      $this->temp2=array('blog_count' => $blog_count, );


      return 'noError';
    } catch (PDOException $e) {
      echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }

  public function delete($data)
{
 try {
   $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   $sql = 'DELETE FROM `rtl_lnd_posts` WHERE `ID` =?';
   $stmt = $conn->prepare($sql);
   $stmt->execute($data);
   $this->temp = array('id'=>$data[0]);
   return 'noError';
 } catch (PDOException $e) {
    echo $sql.'<br>'.$e->getMessage();
   return 'Error';
 }

 $conn = null;
}
public function select($data)
{
   try {
  $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "SELECT * FROM `rtl_lnd_posts` WHERE `ID`=?";

  $stmt = $conn->prepare($sql);
  $stmt->execute($data);
  $sh=$stmt->fetch();
  $content=explode("<!--more-->",@$sh['post_content']);
  if($sh['ID']>9199){
    $guid=$sh['guid'];
  }
  $this->temp = array(
    'id' => $sh['ID'],
    'post_title'=>$sh['post_title'],
    'url' => @$sh['url'],
    'min_content'=>$content[0],
    'max_content'=>@$content[1],
    'guid'=>@$guid,
  );
  return 'noError';
}catch (PDOException $e) {
    return 'Error';
    //echo $sql.'<br>'.$e->getMessage();
  }
}
public function update($data)
{
  try {
    $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = 'UPDATE `rtl_lnd_posts` SET `post_title`=?,`url`=?,`post_content`=?,`guid`=? WHERE `ID`=?';
    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
      return 'noError';
  } catch (PDOException $e) {
    //return $e->getMessage();
    return 'Error';
  }
  $conn = null;
}
public function search($data)
{
  $var='post';
  $var1='attachment';
  $var2='open';
  $var3='0';
  $search=$data[0];

$likeWord='';

  $searchWord = explode(' ' ,$search);
  foreach ($searchWord as $key => $value) {
    $likeWord=$likeWord."AND `post_title`  LIKE '%$value%'";
  }





  try {
    $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8",$this->user,$this->pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // $sql = "SELECT `a`.`ping_status`,`a`.`post_type`,`a`.`post_content`,`a`.`post_content`,`b`.`guid`,`a`.`post_title`,`a`.`ID`,`b`.`post_parent`,`a`.`post_type` as `a_post_type`
    // FROM `rtl_lnd_posts` `a` LEFT JOIN `rtl_lnd_posts` `b`
    //  ON `a`.`ID`=`b`.`post_parent` WHERE `a`.`post_type`='$var' AND `a`.`ping_status`='$var2' AND `b`.`post_parent`<>'$var3' ORDER BY `a`.`ID` DESC LIMIT 100";
          $sql = "SELECT * FROM `rtl_lnd_posts` WHERE `post_type`='$var' $likeWord ORDER BY `ID` DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $sh=$stmt->fetchAll();


    $sw = "SELECT * FROM  `rtl_lnd_posts` WHERE `post_type`='$var'";
$qw = $conn->prepare($sw);
$qw->execute();
$blog_count =  $qw->rowCount();
    foreach($sh as $key=>$value) {
      $sqll = "SELECT * FROM `rtl_lnd_posts` WHERE `post_type`='$var1'  AND `post_parent`=?";
      $stmtl = $conn->prepare($sqll);
      $stmtl->execute(array($value['ID']));
      $shl=$stmtl->fetch();
      $content=explode("<!--more-->",@$value['post_content']);
       if(!empty($shl['guid']) || $value['ID']>9199){
         if($value['ID']>9199){
         $guid = @$value['guid'];
         // $urlObject = new GenerateSeoFriendlyURL($value['post_title'] , 9);
         // $seo_url=$urlObject->getUrl();
         }else {
           $guid = @$shl['guid'];
           // $seo_url=null;
         }
      $this->temp[] = array(
        'id' => @$value['ID'],
        'post_date' => @$value['post_date'],
        'post_content' => @$content[0],
        'url' => @$value['url'],
        'post_title' => @$value['post_title'],
        'guid' => $guid,
        // 'seo_url'=>$seo_url,
      );
     }
    }

$this->temp2=array('blog_count' => $blog_count, );


    return 'noError';
  } catch (PDOException $e) {
    echo $e->getMessage();
    return  'Error';
  }
  $conn = null;
}
}
