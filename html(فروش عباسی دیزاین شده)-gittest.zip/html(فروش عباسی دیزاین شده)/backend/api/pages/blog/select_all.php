<?php
include_once '../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$data = array(
  ($checked->checkPost('id_page', 11, 'notNull')-1)*10,
);
$output->selectAll_data($data);
