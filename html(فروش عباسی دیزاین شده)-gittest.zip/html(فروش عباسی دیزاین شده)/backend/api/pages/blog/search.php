<?php
include_once '../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$data = array(
  $checked->checkPost('search_value', 200, 'notNull')
);
$output->search_data($data);
