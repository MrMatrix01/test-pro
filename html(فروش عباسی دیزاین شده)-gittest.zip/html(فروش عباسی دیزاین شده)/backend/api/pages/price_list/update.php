<?php
include_once '../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$data = array(
  @$_POST['image'],
  @$_POST['content'],
);
$output->update_data($data);
