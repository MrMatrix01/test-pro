<?php

class DbAction extends Config
{
  public function insert($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO `rtl_order` (`gram`,`cassette`,`size`,`form`,`price`)
      VALUES(?,?,?,?,?)";

      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $id = $conn->lastInsertId();
      $sh = $stmt->fetch();
      $this->temp = array(
        "blog_id"=>$id,
      );
      return 'noError';
    } catch (PDOException $e) {
       echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
  public function selectAll($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT *,`buy_castomer`.`id` AS `id_buy_castomer` FROM `buy_castomer`
              LEFT JOIN `rtl_files_user` ON `id_rtl_files_user`=`rtl_files_user`.`id`
              WHERE `pey`=1  ORDER BY `id_buy_castomer` DESC LIMIT $data[0],10";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();







      $sw = "SELECT * FROM  `buy_castomer` WHERE `pey`=1";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count =  $qw->rowCount();




      // print_r(array_unique($array, SORT_REGULAR));

      foreach($sh as $key=>$value) {
        // echo $value['rtl_users_id'].'_';
        $id_user=$value['rtl_users_id'];
        $sql2 = "SELECT * FROM `rtl_users` WHERE `id`='$id_user'";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->execute();
        $sh2=$stmt2->fetch();

        $id_rtl_files_user2=@$value['id_rtl_files_user2'];
        $sql3 = "SELECT * FROM `rtl_files_user` WHERE `id`='$id_rtl_files_user2'";
        $stmt3 = $conn->prepare($sql3);
        $stmt3->execute();
        $sh3=$stmt3->fetch();



        $this->temp[] = array(
          'id_buy_castomer' => @$value['id_buy_castomer'],
          'handel' => @$value['handel'],
          'handel_color' => @$value['handel_color'],
          'first_color' => @$value['first_color'],
          'second_color' => @$value['second_color'],
          'number' => @$value['number'],
          'print' => @$value['print'],
          'price' => @$value['price'],
          'garma' => @$value['garma'],
          'form' => @$value['form'],
          'cassette' => @$value['cassette'],
          'size' => @$value['size'],
          'rtl_users_id' => @$value['rtl_users_id'],
          'address' => @$value['address'],
          'transport' => @$value['transport'],
          'mobile' => @$value['mobile'],
          'mobile2' => @$value['mobile2'],
          'phone' => @$value['phone'],
          'city' => @$value['city'],
          'state' => @$value['state'],
          'id_rtl_files_user' => @$value['id_rtl_files_user'],
          'file_name2' => @$sh3['file_name'],
          'file_name' => @$value['file_name'],
          'phone_user'=>@$sh2['username'],
          'sended' => @$value['sended'],
          'title' => @$value['title'],
          'description' => @$value['description'],
          'print_color' => @$value['print_color'],
        );
      }
      $this->temp2=array('blog_count' => $blog_count);
      return 'noError';
    } catch (PDOException $e) {
      echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
  public function select($data)
  {
     try {
    $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM `buy_castomer` WHERE `id`=?";

    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
    $sh=$stmt->fetch();
    // $content=explode("<!--more-->",@$sh['content']);
    $this->temp = array(
      'id' => $sh['id'],
      'gram'=>$sh['gram'],
      'cassette'=>$sh['cassette'],
      'size'=>$sh['size'],
      'form'=>$sh['form'],
      'price'=>$sh['price'],
      'id_rtl_files_user'=>$sh['id_rtl_files_user'],


    );
    return 'noError';
  }catch (PDOException $e) {
      return 'Error';
      //echo $sql.'<br>'.$e->getMessage();
    }
  }
  public function update($data)
  {

    $token=$data[3];
    if(isset($data[2])){
        $token10=$data[2];
    }else {
      $token10='وارد نشده';
    }

    $token10=urlencode($token10);
    if ($data[0]==0) {
      $token20='در حال بررسی';
      // $token20=urlencode($token20);
    }
    elseif ($data[0]==1) {
      $token20='ارسال شد';
      // $token20=urlencode($token20);

    }
    elseif ($data[0]==2) {
      $token20='در حال تولید';
      $token20=urlencode($token20);
    }
    elseif ($data[0]==3) {
      $token20='آماده تحویل';
      $token20=urlencode($token20);
    }
$token20=urlencode($token20);
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'UPDATE `buy_castomer` SET `sended`=? WHERE `id`=?';
      $stmt = $conn->prepare($sql);
      $stmt->execute([$data[0],$data[1]]);



      // $token='09013384162';
      //
      // $token10='سیسب';
      //
      // $token20='سیلسیل';

        if ($data[0]==0 || $data[0]==1 || $data[0]==2 || $data[0]==3) {
          $content = file_get_contents("https://api.kavenegar.com/v1/33544A49654A41584F5245782F6E474B304F4D534A324E716D4F614F78384747577646596A5763792F6A493D/verify/lookup.json?receptor=$token&token=$token&token10=$token10&token20=$token20&template=status");

        }









        return 'noError';
    } catch (PDOException $e) {
      return $e->getMessage();
      return 'Error';
    }
    $conn = null;

  }









}
