<?php
include_once '../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$data = array(
  $_POST['min_content'],
  $_POST['max_content'],
);
$output->update_data($data);
