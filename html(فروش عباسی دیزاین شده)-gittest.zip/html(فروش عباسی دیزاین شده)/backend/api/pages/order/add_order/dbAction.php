<?php

class DbAction extends Config
{
  public function insert($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO `rtl_order` (`gram`,`cassette`,`size`,`form`,`price`)
      VALUES(?,?,?,?,?)";

      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $id = $conn->lastInsertId();
      $sh = $stmt->fetch();
      $this->temp = array(
        "blog_id"=>$id,
      );
      return 'noError';
    } catch (PDOException $e) {
       echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
  public function selectAll($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT * FROM `rtl_order`  ORDER BY `id` DESC LIMIT $data[0],10";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();


      $sw = "SELECT * FROM  `rtl_order`";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count =  $qw->rowCount();
      foreach($sh as $key=>$value) {
        $this->temp[] = array(
          'id' => @$value['id'],
          'gram' => @$value['gram'],
          'cassette' => @$value['cassette'],
          'size' => @$value['size'],
          'form' => @$value['form'],
          'price' => @$value['price'],

        );
      }
      $this->temp2=array('blog_count' => $blog_count,);
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
  public function select($data)
  {
     try {
    $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM `rtl_order` WHERE `id`=?";

    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
    $sh=$stmt->fetch();
    // $content=explode("<!--more-->",@$sh['content']);
    $this->temp = array(
      'id' => $sh['id'],
      'gram'=>$sh['gram'],
      'cassette'=>$sh['cassette'],
      'size'=>$sh['size'],
      'form'=>$sh['form'],
      'price'=>$sh['price'],


    );
    return 'noError';
  }catch (PDOException $e) {
      return 'Error';
      //echo $sql.'<br>'.$e->getMessage();
    }
  }
  public function update($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'UPDATE `rtl_order` SET `gram`=?,`cassette`=?,`size`=?,`form`=?,`price`=? WHERE `id`=?';
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
        return 'noError';
    } catch (PDOException $e) {
      return $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }









}
