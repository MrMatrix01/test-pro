<?php
include_once '../../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$data = array(
  $checked->checkPost('garma', 200, 'notNull'),
  $checked->checkPost('kaset', 200, 'notNull'),
  $checked->checkPost('size', 200, 'notNull'),
  $checked->checkPost('halat', 200, 'notNull'),
  $checked->checkPost('order_price', 200, 'notNull'),
  // $checked->checkPost('silver', 200, 'notNull'),
  // $checked->checkPost('phosphoric', 200, 'notNull'),
  // $checked->checkPost('golden', 200, 'notNull'),
  // $checked->checkPost('white', 200, 'notNull'),
  // $checked->checkPost('add_Percent', 200, 'notNull'),


    $checked->checkPost('blog_id', 11, 'notNull'),
  // ($checked->checkPost('min_content', 1500, 'notNull').
  // '<!--more-->'.
  // $checked->checkPost('max_content', 2500, 'notNull')),

);
$output->update_data($data);
