<?php
include_once '../../../kernel/config/config.php';
  $data = array(
    $checked->checkPost('gram', 70, 'notNull'),
    $checked->checkPost('cassette', 70, 'notNull'),
    $checked->checkPost('first_color', 70, 'notNull'),
    $checked->checkPost('second_color', 70, 'notNull'),
    $checked->checkPost('size', 70, 'notNull'),
    $checked->checkPost('print', 70, 'notNull'),
    $checked->checkPost('form', 70, 'notNull'),
    $checked->checkPost('handle', 70, 'notNull'),
    $checked->checkPost('handle_color', 70, 'notNull'),
    $checked->checkPost('number', 11, 'notNull'),
    2000,
    // $checked->checkPost('answer', 11, 'notNull'),
  );
$output->insert_data(@$data);
