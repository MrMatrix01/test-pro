<?php
include_once '../../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-----
$data = array(
  $checked->checkPost('id_page', 11, 'notNull'),
);
$output->select_data($data);
