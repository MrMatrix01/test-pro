<?php
include_once '../../../../../kernel/config/config.php';


  $data = array(
    // $checked->checkPost('garma', 70, 'notNull'),
    // $checked->checkPost('kaset', 70, 'notNull'),
    // $checked->checkPost('size', 70, 'notNull'),
    // $checked->checkPost('halat', 70, 'notNull'),

    $checked->checkPost('first-color-price', 70, 'notNull'),
    $checked->checkPost('secont-color-price', 70, 'notNull'),
    $checked->checkPost('chooce-secont-price', 70, 'notNull'),
    $checked->checkPost('handel-90-price', 70, 'notNull'),
    $checked->checkPost('handel-60-price', 70, 'notNull'),
    $checked->checkPost('silver-price', 70, 'notNull'),
    $checked->checkPost('phosphor-price', 70, 'notNull'),
    $checked->checkPost('golden-price', 70, 'notNull'),
    $checked->checkPost('white-price', 70, 'notNull'),
    $checked->checkPost('percent-price', 70, 'notNull'),
    $checked->checkPost('handel-40-price', 70, 'notNull'),
    // $checked->checkPost('order_price', 70, 'notNull'),
    // $checked->checkPost('print', 70, 'notNull'),
    // $checked->checkPost('form', 70, 'notNull'),
    // $checked->checkPost('handle', 70, 'notNull'),
    // $checked->checkPost('handle_color', 70, 'notNull'),
    // $checked->checkPost('number', 11, 'notNull'),
    // 2000,
    // $checked->checkPost('answer', 11, 'notNull'),

  );

$output->insert_data(@$data);
