<?php
include_once '../../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
if(!isset($_POST['add_Percent'])){
  $add_Percent=0;
}else {
  $add_Percent=$_POST['add_Percent'];
}
$data = array(
  $checked->checkPost('blog_title', 200, 'notNull'),
  $checked->checkPost('price_second_color', 200, 'notNull'),
  $checked->checkPost('choose_second_color', 200, 'notNull'),
  $checked->checkPost('zanbil_handel_90', 200, 'notNull'),
  $checked->checkPost('zanbil_handel_60', 200, 'notNull'),
  $checked->checkPost('silver', 200, 'notNull'),
  $checked->checkPost('phosphoric', 200, 'notNull'),
  $checked->checkPost('golden', 200, 'notNull'),
  $checked->checkPost('white', 200, 'notNull'),
  $checked->checkPost('print1', 200, 'notNull'),
  $checked->checkPost('print2', 200, 'notNull'),
  // $checked->checkPost('add_Percent', 200, 'notNull'),
  $add_Percent,


  $checked->checkPost('zanbil_handel_40', 200, 'notNull'),
    $checked->checkPost('blog_id', 11, 'notNull'),
  // ($checked->checkPost('min_content', 1500, 'notNull').
  // '<!--more-->'.
  // $checked->checkPost('max_content', 2500, 'notNull')),

);
$output->update_data($data);
