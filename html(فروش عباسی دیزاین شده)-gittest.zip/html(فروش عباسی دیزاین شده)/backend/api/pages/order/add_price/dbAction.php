<?php

class DbAction extends Config
{
  public function insert($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO `add_price` (`price_first_color`,`price_second_color`,`choose_second_color`,`zanbil_handel_90`,`zanbil_handel_60`,`silver`,`phosphoric`,`golden`,`white`,`add_Percent`,`zanbil_handel_40`)
      VALUES(?,?,?,?,?,?,?,?,?,?,?)";

      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $id = $conn->lastInsertId();
      $sh = $stmt->fetch();
      $this->temp = array(
        "blog_id"=>$id,
      );
      return 'noError';
    } catch (PDOException $e) {
       echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
  public function selectAll($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT * FROM `add_price`  ORDER BY `id` DESC LIMIT $data[0],10";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();


      $sw = "SELECT * FROM  `add_price`";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count =  $qw->rowCount();
      foreach($sh as $key=>$value) {
        $this->temp[] = array(
          'id' => @$value['id'],
          'price_first_color' => @$value['price_first_color'],
          'price_second_color' => @$value['price_second_color'],
          'choose_second_color' => @$value['choose_second_color'],
          'zanbil_handel_90' => @$value['zanbil_handel_90'],
          'zanbil_handel_60' => @$value['zanbil_handel_60'],
          'silver' => @$value['silver'],
          'phosphoric' => @$value['phosphoric'],
          'golden' => @$value['golden'],
          'white' => @$value['white'],
          'print_one'=>$sh['print_one'],
          'print_two'=>$sh['print_two'],
          'add_Percent' => @$value['add_Percent'],
          'zanbil_handel_40' => @$value['zanbil_handel_40'],
        );
      }
      $this->temp2=array('blog_count' => $blog_count,);
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
  public function select($data)
  {
     try {
    $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM `add_price` WHERE `id`=?";

    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
    $sh=$stmt->fetch();
    $this->temp = array(
      'id' => $sh['id'],
      'price_first_color'=>$sh['price_first_color'],
      'price_second_color'=>$sh['price_second_color'],
      'choose_second_color'=>$sh['choose_second_color'],
      'zanbil_handel_90'=>$sh['zanbil_handel_90'],
      'zanbil_handel_60'=>$sh['zanbil_handel_60'],
      'silver'=>$sh['silver'],
      'phosphoric'=>$sh['phosphoric'],
      'golden'=>$sh['golden'],
      'white'=>$sh['white'],
      'print_one'=>$sh['print_one'],
      'print_two'=>$sh['print_two'],
      'add_Percent'=>$sh['add_Percent'],
      'zanbil_handel_40'=>$sh['zanbil_handel_40'],
    );
    return 'noError';
  }catch (PDOException $e) {
      return 'Error';
      //echo $sql.'<br>'.$e->getMessage();
    }
  }
  public function update($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'UPDATE `add_price` SET `price_first_color`=?,`price_second_color`=?,`choose_second_color`=?,`zanbil_handel_90`=?,`zanbil_handel_60`=?,`silver`=?,`phosphoric`=?,`golden`=?,`white`=?,`print_one`=?,`print_two`=?,`add_Percent`=?,`zanbil_handel_40`=? WHERE `id`=?';
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
        return 'noError';
    } catch (PDOException $e) {
      //return $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
}
