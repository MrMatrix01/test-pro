<?php
include_once '../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$data = array(
  $checked->checkPost('name', 60, 'null'),
  $checked->checkPost('family', 60, 'null'),
  $checked->checkPost('username', 60, 'notNull'),
  $checked->checkPost('password', 100, 'notNull'),
  $checked->checkPost('role', 2, 'null'),
  $checked->checkPost('status', 2, 'null'),
);
$output->insert_data($data);
