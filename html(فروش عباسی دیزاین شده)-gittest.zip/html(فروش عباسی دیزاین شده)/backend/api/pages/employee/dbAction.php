<?php
class DbAction extends Config
{
  public function insert($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO `managers` (`name`,`family`,`username`,`password`,`role`,`status`)
      VALUES(?,?,?,?,?,?)";
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $id = $conn->lastInsertId();
      $sh = $stmt->fetch();
      $this->temp = array(
        "blog_id"=>$id,
      );
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
  public function selectAll($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8",$this->user,$this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT * FROM `rtl_users` ORDER BY `id` DESC";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();

      $sw = "SELECT * FROM  `rtl_users`";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count =  $qw->rowCount();
      $this->temp = $sh;

      $this->temp2=array('blog_count' => $blog_count, );
      return 'noError';
    } catch (PDOException $e) {
      // echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
  public function select($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT `name`,`family`,`username`,`status` FROM `managers` WHERE `id`=?";

      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $sh=$stmt->fetch();
      $this->temp = $sh;
      return 'noError';
    }catch (PDOException $e) {
      return 'Error';
      //echo $sql.'<br>'.$e->getMessage();
    }
  }
  public function update($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      if(empty($data[3])){
        $sql = "UPDATE `managers` SET `name`=?,`family`=?,`username`=?,`status`=? WHERE `id`=?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$data[0],$data[1],$data[2],$data[4],$data[5]]);
      }else {
        $sql = 'UPDATE `managers` SET `name`=?,`family`=?,`username`=?,`password`=?,`status`=? WHERE `id`=?';
        $stmt = $conn->prepare($sql);
        $stmt->execute($data);
      }
      return 'noError';
    } catch (PDOException $e) {
      //return $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
  public function search($data)
  {
    $var=1;
    $search=$data[0];

    $likeWord='';

    $searchWord = explode(' ' ,$search);
    foreach ($searchWord as $key => $value) {
      $likeWord=$likeWord."AND `username`  LIKE '%$value%'";
    }
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8",$this->user,$this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT * FROM `managers` WHERE `role`='$var' $likeWord ORDER BY `id` DESC";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();
      $sw = "SELECT * FROM  `managers` WHERE `role`='$var'  $likeWord ORDER BY `id` DESC";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count =  $qw->rowCount();
      $this->temp = $sh;
    $this->temp2=array('blog_count' => $blog_count);
    return 'noError';
  } catch (PDOException $e) {
    echo $e->getMessage();
    return  'Error';
  }
  $conn = null;
}
}
