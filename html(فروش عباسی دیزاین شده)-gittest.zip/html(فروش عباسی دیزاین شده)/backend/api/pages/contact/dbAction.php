<?php
class DbAction extends Config
{
  public function update($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8",$this->user,$this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $id=1;
      $sql = "UPDATE `rtl_lnd_contact` SET `content`=? WHERE `id`='$id'";
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      return 'noError';
    } catch (PDOException $e) {
      //return $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
 public function selectAll($data)
  {
    $id=1;
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT * FROM `rtl_lnd_contact` WHERE `id`='$id'";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetch();

        $this->temp[] = array(
          'content' => @$sh['content'],
        );

      return 'noError';
    } catch (PDOException $e) {
      return  'Error';
    }
    $conn = null;
  }
}
