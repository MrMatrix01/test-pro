<?php
include_once '../../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$data = array(
  $checked->checkPost('check_sended', 9, 'null'),
    $checked->checkPost('id_sended', 9, 'notNull'),
);
$output->update_data($data);
