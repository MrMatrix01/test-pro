<?php

class DbAction extends Config
{
  public function insert($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO `rtl_order` (`gram`,`cassette`,`size`,`form`,`price`)
      VALUES(?,?,?,?,?)";

      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
      $id = $conn->lastInsertId();
      $sh = $stmt->fetch();
      $this->temp = array(
        "blog_id"=>$id,
      );
      return 'noError';
    } catch (PDOException $e) {
       echo $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }
  public function selectAll($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT *,`buy_castomer`.`id` AS `id_buy_castomers` FROM `buy_castomer`
      INNER JOIN `rtl_transactions` ON `rtl_transactions`.`authority`=`buy_castomer`.`authority`
      LEFT JOIN `rtl_files_user` ON `id_rtl_files_user`=`rtl_files_user`.`id`
       ORDER BY `id_buy_castomers` DESC LIMIT $data[0],10";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $sh=$stmt->fetchAll();


      $sw = "SELECT *,`buy_castomer`.`id` AS `id_buy_castomers` FROM `buy_castomer`
      INNER JOIN `rtl_transactions` ON `rtl_transactions`.`authority`=`buy_castomer`.`authority`
       ORDER BY `id_buy_castomers`";
      $qw = $conn->prepare($sw);
      $qw->execute();
      $blog_count =  $qw->rowCount();





      foreach($sh as $key=>$value) {
        // echo $value['rtl_users_id'].'_';
        $id_user=$value['rtl_users_id'];
        $sql2 = "SELECT * FROM `rtl_users` WHERE `id`='$id_user'";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->execute();
        $sh2=$stmt2->fetch();



        $this->temp[] = array(
          'id_buy_castomer' => @$value['id_buy_castomers'],
          'handel' => @$value['handel'],
          'handel_color' => @$value['handel_color'],
          'first_color' => @$value['first_color'],
          'second_color' => @$value['second_color'],
          'number' => @$value['number'],
          'print' => @$value['print'],
          'price' => @$value['price'],
          'garma' => @$value['garma'],
          'form' => @$value['form'],
          'cassette' => @$value['cassette'],
          'size' => @$value['size'],
          'rtl_users_id' => @$value['rtl_users_id'],
          'address' => @$value['address'],
          'transport' => @$value['transport'],
          'mobile' => @$value['mobile'],
          'mobile2' => @$value['mobile2'],
          'phone' => @$value['phone'],
          'city' => @$value['city'],
          'state' => @$value['state'],
          'id_rtl_files_user' => @$value['id_rtl_files_user'],
          'file_name' => @$value['file_name'],
          'phone_user'=>@$sh2['phone'],
          'sended' => @$value['sended'],
          'authority' => @$value['authority'],
          'refid' => @$value['refid'],
        );
      }
      $this->temp2=array('blog_count' => $blog_count);
      return 'noError';
    } catch (PDOException $e) {
      echo $e->getMessage();
      return  'Error';
    }
    $conn = null;
  }
  public function select($data)
  {
     try {
    $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM `buy_castomer` WHERE `id`=?";

    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
    $sh=$stmt->fetch();
    // $content=explode("<!--more-->",@$sh['content']);
    $this->temp = array(
      'id' => $sh['id'],
      'gram'=>$sh['gram'],
      'cassette'=>$sh['cassette'],
      'size'=>$sh['size'],
      'form'=>$sh['form'],
      'price'=>$sh['price'],
      'id_rtl_files_user'=>$sh['id_rtl_files_user'],


    );
    return 'noError';
  }catch (PDOException $e) {
      return 'Error';
      //echo $sql.'<br>'.$e->getMessage();
    }
  }
  public function update($data)
  {
    try {
      $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = 'UPDATE `buy_castomer` SET `sended`=? WHERE `id`=?';
      $stmt = $conn->prepare($sql);
      $stmt->execute($data);
        return 'noError';
    } catch (PDOException $e) {
      return $e->getMessage();
      return 'Error';
    }
    $conn = null;
  }









}
