<?php
include_once '../../../../kernel/config/config.php';
//-------------------مشخص کردن دریافتی های سمت کاربر و تعداد کاراکتر ان-------
$data = array(
  $checked->checkPost('blog_title', 200, 'notNull'),
  $_POST['min_content'],
    $checked->checkPost('blog_pre_image', 200, 'notNull'),
    $checked->checkPost('blog_id', 11, 'notNull'),
  // ($checked->checkPost('min_content', 1500, 'notNull').
  // '<!--more-->'.
  // $checked->checkPost('max_content', 2500, 'notNull')),

);
$output->update_data($data);
