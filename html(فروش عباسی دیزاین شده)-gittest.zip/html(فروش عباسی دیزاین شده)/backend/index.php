<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <title></title>
  <?php
  // $_SESSION['id']=1;
  ?>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php
  require_once '../kernel/route/route.php';
  require_once 'web_view/themes/widgets/head.php';
  ?>
</head>
<body onload="select()">
  <div class="container">
    <?php
    require_once 'web_view/themes/widgets/header.php';
    ?>
    <main>
      <?php
      if ($uri!='/') {
        require_once 'web_view/themes/widgets/rightbar.php';
      }
      if((!isset($_SESSION['id'])) && ($uri!='/')){
        ?>
        <meta http-equiv="refresh" content="0;url=./">
        <?php
      }
          require_once '../kernel/lib/onload.php';
      if($main_route=='404'){
        ?>
        <div style="width:100%;text-align:center;margin-top:100px;font-size:30px;">404 Not Found</div>
        <?php
      }else{
        require_once $main_route;
      }
      ?>
    </main>
    <?php
    if ($uri!='/') {
      require_once 'web_view/themes/widgets/footer.php';
    }
    ?>
  </div>
  <?php
  require_once 'web_view/themes/widgets/foot.php';
   ?>
</body>
</html>
