<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <?php
  $_SESSION['id']=1;
  ?>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="ساک دستی پارچه ای| بگ تبلیغاتی|بگ پارچه ای|ساک دستی| ساک پارچه ای تبلیغاتی|کیف پارچه ای">
  <meta name="keyword" content="ساک پارچه ای,بگ پارچه ای,بگ تبلیغاتی,بگ,شاپینگ بگ پارچه ای,کیف پارچه ای,تولید بگ پارچه ای,ساک دستی">
  <meta property="og:site_name" content="ایران بگ">
  <title>بگ پارچه ای | ساک دستی پارچه ای</title>
  <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'<?=$countBack?>frontend/web_view/themes/js/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WK7W35M');</script>
<!-- End Google Tag Manager -->
<!-- Google tag (gtag.js) -->
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-PGV4Z5J6YE');

  !function (t, e, n) {
      t.yektanetAnalyticsObject = n, t[n] = t[n] || function () {
          t[n].q.push(arguments)
      }, t[n].q = t[n].q || [];
      var a = new Date, r = a.getFullYear().toString() + "0" + a.getMonth() + "0" + a.getDate() + "0" + a.getHours(),
          c = e.getElementsByTagName("script")[0], s = e.createElement("script");
      s.id = "ua-script-DymvsjT5"; s.dataset.analyticsobject = n;
      s.async = 1; s.type = "text/javascript";
      s.src = "https://cdn.yektanet.com/rg_woebegone/scripts_v3/DymvsjT5/rg.complete.js?v=" + r, c.parentNode.insertBefore(s, c)
  }(window, document, "yektanet");
</script>
  <?php
  require_once 'kernel/route/route.php';
  require_once 'frontend/web_view/themes/widgets/head.php';
  ?>
</head>
<body onload="select()">
  <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WK7W35M"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <div class="container">
    <header>
      <div class="menu-head">
        <div class="link-menu-head">
          <ul class="link-menu-ul">
            <li class="link-menu-li">
              <a href="<?=$countBack?>" class="link-a">
                <i class="fas fa-home"></i>
              </a>
            </li>
            <?php
            if(isset($_SESSION['username'])){
              ?>
              <li class="link-menu-li">
                خوش آمدید
              </li>
              <li class="link-menu-li">
              <a href="<?=$countBack?>frontend/api/authentication/logout/index.php">  خروج</a>
              </li>

              <?php
            }else{
             ?>
             <!-- <li class="link-menu-li">
               <a href="<?=$countBack?>signin" class="link-a">
                 ثبت نام/ورود
               </a>
             </li> -->
              <?php
              }
              ?>
          </ul>
        </div>
    <div class="contact-menu-head">
      <ul class="contact-menu-ul">
        <li class="contact-menu-li">09120129098 -09120126880 -02146041466<i class="fa fa-phone green"></i></li>
        <li class="contact-menu-li">iranbag.ir@gmail.com <i class="fa fa-envelope green"></i></li>
      </ul>
    </div>
    <div class="logo-mobile">
      <a href="<?=$countBack?>">
        <img src="<?=$countBack?>frontend/web_view/themes/images/logo2.png" style="width: 58%;" alt="بگ پارچه ای">
      </a>
    </div>
      </div>
      <div class="search">
        <div class="logo-head">
          <a href="<?=$countBack?>">
            <img src="<?=$countBack?>frontend/web_view/themes/images/logo2.png" class="img-logo-head" alt="بگ پارچه ای">
            <h1 style="display:none;">
              بگ پارچه ای
            </h1>
          </a>
        </div>
        <div class="search-bar">
          <form class="form-search" action="<?=$countBack?>search" method="get">
            <div  class="select-serch">
              <div onclick="myFunctionSearch()" class="dropbtn2">
              </div>
              <span class="span-all-file">همه فایل ها</span>
              <i class="fa fa-chevron-down icon-down" ></i>
            </div>
            <!-- <div id="myDropdown2" class="dropdown-content2">
              <div class="check-input">
                <input type="checkbox" name="" value="">
                عنوان مقالات
              </div>
              <div class="check-input">
                <input type="checkbox" name="" value="">
                تگ
              </div>
            </div> -->
            <input type="text" name="search" class="input-search" value="" placeholder="جستجو کنید ...">
            <button type="submit"    class="button-search"><i class="fal fa-search icon-search"> </i></button>
          </form>
          <div class="search-text">
            ایران بگ تولید کننده انواع ساک دستی پارچه ای تبلیغاتی
          </div>
        </div>
        <div class="search-left">
        </div>
      </div>
      <div class="menubar">
        <ul class="menubar-ul">
          <!-- <li class="menubar-li selected">لیست قیمت</li> -->
          <li class="menubar-li <?php if($uri=='/')echo 'selected'; ?> ">
            <a href="<?=$countBack?>" class="menubar-a">صفحه اصلی</a>
          </li>
          <!-- <li class="menubar-li">
            <a href="https://irantarh.com/" class="menubar-a">خدمات ما</a>
          </li> -->
          <li class="menubar-li <?php if($uri=='/gallery')echo 'selected'; ?>">
            <a href="<?=$countBack?>gallery" class="menubar-a">محصولات بگ پارچه ای</a>
          </li>
          <li class="menubar-li <?php if($uri=='/blog')echo 'selected'; ?>">
            <a href="<?=$countBack?>blog" class="menubar-a">مقالات آموزشی</a>
          </li>
          <li class="menubar-li <?php if($uri=='/price_list')echo 'selected'; ?>">
            <a href="<?=$countBack?>price_list" class="menubar-a">لیست قیمت بگ پارچه ای</a>
          </li>
          <li class="menubar-li <?php if($uri=='/contact')echo 'selected'; ?>">
            <a href="<?=$countBack?>contact" class="menubar-a">تماس با ایران بگ</a>
          </li>
          <!-- <li class="menubar-li <?php if($uri=='/order')echo 'selected'; ?>">
            <a href="<?=$countBack?>order" class="menubar-a">سامانه سفارش آنلاین</a>
          </li> -->
        </ul>
        <div class="dropdown">
          <button onclick="myDropdown()" class="dropbtn">
            <i class="fa fa-bars"></i>
          </button>
          <div id="myDropdown" class="dropdown-content">
            <!-- <li class="menubar-li selected">لیست قیمت</li> -->
            <li class="menubar-li selected">
              <a href="<?=$countBack?>" class="menubar-a">صفحه اصلی</a>
            </li>

            <!-- <li class="menubar-li">
              <a href="https://irantarh.com/" class="menubar-a">خدمات ما</a>
            </li> -->
            <li class="menubar-li">
              <a href="<?=$countBack?>gallery" class="menubar-a">محصولات بگ پارچه ای</a>
            </li>
            <li class="menubar-li">
              <a href="<?=$countBack?>blog" class="menubar-a">مقالات آموزشی</a>
            </li>
            <li class="menubar-li">
              <a href="<?=$countBack?>price_list" class="menubar-a">لیست قیمت بگ پارچه ای</a>
            </li>
            <li class="menubar-li">
              <a href="<?=$countBack?>contact" class="menubar-a">تماس با ایران بگ</a>
            </li>
            <!-- <li class="menubar-li">
              <a href="<?=$countBack?>order" class="menubar-a">سامانه سفارش آنلاین</a>
            </li> -->
          </div>
        </div>
      </div>
    </header>
    <?php
    include 'kernel/lib/onload.php';
    if($main_route=='404'){
      echo "404";
      ?>
      <div style="width:100%;text-align:center;margin-top:100px;font-size:30px;">404 Not Found</div>
      <?php
    }else{
      require_once $main_route;
    }

    ?>
    <footer>
      <div class="footer-about">
        <div class="access">
          <h2 class="access-h4">دسترسی سریع</h2>
          <a href="about" class="access-a">درباره ما</a>
          <a href="contact" class="access-a">تماس با ایران بگ</a>
          <a href="#" class="access-a">همکاری با ما</a>
        </div>
        <div class="access">
          <h2 class="access-h4">اطلاعات تماس</h2>
          <span class="access-a"><i class="fa fa-phone-alt green"></i> پشتیبانی در ساعات اداری</span>
          <span class="access-a tab">02146041466</span>
          <span class="access-a tab">09120126880</span>
          <span class="access-a tab">09120129098</span>
          <span class="access-a"><i class="fa fa-envelope green"></i> فرم تماس</span>
        </div>
        <div class="access">
          <h2 class="access-h4">اطلاعات</h2>
          <span class="access-a">پرسش های متداول</span>
          <a href="about" class="access-a">درباره ما و قوانین</a>
          <span class="access-a">دانلود فونت ها</span>
        </div>
        <div class="access" style="padding-top: 64px;">
          <!-- <img src="<?=$countBack?>frontend/web_view/themes/images/enamad.png" class="access-img" alt="نماد"> -->
          <a referrerpolicy="origin" target="_blank" href="https://trustseal.enamad.ir/?id=372528&amp;Code=JtZZy1EW3S1YqzzX1ouQ"><img referrerpolicy="origin" src="https://Trustseal.eNamad.ir/logo.aspx?id=372528&amp;Code=JtZZy1EW3S1YqzzX1ouQ" alt="" style="cursor:pointer" id="JtZZy1EW3S1YqzzX1ouQ"></a>
        </div>
        <div class="access">
          <img src="<?=$countBack?>frontend/web_view/themes/images/resane.png" class="access-img" alt="رسانه">
        </div>
      </div>
      <div class="footer-rule">
        <p class="p-rule">
استفاده از مطالب سایت ایران بگ فقط برای مقاصد غیر تجاری و با ذکر منبع بلا مانع است.
        </p>
        <p class="p-rule">
        طراحی سایت و برنامه نویسی : گروه برنامه نویسی خیام. - Developed By Khayyam programming group
        </p>
      </div>
    </footer>
  </div>
</body>
<?php require_once 'frontend/web_view/themes/widgets/foot.php'; ?>
</html>
